package app.pdfreader.core.text

import java.text.Normalizer

/** Ported from the original HTML project: normalisation, garbled detection, sentence/block logic. */
object TextUtils {
    class PText(val g: Int, val text: String)
    class Block(val src: String, val grps: List<Int>)

    fun hash(s: String): String {
        var h = 5381
        for (c in s) h = (h shl 5) + h + c.code
        return (h.toLong() and 0xFFFFFFFFL).toString(36) + "_" + s.length
    }

    fun docKey(name: String, pageCount: Int): String = hash("$name|$pageCount")

    private const val FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹"
    private val presentationForms = Regex("[\\uFB50-\\uFDFF\\uFE70-\\uFEFF]")

    fun faDigits(n: Int): String = n.toString().map { FA_DIGITS[it - '0'] }.joinToString("")

    fun faFix(input: String): String {
        var t = input
        if (presentationForms.containsMatchIn(t)) t = Normalizer.normalize(t, Normalizer.Form.NFKC)
        val sb = StringBuilder(t.length)
        for (ch in t) {
            when {
                ch == '\u064A' -> sb.append('\u06CC')
                ch == '\u0643' -> sb.append('\u06A9')
                ch == '\u0640' -> {}
                ch in '\u0660'..'\u0669' -> sb.append(FA_DIGITS[ch - '\u0660'])
                ch in '\u064B'..'\u065F' || ch == '\u0670' -> {}
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun normalizeText(t: String): String =
        faFix(t)
            .replace("\u00AD", "")
            .replace('\u2010', '-')
            .replace("ﬁ", "fi").replace("ﬂ", "fl").replace("ﬀ", "ff").replace("ﬃ", "ffi").replace("ﬄ", "ffl")
            .replace('\u2018', '\'').replace('\u2019', '\'')
            .replace('\u201C', '"').replace('\u201D', '"')
            .replace(Regex("\\s{2,}"), " ")
            .trim()

    fun isPersian(t: String): Boolean {
        val fa = t.count { it in '\u0600'..'\u06FF' }
        val en = t.count { it in 'A'..'Z' || it in 'a'..'z' }
        return fa > 0 && fa >= en * 0.5
    }

    /** Persian text layers with unmapped fonts: odd glyphs, reversed order or very few real letters. */
    fun looksGarbled(t: String): Boolean {
        val s = t.replace(Regex("\\s+"), "")
        if (s.length < 40) return false
        val fa = s.count { it in '\u0600'..'\u06FF' }
        val odd = s.count { it == '\uFFFD' || it in '\u0000'..'\u0008' || it in '\uE000'..'\uF8FF' }
        val pres = s.count { it in '\uFB50'..'\uFDFF' || it in '\uFE70'..'\uFEFF' }
        val latin = s.count { it in 'A'..'Z' || it in 'a'..'z' }
        if (odd.toDouble() / s.length > 0.03) return true
        if (fa > 0 && pres.toDouble() / fa > 0.5) return false
        return fa < s.length * 0.2 && latin < s.length * 0.2
    }

    fun joinLines(a: List<String>): String {
        var s = ""
        for (t in a) {
            s = when {
                s.isEmpty() -> t
                Regex("[A-Za-z]-$").containsMatchIn(s) && Regex("^[a-z]").containsMatchIn(t) -> s.dropLast(1) + t
                else -> "$s $t"
            }
        }
        return s
    }

    fun isMdTable(t: String): Boolean = t.split('\n').count { Regex("^\\s*\\|").containsMatchIn(it) } >= 2

    private val tableSep = Regex("^\\s*\\|[\\s:\\-|]*\\|\\s*$")

    private fun rowCells(l: String): List<String> =
        l.replace(Regex("^\\s*\\|"), "").replace(Regex("\\|\\s*$"), "").split('|').map { it.trim() }

    /** Markdown table -> readable sentence for TTS: columns first, then each row. */
    fun mdTableToSpeech(text: String): String {
        val fa = text.any { it in '\u0600'..'\u06FF' }
        val label = if (fa) "جدول." else "Table."
        val out = ArrayList<String>()
        var rows = ArrayList<String>()
        fun flush() {
            if (rows.isEmpty()) return
            val clean = rows.filter { !tableSep.containsMatchIn(it) }
                .map { l -> rowCells(l).filter { it.isNotEmpty() } }
            if (clean.isNotEmpty()) {
                val sep = if (fa) "، " else ", "
                var s = label
                if (clean.size > 1) {
                    s += (if (fa) " ستون‌ها: " else " Columns: ") + clean[0].joinToString(sep) + "."
                    for (i in 1 until clean.size) {
                        s += (if (fa) " ردیف ${faDigits(i)}: " else " Row $i: ") + clean[i].joinToString(sep) + "."
                    }
                } else s += " " + clean[0].joinToString(sep) + "."
                out.add(s)
            }
            rows = ArrayList()
        }
        text.split('\n').forEach { l ->
            if (Regex("^\\s*\\|").containsMatchIn(l)) rows.add(l) else { flush(); out.add(l) }
        }
        flush()
        return out.joinToString("\n")
    }

    /** Text sent to TTS: tables as sentences, pronunciation dictionary, tag codes like FT-101 spelled out. */
    fun ttsReady(text: String, pron: Map<String, String>): String {
        var t = mdTableToSpeech(text)
        for (k in pron.keys.sortedByDescending { it.length }) {
            val esc = Regex.escape(k)
            val pre = if (Regex("^[A-Za-z0-9]").containsMatchIn(k)) "(?<![A-Za-z0-9])" else ""
            val post = if (Regex("[A-Za-z0-9]$").containsMatchIn(k)) "(?![A-Za-z0-9])" else ""
            val v = pron.getValue(k)
            t = Regex(pre + esc + post).replace(t) { v }
        }
        t = Regex("\\b([A-Z]{2,5})-(\\d{1,5}[A-Z]?)\\b").replace(t) { m ->
            m.groupValues[1].toCharArray().joinToString(" ") + " " + m.groupValues[2]
        }
        return t.trim()
    }

    // ---------- OCR output -> paragraphs ----------

    fun ocrToParas(text: String): List<String> {
        val cleaned = text.replace("\r", "").replace(Regex("(?m)^\\s*```[a-z]*\\s*$|\\s*```\\s*$"), "")
        val paras = ArrayList<String>()
        for (b in cleaned.split(Regex("\\n\\s*\\n"))) {
            val bl = b.trim()
            if (bl.isEmpty()) continue
            val tableLines = bl.split('\n').filter { Regex("^\\s*\\|").containsMatchIn(it) }
            if (tableLines.size >= 2) {
                paras.add(tableLines.joinToString("\n") { it.trim().replace(Regex("\\s{2,}"), " ") })
                continue
            }
            var lines = b.split('\n').map { normalizeText(it) }.filter { it.isNotEmpty() }
            lines = lines.filter { l ->
                !((Regex("^\\s*page\\s*\\d+\\s*(of\\s*\\d+)?\\s*$", RegexOption.IGNORE_CASE).containsMatchIn(l) ||
                    Regex("^\\s*[\\d۰-۹]+\\s*$").containsMatchIn(l)) && l.length < 25)
            }
            if (lines.isEmpty()) continue
            val p = joinLines(lines)
            if (p.isNotEmpty()) paras.add(p)
        }
        val merged = ArrayList<String>()
        for (p in paras) {
            val t = p.trim()
            if (t.isEmpty()) continue
            if (!isMdTable(t) && merged.isNotEmpty() &&
                Regex("[\\u2013-]$").containsMatchIn(merged.last()) && Regex("^[a-z]").containsMatchIn(t)
            ) {
                merged[merged.lastIndex] = merged.last().replace(Regex("[\\u2013-]$"), "") + t
            } else merged.add(t)
        }
        return merged
    }

    // ---------- sentences and TTS blocks ----------

    private val abbr = Regex("\\b(Figs?|Eqs?|Nos?|Tabs?|Sects?|Sec|Refs?|approx|cf|vs|etc|e\\.g|i\\.e|viz|Vol|Ch|Dept|Univ|Co|Ltd|Inc|Corp|St|Mr|Dr|Ms|Prof|min|max|Std|Din|ISO)\\.")
    private val dec = Regex("(\\d)\\.(\\d)")
    private val sentSplit = Regex("(?<=[.!?؟])\\s+")

    fun splitSentences(text: String): List<String> {
        val t = text.replace(abbr, "$1\u0001").replace(dec, "$1\u0001$2")
        val out = ArrayList<String>()
        for (s in t.split(sentSplit)) {
            val clean = s.replace('\u0001', '.').trim()
            if (clean.isEmpty()) continue
            if (out.isNotEmpty() && (clean.length < 3 || Regex("^[,;)\\]}\"']").containsMatchIn(clean))) {
                out[out.lastIndex] = out.last() + " " + clean
            } else out.add(clean)
        }
        return out
    }

    private fun sentenceUnits(p: String): List<String> =
        if (isMdTable(p)) p.split('\n') else splitSentences(p)

    /** Packs whole sentences into blocks of about `target` characters; never cuts mid-sentence. */
    fun buildBlocks(paras: List<PText>, target: Int): List<Block> {
        val max = (target * 1.35).toInt()
        class Cur(var text: String = "", val gs: LinkedHashSet<Int> = LinkedHashSet())
        val blocks = ArrayList<Cur>()
        var cur: Cur? = null
        fun push() { cur?.let { if (it.text.isNotEmpty()) blocks.add(it) }; cur = null }
        for (p in paras) {
            sentenceUnits(p.text).forEachIndexed { si, sen ->
                val c0 = cur
                if (c0 != null) {
                    val add = sen.length + 1
                    if (c0.text.length + add > max || (c0.text.length + add > target && c0.text.length >= target * 0.4)) push()
                }
                val c = cur ?: Cur().also { cur = it }
                val sep = if (c.text.isEmpty()) "" else if (Regex("^\\s*\\|").containsMatchIn(sen)) "\n" else if (si == 0) "\n\n" else " "
                c.text += sep + sen
                c.gs.add(p.g)
            }
        }
        push()
        if (blocks.size > 1) {
            val last = blocks.last(); val prev = blocks[blocks.size - 2]
            if (last.text.length < 250 && prev.text.length + last.text.length + 2 <= max) {
                prev.text += "\n\n" + last.text
                prev.gs.addAll(last.gs)
                blocks.removeAt(blocks.lastIndex)
            }
        }
        return blocks.map { Block(it.text, it.gs.toList()) }
    }
}
