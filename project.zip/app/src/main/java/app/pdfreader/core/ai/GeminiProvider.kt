package app.pdfreader.core.ai

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject

class GeminiProvider : AiProvider {
    override val type = "gemini"

    private fun url(cfg: ProviderEntity, model: String) =
        cfg.baseUrl.trimEnd('/') + "/models/" + model + ":generateContent"

    private suspend fun call(cfg: ProviderEntity, model: String, key: String, body: JSONObject): JSONObject {
        val r = Http.postJson(url(cfg, model), mapOf("x-goog-api-key" to key), body.toString())
        if (r.code !in 200..299) throw Http.errorFor(r.code, r.text)
        return try {
            JSONObject(r.text)
        } catch (e: Exception) {
            throw AiException(AiErrorKind.EMPTY, "پاسخ نامعتبر از سرور")
        }
    }

    private fun parts(text: String?, extra: JSONObject? = null): JSONArray {
        val arr = JSONArray()
        if (text != null) arr.put(JSONObject().put("text", text))
        if (extra != null) arr.put(extra)
        return arr
    }

    private fun contents(p: JSONArray) = JSONArray().put(JSONObject().put("parts", p))

    private fun collectText(j: JSONObject): String {
        val ps = j.optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until ps.length()) sb.append(ps.optJSONObject(i)?.optString("text", "") ?: "")
        return sb.toString().trim()
    }

    override suspend fun text(
        cfg: ProviderEntity, model: String, key: String,
        prompt: String, temperature: Double, maxTokens: Int,
    ): String {
        val body = JSONObject()
            .put("contents", contents(parts(prompt)))
            .put("generationConfig", JSONObject().put("temperature", temperature).put("maxOutputTokens", maxTokens))
        val out = collectText(call(cfg, model, key, body))
        if (out.isBlank()) throw AiException(AiErrorKind.EMPTY, "پاسخ خالی از مدل")
        return out
    }

    override suspend fun vision(
        cfg: ProviderEntity, model: String, key: String, prompt: String, jpeg: ByteArray,
    ): String {
        val img = JSONObject().put(
            "inline_data",
            JSONObject().put("mime_type", "image/jpeg").put("data", Base64.encodeToString(jpeg, Base64.NO_WRAP))
        )
        val body = JSONObject()
            .put("contents", contents(parts(prompt, img)))
            .put("generationConfig", JSONObject().put("temperature", 0.1).put("maxOutputTokens", 16384))
        val out = collectText(call(cfg, model, key, body))
        if (out.isBlank()) throw AiException(AiErrorKind.EMPTY, "پاسخ خالی از مدل OCR")
        return out
    }

    override suspend fun speech(
        cfg: ProviderEntity, model: String, key: String, text: String, voice: String,
    ): ByteArray {
        val body = JSONObject()
            .put("contents", contents(parts(text)))
            .put(
                "generationConfig",
                JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put(
                        "speechConfig",
                        JSONObject().put(
                            "voiceConfig",
                            JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice))
                        )
                    )
            )
        val j = call(cfg, model, key, body)
        val ps = j.optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")
        var b64: String? = null
        if (ps != null) for (i in 0 until ps.length()) {
            val d = ps.optJSONObject(i)?.optJSONObject("inlineData")?.optString("data", "")
                ?: ps.optJSONObject(i)?.optJSONObject("inline_data")?.optString("data", "")
            if (!d.isNullOrEmpty()) { b64 = d; break }
        }
        if (b64 == null) throw AiException(AiErrorKind.EMPTY, "پاسخ بدون صدا")
        val raw = Base64.decode(b64, Base64.DEFAULT)
        return if (Wav.isRiff(raw)) raw else Wav.fromPcm16(raw, 24000)
    }
}
