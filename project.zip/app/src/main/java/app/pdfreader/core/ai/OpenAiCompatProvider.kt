package app.pdfreader.core.ai

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject

/** Any OpenAI-compatible endpoint: the user supplies Base URL, key and model names. */
class OpenAiCompatProvider : AiProvider {
    override val type = "openai"

    private fun headers(key: String) = mapOf("Authorization" to "Bearer $key")

    private suspend fun chat(cfg: ProviderEntity, key: String, body: JSONObject): String {
        val r = Http.postJson(cfg.baseUrl.trimEnd('/') + "/chat/completions", headers(key), body.toString())
        if (r.code !in 200..299) throw Http.errorFor(r.code, r.text)
        val out = try {
            JSONObject(r.text).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").optString("content", "")
        } catch (e: Exception) {
            ""
        }.trim()
        if (out.isBlank()) throw AiException(AiErrorKind.EMPTY, "پاسخ خالی از مدل")
        return out
    }

    override suspend fun text(
        cfg: ProviderEntity, model: String, key: String,
        prompt: String, temperature: Double, maxTokens: Int,
    ): String = chat(
        cfg, key,
        JSONObject().put("model", model).put("temperature", temperature).put("max_tokens", maxTokens)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
    )

    override suspend fun vision(
        cfg: ProviderEntity, model: String, key: String, prompt: String, jpeg: ByteArray,
    ): String {
        val url = "data:image/jpeg;base64," + Base64.encodeToString(jpeg, Base64.NO_WRAP)
        val content = JSONArray()
            .put(JSONObject().put("type", "text").put("text", prompt))
            .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", url)))
        return chat(
            cfg, key,
            JSONObject().put("model", model).put("temperature", 0.1).put("max_tokens", 8192)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
        )
    }

    override suspend fun speech(
        cfg: ProviderEntity, model: String, key: String, text: String, voice: String,
    ): ByteArray {
        val body = JSONObject().put("model", model).put("input", text).put("voice", voice)
            .put("response_format", "wav")
        val r = Http.postJson(cfg.baseUrl.trimEnd('/') + "/audio/speech", headers(key), body.toString())
        if (r.code !in 200..299) throw Http.errorFor(r.code, r.text)
        if (r.bytes.isEmpty()) throw AiException(AiErrorKind.EMPTY, "پاسخ بدون صدا")
        return r.bytes
    }
}
