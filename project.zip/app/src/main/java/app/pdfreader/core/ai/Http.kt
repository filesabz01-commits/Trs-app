package app.pdfreader.core.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL

class HttpResult(val code: Int, val bytes: ByteArray) {
    val text: String get() = String(bytes, Charsets.UTF_8)
}

object Http {
    suspend fun postJson(
        url: String,
        headers: Map<String, String>,
        body: String,
        readTimeoutMs: Int = 90_000,
    ): HttpResult = withContext(Dispatchers.IO) {
        var conn: HttpURLConnection? = null
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            conn = c
            c.requestMethod = "POST"
            c.connectTimeout = 20_000
            c.readTimeout = readTimeoutMs
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val bytes = stream?.use { it.readBytes() } ?: ByteArray(0)
            HttpResult(code, bytes)
        } catch (e: SocketTimeoutException) {
            throw AiException(AiErrorKind.TIMEOUT, "زمان پاسخ‌گویی سرور تمام شد")
        } catch (e: IOException) {
            throw AiException(AiErrorKind.NETWORK, "اینترنت یا شبکه قطع است")
        } finally {
            conn?.disconnect()
        }
    }

    /** Turns a non-2xx response into a typed error. Quota state comes only from real provider errors. */
    fun errorFor(code: Int, raw: String): AiException {
        val msg = try {
            JSONObject(raw).getJSONObject("error").optString("message", "")
        } catch (e: Exception) {
            ""
        }.ifBlank { "HTTP $code" }
        val retry = Regex("\"retryDelay\":\\s*\"(\\d+)").find(raw)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        val daily = Regex("PerDay|per day|daily", RegexOption.IGNORE_CASE).containsMatchIn(raw)
        val invalid = code == 401 || code == 403 ||
            Regex("API key not valid|API_KEY_INVALID|API key expired|invalid_api_key|Incorrect API key", RegexOption.IGNORE_CASE)
                .containsMatchIn(raw)
        val kind = when {
            code == 429 && daily -> AiErrorKind.DAILY_QUOTA
            code == 429 -> AiErrorKind.RATE_LIMIT
            code == 402 -> AiErrorKind.DAILY_QUOTA
            invalid -> AiErrorKind.INVALID_KEY
            code == 404 -> AiErrorKind.MODEL_NOT_FOUND
            code == 400 -> AiErrorKind.BAD_REQUEST
            code >= 500 -> AiErrorKind.SERVER
            else -> AiErrorKind.OTHER
        }
        return AiException(kind, msg, retry, code)
    }
}
