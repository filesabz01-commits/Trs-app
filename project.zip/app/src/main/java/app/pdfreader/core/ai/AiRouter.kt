package app.pdfreader.core.ai

import kotlinx.coroutines.delay
import java.time.LocalDate

/**
 * Smart router: provider -> model -> key. Quota/limit state changes only on real provider errors
 * (429, "per day" bodies, 401...), never from local guesses.
 */
class AiRouter(
    private val dao: AiDao,
    private val settings: AiSettings,
    private val impls: Map<String, AiProvider>,
) {
    private suspend fun orderedProviders(cap: Capability): List<ProviderEntity> {
        val all = dao.providers().filter { it.enabled }
        val pref = settings.preferredProvider(cap)
        return if (pref.isEmpty()) all else all.sortedBy { if (it.id == pref) 0 else 1 }
    }

    private suspend fun cooldown(p: String, key: String, model: String, status: KeyStatus, ms: Long) {
        dao.upsertCooldown(CooldownEntity(p, key, model, System.currentTimeMillis() + ms, status.name))
    }

    suspend fun <T> run(
        cap: Capability,
        call: suspend (AiProvider, ProviderEntity, String, String) -> T,
    ): T {
        var lastError: AiException? = null
        var minWait = Long.MAX_VALUE
        for (round in 0..1) {
            minWait = Long.MAX_VALUE
            for (p in orderedProviders(cap)) {
                val impl = impls[p.type] ?: continue
                val models = dao.models(p.id).filter { m ->
                    m.enabled && m.capabilities.split(',').contains(cap.name)
                }
                val keys = dao.keys(p.id).filter {
                    it.status != KeyStatus.INVALID.name && it.status != KeyStatus.DISABLED.name
                }
                for (m in models) {
                    for (k in keys) {
                        val now = System.currentTimeMillis()
                        val cd = dao.cooldownFor(p.id, k.id, m.modelId, now)
                        if (cd != null) {
                            minWait = minOf(minWait, cd.until - now)
                            continue
                        }
                        val secret = try {
                            KeyCrypto.decrypt(k.secret)
                        } catch (e: Exception) {
                            dao.setKeyStatus(k.id, KeyStatus.INVALID.name, "کلید قابل رمزگشایی نیست؛ دوباره وارد کنید")
                            continue
                        }
                        var tries = 0
                        while (true) {
                            try {
                                val out = call(impl, p, m.modelId, secret)
                                dao.bump(LocalDate.now().toString(), p.id, cap.name, 1, 0)
                                return out
                            } catch (e: AiException) {
                                lastError = e
                                dao.bump(LocalDate.now().toString(), p.id, cap.name, 1, 1)
                                when (e.kind) {
                                    AiErrorKind.INVALID_KEY -> {
                                        dao.setKeyStatus(k.id, KeyStatus.INVALID.name, e.message)
                                        break
                                    }
                                    AiErrorKind.DAILY_QUOTA -> {
                                        cooldown(p.id, k.id, m.modelId, KeyStatus.DAILY_QUOTA_EXCEEDED, 6 * 3600_000L)
                                        break
                                    }
                                    AiErrorKind.RATE_LIMIT -> {
                                        val s = maxOf(e.retryAfterSec, 20)
                                        cooldown(p.id, k.id, m.modelId, KeyStatus.RATE_LIMITED, s * 1000L)
                                        break
                                    }
                                    AiErrorKind.MODEL_NOT_FOUND -> {
                                        cooldown(p.id, "*", m.modelId, KeyStatus.TEMPORARILY_UNAVAILABLE, 24 * 3600_000L)
                                        break
                                    }
                                    AiErrorKind.BAD_REQUEST -> {
                                        cooldown(p.id, "*", m.modelId, KeyStatus.TEMPORARILY_UNAVAILABLE, 10 * 60_000L)
                                        break
                                    }
                                    AiErrorKind.UNSUPPORTED -> break
                                    AiErrorKind.SERVER, AiErrorKind.TIMEOUT, AiErrorKind.NETWORK, AiErrorKind.EMPTY -> {
                                        if (tries < 2) {
                                            tries++
                                            delay(1000L shl tries) // exponential backoff: 2s, 4s
                                        } else {
                                            cooldown(p.id, k.id, m.modelId, KeyStatus.TEMPORARILY_UNAVAILABLE, 2 * 60_000L)
                                            break
                                        }
                                    }
                                    else -> {
                                        cooldown(p.id, k.id, m.modelId, KeyStatus.TEMPORARILY_UNAVAILABLE, 2 * 60_000L)
                                        break
                                    }
                                }
                            }
                        }
                    }
                }
            }
            // Only wait and retry once if a cooldown is about to end.
            if (round == 0 && minWait in 1..25_000L) delay(minWait + 300) else break
        }
        val le = lastError
        if (le != null) throw AiException(le.kind, le.message ?: "خطا", le.retryAfterSec, le.httpStatus)
        if (minWait != Long.MAX_VALUE) {
            throw AiException(
                AiErrorKind.RATE_LIMIT,
                "همه‌ی مسیرها موقتاً در cooldown هستند (حدود ${minWait / 1000} ثانیه)"
            )
        }
        throw AiException(
            AiErrorKind.NO_ROUTE,
            "برای این قابلیت (${cap.name}) هیچ ارائه‌دهنده، مدل و کلید فعالی تنظیم نشده است. از تنظیمات اضافه کنید."
        )
    }

    /** Connection test for one specific key; marks the key INVALID only on a real auth error. */
    suspend fun testKey(provider: ProviderEntity, key: KeyEntity): String {
        val impl = impls[provider.type] ?: return "نوع ارائه‌دهنده پشتیبانی نمی‌شود"
        val model = dao.models(provider.id).firstOrNull { it.enabled && it.capabilities.split(',').contains("TEXT") }
            ?: return "هیچ مدل متنی برای این ارائه‌دهنده تعریف نشده است"
        val secret = try { KeyCrypto.decrypt(key.secret) } catch (e: Exception) { return "کلید قابل رمزگشایی نیست" }
        return try {
            impl.text(provider, model.modelId, secret, "Reply with the single word: OK", 0.0, 16)
            dao.setKeyStatus(key.id, KeyStatus.ACTIVE.name, null)
            dao.deleteCooldownsOfKey(key.id)
            "اتصال موفق بود (${model.modelId})"
        } catch (e: AiException) {
            if (e.kind == AiErrorKind.INVALID_KEY) dao.setKeyStatus(key.id, KeyStatus.INVALID.name, e.message)
            when (e.kind) {
                AiErrorKind.INVALID_KEY -> "کلید نامعتبر است: ${e.message}"
                AiErrorKind.RATE_LIMIT, AiErrorKind.DAILY_QUOTA -> "کلید معتبر است ولی سقف مصرف پر شده: ${e.message}"
                AiErrorKind.MODEL_NOT_FOUND -> "مدل ${model.modelId} پیدا نشد: ${e.message}"
                else -> "خطا: ${e.message}"
            }
        }
    }
}
