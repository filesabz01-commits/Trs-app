package app.pdfreader.core.ai

import android.content.Context

enum class ReadingProfile(val label: String) {
    GENERAL("عمومی"), TECHNICAL("فنی / مهندسی"), ACADEMIC("آکادمیک"),
    MEDICAL("پزشکی"), LITERATURE("ادبیات"), CUSTOM("سفارشی")
}

class AiSettings(ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private fun str(k: String, d: String) = sp.getString(k, d) ?: d
    private fun bool(k: String, d: Boolean) = sp.getBoolean(k, d)

    var targetLang: String
        get() = str("targetLang", "Persian"); set(v) = sp.edit().putString("targetLang", v).apply()
    var readMode: String // ORIGINAL | TRANSLATE | BILINGUAL
        get() = str("readMode", "ORIGINAL"); set(v) = sp.edit().putString("readMode", v).apply()
    var profile: ReadingProfile
        get() = try { ReadingProfile.valueOf(str("profile", "TECHNICAL")) } catch (e: Exception) { ReadingProfile.TECHNICAL }
        set(v) = sp.edit().putString("profile", v.name).apply()
    var customInstruction: String
        get() = str("customInstruction", ""); set(v) = sp.edit().putString("customInstruction", v).apply()
    var glossary: String
        get() = str("glossary", ""); set(v) = sp.edit().putString("glossary", v).apply()
    var pron: String
        get() = str("pron", DEFAULT_PRON); set(v) = sp.edit().putString("pron", v).apply()
    var voice: String
        get() = str("voice", "Kore"); set(v) = sp.edit().putString("voice", v).apply()
    var openaiVoice: String
        get() = str("openaiVoice", "alloy"); set(v) = sp.edit().putString("openaiVoice", v).apply()
    var speed: Float
        get() = sp.getFloat("speed", 1f); set(v) = sp.edit().putFloat("speed", v).apply()
    var blockSize: Int
        get() = sp.getInt("blockSize", 1500); set(v) = sp.edit().putInt("blockSize", v).apply()
    var prefetch: Boolean
        get() = bool("prefetch", true); set(v) = sp.edit().putBoolean("prefetch", v).apply()
    var autoOcr: Boolean
        get() = bool("autoOcr", true); set(v) = sp.edit().putBoolean("autoOcr", v).apply()
    var cleanText: Boolean
        get() = bool("cleanText", true); set(v) = sp.edit().putBoolean("cleanText", v).apply()
    var autoNextPage: Boolean
        get() = bool("autoNextPage", true); set(v) = sp.edit().putBoolean("autoNextPage", v).apply()
    var systemTtsFallback: Boolean
        get() = bool("systemTtsFallback", false); set(v) = sp.edit().putBoolean("systemTtsFallback", v).apply()
    var persianBook: Boolean
        get() = bool("persianBook", false); set(v) = sp.edit().putBoolean("persianBook", v).apply()
    var forceOcrPersian: Boolean
        get() = bool("forceOcrPersian", false); set(v) = sp.edit().putBoolean("forceOcrPersian", v).apply()

    /** Empty string = automatic (follow the provider order). */
    fun preferredProvider(cap: Capability): String = str("pref_" + cap.name, "")
    fun setPreferredProvider(cap: Capability, id: String) = sp.edit().putString("pref_" + cap.name, id).apply()

    fun voiceFor(providerType: String): String = if (providerType == "openai") openaiVoice else voice

    fun pronMap(): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        pron.lines().forEach { ln ->
            val i = ln.indexOf('=')
            if (i >= 1) {
                val k = ln.substring(0, i).trim()
                val v = ln.substring(i + 1).trim()
                if (k.isNotEmpty() && v.isNotEmpty()) m[k] = v
            }
        }
        return m
    }

    fun savePos(docKey: String, page: Int, idx: Int) =
        sp.edit().putString("pos_$docKey", "$page,$idx").apply()

    fun getPos(docKey: String): Pair<Int, Int>? {
        val s = sp.getString("pos_$docKey", null) ?: return null
        val p = s.split(',')
        if (p.size != 2) return null
        val a = p[0].toIntOrNull() ?: return null
        val b = p[1].toIntOrNull() ?: return null
        return a to b
    }

    companion object {
        val GEMINI_VOICES = listOf("Kore", "Puck", "Charon", "Fenrir", "Aoede", "Leda", "Orus", "Zephyr")
        const val DEFAULT_PRON = """P&ID = P I D
P&IDs = P I Ds
PFD = P F D
BFD = B F D
UFD = U F D
HAZOP = HAZ-OP
ESD = E S D
PSV = P S V
NPSH = N P S H
DCS = D C S
PLC = P L C
ISA = I S A
API = A P I
ASME = A S M E
ANSI = A N S I
ASTM = A S T M
barg = bar gauge
kg/h = kilograms per hour
°C = degrees Celsius
± = plus or minus
~ = approximately"""
    }
}
