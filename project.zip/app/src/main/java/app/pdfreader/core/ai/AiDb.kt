package app.pdfreader.core.ai

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "providers")
data class ProviderEntity(
    @androidx.room.PrimaryKey val id: String,
    val type: String,          // "gemini" | "openai"
    val name: String,
    val baseUrl: String,
    val enabled: Boolean = true,
    val sortOrder: Int = 0,
)

@Entity(tableName = "models", primaryKeys = ["providerId", "modelId"])
data class ModelEntity(
    val providerId: String,
    val modelId: String,
    val capabilities: String,  // comma separated Capability names
    val sortOrder: Int = 0,
    val enabled: Boolean = true,
)

@Entity(tableName = "api_keys")
data class KeyEntity(
    @androidx.room.PrimaryKey val id: String,
    val providerId: String,
    val label: String,
    val secret: String,        // AES-GCM (Android Keystore) + Base64, never plain text
    val status: String = "ACTIVE", // ACTIVE | INVALID | DISABLED (cooldowns are separate)
    val lastError: String? = null,
    val sortOrder: Int = 0,
)

@Entity(tableName = "cooldowns", primaryKeys = ["providerId", "keyId", "modelId"])
data class CooldownEntity(
    val providerId: String,
    val keyId: String,         // "*" = all keys of the provider
    val modelId: String,
    val until: Long,
    val reason: String,        // KeyStatus name
)

@Entity(tableName = "usage", primaryKeys = ["day", "providerId", "kind"])
data class UsageEntity(
    val day: String,
    val providerId: String,
    val kind: String,
    val requests: Int,
    val errors: Int,
)

@Entity(tableName = "cache")
data class CacheEntity(
    @androidx.room.PrimaryKey val key: String,
    val value: String,
    val createdAt: Long,
)

@Dao
abstract class AiDao {
    @Query("SELECT * FROM providers ORDER BY sortOrder, id")
    abstract fun observeProviders(): Flow<List<ProviderEntity>>

    @Query("SELECT * FROM providers ORDER BY sortOrder, id")
    abstract suspend fun providers(): List<ProviderEntity>

    @Upsert abstract suspend fun upsertProvider(p: ProviderEntity)

    @Query("DELETE FROM providers WHERE id = :id") abstract suspend fun deleteProvider(id: String)

    @Query("SELECT * FROM models ORDER BY providerId, sortOrder, modelId")
    abstract fun observeModels(): Flow<List<ModelEntity>>

    @Query("SELECT * FROM models WHERE providerId = :pid ORDER BY sortOrder, modelId")
    abstract suspend fun models(pid: String): List<ModelEntity>

    @Upsert abstract suspend fun upsertModel(m: ModelEntity)

    @Query("DELETE FROM models WHERE providerId = :pid AND modelId = :mid")
    abstract suspend fun deleteModel(pid: String, mid: String)

    @Query("DELETE FROM models WHERE providerId = :pid") abstract suspend fun deleteModelsOf(pid: String)

    @Query("SELECT * FROM api_keys ORDER BY providerId, sortOrder, id")
    abstract fun observeKeys(): Flow<List<KeyEntity>>

    @Query("SELECT * FROM api_keys WHERE providerId = :pid ORDER BY sortOrder, id")
    abstract suspend fun keys(pid: String): List<KeyEntity>

    @Upsert abstract suspend fun upsertKey(k: KeyEntity)

    @Query("DELETE FROM api_keys WHERE id = :id") abstract suspend fun deleteKey(id: String)

    @Query("DELETE FROM api_keys WHERE providerId = :pid") abstract suspend fun deleteKeysOf(pid: String)

    @Query("UPDATE api_keys SET status = :status, lastError = :err WHERE id = :id")
    abstract suspend fun setKeyStatus(id: String, status: String, err: String?)

    @Query("SELECT * FROM cooldowns")
    abstract fun observeCooldowns(): Flow<List<CooldownEntity>>

    @Query(
        "SELECT * FROM cooldowns WHERE providerId = :pid AND modelId = :mid AND until > :now " +
            "AND (keyId = :kid OR keyId = '*') ORDER BY until DESC LIMIT 1"
    )
    abstract suspend fun cooldownFor(pid: String, kid: String, mid: String, now: Long): CooldownEntity?

    @Upsert abstract suspend fun upsertCooldown(c: CooldownEntity)

    @Query("DELETE FROM cooldowns WHERE keyId = :kid") abstract suspend fun deleteCooldownsOfKey(kid: String)

    @Query("DELETE FROM cooldowns") abstract suspend fun clearCooldowns()

    @Query("SELECT * FROM usage WHERE day = :day")
    abstract fun observeUsage(day: String): Flow<List<UsageEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE) abstract suspend fun insertUsage(u: UsageEntity)

    @Query(
        "UPDATE usage SET requests = requests + :r, errors = errors + :e " +
            "WHERE day = :day AND providerId = :pid AND kind = :kind"
    )
    abstract suspend fun addUsage(day: String, pid: String, kind: String, r: Int, e: Int)

    @Transaction
    open suspend fun bump(day: String, pid: String, kind: String, r: Int, e: Int) {
        insertUsage(UsageEntity(day, pid, kind, 0, 0))
        addUsage(day, pid, kind, r, e)
    }

    @Query("SELECT * FROM cache WHERE `key` = :key") abstract suspend fun getCache(key: String): CacheEntity?

    @Upsert abstract suspend fun putCache(c: CacheEntity)

    @Query("SELECT COALESCE(SUM(LENGTH(value)), 0) FROM cache") abstract suspend fun cacheBytes(): Long

    @Query("DELETE FROM cache") abstract suspend fun clearCache()
}

@Database(
    entities = [
        ProviderEntity::class, ModelEntity::class, KeyEntity::class,
        CooldownEntity::class, UsageEntity::class, CacheEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
abstract class AiDatabase : RoomDatabase() {
    abstract fun dao(): AiDao
}
