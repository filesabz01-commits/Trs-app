package app.pdfreader.core.pdf

import android.graphics.Bitmap
import android.net.Uri

enum class PdfError { ENCRYPTED, CORRUPT, UNREADABLE }

sealed interface PdfOpenResult {
    class Ok(val doc: PdfDocument) : PdfOpenResult
    class Error(val kind: PdfError, val detail: String?) : PdfOpenResult
}

/** A single open PDF. Implementations must be safe to call from any coroutine. */
interface PdfDocument : AutoCloseable {
    val pageCount: Int
    /** height / width of the page. */
    suspend fun pageAspect(index: Int): Float
    suspend fun render(index: Int, widthPx: Int): Bitmap
}

/** The reader only talks to this interface, so the engine can be swapped (e.g. PDFium) later. */
interface PdfEngine {
    suspend fun open(uri: Uri): PdfOpenResult
}
