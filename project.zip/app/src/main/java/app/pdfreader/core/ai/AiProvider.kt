package app.pdfreader.core.ai

/** Generic provider contract. Nothing outside the implementations knows Gemini or OpenAI exist. */
interface AiProvider {
    val type: String

    suspend fun text(
        cfg: ProviderEntity, model: String, key: String,
        prompt: String, temperature: Double, maxTokens: Int,
    ): String

    suspend fun vision(
        cfg: ProviderEntity, model: String, key: String,
        prompt: String, jpeg: ByteArray,
    ): String

    /** Returns audio bytes, WAV (RIFF) whenever the provider allows it. */
    suspend fun speech(
        cfg: ProviderEntity, model: String, key: String,
        text: String, voice: String,
    ): ByteArray
}

object Wav {
    fun isRiff(b: ByteArray): Boolean =
        b.size > 12 && b[0] == 'R'.code.toByte() && b[1] == 'I'.code.toByte() &&
            b[2] == 'F'.code.toByte() && b[3] == 'F'.code.toByte()

    fun fromPcm16(pcm: ByteArray, sampleRate: Int = 24000): ByteArray {
        val len = pcm.size
        val out = java.nio.ByteBuffer.allocate(44 + len).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        out.put("RIFF".toByteArray()); out.putInt(36 + len); out.put("WAVE".toByteArray())
        out.put("fmt ".toByteArray()); out.putInt(16); out.putShort(1); out.putShort(1)
        out.putInt(sampleRate); out.putInt(sampleRate * 2); out.putShort(2); out.putShort(16)
        out.put("data".toByteArray()); out.putInt(len); out.put(pcm)
        return out.array()
    }

    fun durationSec(wav: ByteArray): Double = maxOf(0, wav.size - 44) / 48000.0

    fun concat(parts: List<ByteArray>): ByteArray {
        val len = parts.sumOf { it.size - 44 }
        val out = java.nio.ByteBuffer.allocate(44 + len).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        out.put(parts[0], 0, 44)
        parts.forEach { out.put(it, 44, it.size - 44) }
        out.putInt(4, 36 + len); out.putInt(40, len)
        return out.array()
    }
}
