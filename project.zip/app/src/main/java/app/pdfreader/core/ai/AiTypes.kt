package app.pdfreader.core.ai

enum class Capability { TEXT, VISION, TTS }

enum class AiErrorKind {
    RATE_LIMIT, DAILY_QUOTA, INVALID_KEY, MODEL_NOT_FOUND, BAD_REQUEST,
    TIMEOUT, NETWORK, SERVER, EMPTY, UNSUPPORTED, NO_ROUTE, OTHER
}

class AiException(
    val kind: AiErrorKind,
    message: String,
    val retryAfterSec: Int = 0,
    val httpStatus: Int = 0,
) : Exception(message)

enum class KeyStatus {
    ACTIVE, RATE_LIMITED, DAILY_QUOTA_EXCEEDED, INVALID, TEMPORARILY_UNAVAILABLE, DISABLED
}
