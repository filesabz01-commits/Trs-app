package app.pdfreader

import android.app.Application
import android.content.Context
import androidx.room.Room
import app.pdfreader.core.pdf.PdfEngine
import app.pdfreader.core.pdf.PdfRendererEngine
import app.pdfreader.ai.AiDatabase
import app.pdfreader.ai.AiRouter
import app.pdfreader.ai.MIGRATION_1_2
import app.pdfreader.ai.GeminiProvider
import app.pdfreader.ai.OpenAiCompatProvider
import app.pdfreader.ai.PageTextService
import app.pdfreader.tts.ReadAloudController
import app.pdfreader.ai.ProviderTypes
import app.pdfreader.ai.SettingsRepo
import app.pdfreader.data.AppDatabase

class AppContainer(context: Context) {
    val db: AppDatabase =
        Room.databaseBuilder(context, AppDatabase::class.java, "reader.db").build()
    val engine: PdfEngine = PdfRendererEngine(context)

    val aiDb: AiDatabase = Room.databaseBuilder(context, AiDatabase::class.java, "ai.db").addMigrations(MIGRATION_1_2).build()
    val aiDao = aiDb.aiDao()
    val settings = SettingsRepo(context)
    val router = AiRouter(
        aiDao,
        mapOf(ProviderTypes.GEMINI to GeminiProvider(), ProviderTypes.OPENAI to OpenAiCompatProvider()),
    )
    val pageText = PageTextService(aiDao, router)
    val readAloud = ReadAloudController(context, router, pageText, settings)
}

class ReaderApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
