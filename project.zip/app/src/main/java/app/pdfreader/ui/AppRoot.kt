package app.pdfreader.ui

import app.pdfreader.ReaderApp
import androidx.compose.runtime.remember
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import app.pdfreader.R

@Composable
fun AppRoot(vm: AppViewModel) {
    val context = LocalContext.current
    val aiVm: AiViewModel = viewModel()
    val reader by vm.reader.collectAsStateWithLifecycle()
    val docs by vm.documents.collectAsStateWithLifecycle()
    val handouts by aiVm.handouts.collectAsStateWithLifecycle()
    val ai by aiVm.ui.collectAsStateWithLifecycle()
    val rs by aiVm.settings.collectAsStateWithLifecycle()
    val readCtrl = remember { (context.applicationContext as ReaderApp).container.readAloud }
    var screen by rememberSaveable { mutableStateOf("library") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // ignore: still readable for this session
            }
            vm.openDocument(uri)
        }
    }

    // If AI result / loading sheet is open, system Back only closes it — stay on the book page.
    BackHandler(enabled = reader !is ReaderState.Closed && ai !is AiUi.Idle) {
        if (ai is AiUi.Loading || ai is AiUi.Streaming) aiVm.cancelTask()
        else aiVm.dismissResult()
    }
    BackHandler(enabled = reader !is ReaderState.Closed && ai is AiUi.Idle) {
        readCtrl.stop()
        aiVm.dismissResult()
        vm.closeReader()
    }
    BackHandler(enabled = reader is ReaderState.Closed && screen == "usage") { screen = "settings" }
    BackHandler(enabled = reader is ReaderState.Closed && screen == "settings") { screen = "library" }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        when (val r = reader) {
            ReaderState.Closed -> when (screen) {
                "settings" -> SettingsScreen(aiVm, onBack = { screen = "library" }, onUsage = { screen = "usage" })
                "usage" -> UsageScreen(aiVm, onBack = { screen = "settings" })
                else -> LibraryScreen(
                    docs = docs,
                    handouts = handouts,
                    onOpenPicker = { picker.launch(arrayOf("application/pdf")) },
                    onOpen = { vm.openDocument(Uri.parse(it.uri)) },
                    onToggleFavorite = vm::toggleFavorite,
                    onRemove = vm::removeFromList,
                    onDeleteHandout = aiVm::deleteHandout,
                    onOpenHandout = { h ->
                        try {
                            val f = java.io.File(h.pdfPath)
                            if (f.exists()) {
                                val uri = androidx.core.content.FileProvider.getUriForFile(
                                    context, context.packageName + ".files", f
                                )
                                vm.openDocument(uri)
                            }
                        } catch (_: Exception) {}
                    },
                    onOpenSettings = { screen = "settings" },
                    onOpenUsage = { screen = "usage" },
                )
            }
            ReaderState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    CircularProgressIndicator()
                    Text(stringResource(R.string.opening))
                }
            }
            is ReaderState.Error -> Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text(stringResource(r.message), textAlign = TextAlign.Center)
                    Button(onClick = vm::closeReader) { Text(stringResource(R.string.back)) }
                }
            }
            is ReaderState.Open -> ReaderScreen(
                state = r,
                favorite = docs.firstOrNull { it.uri == r.uri }?.favorite ?: false,
                onBack = {
                    readCtrl.stop()
                    aiVm.dismissResult()
                    vm.closeReader()
                },
                onToggleFavorite = { docs.firstOrNull { it.uri == r.uri }?.let(vm::toggleFavorite) },
                onProgress = { page, offset -> vm.saveProgress(r.uri, page, offset) },
                ai = ai,
                bilingual = rs.bilingual,
                onBilingual = aiVm::setBilingual,
                onAiTask = { task, page, force -> aiVm.runPageTask(r.doc, r.uri, page, task, force) },
                onRangeSummary = { f, t, force -> aiVm.runRangeSummary(r.doc, r.uri, f, t, force) },
                onAiDismiss = aiVm::dismissResult,
                onAiCancel = aiVm::cancelTask,
                onAiNextModel = aiVm::nextModel,
                onOpenSettings = {
                    readCtrl.stop()
                    aiVm.dismissResult()
                    vm.closeReader()
                    screen = "settings"
                },
            )
        }
    }
}
