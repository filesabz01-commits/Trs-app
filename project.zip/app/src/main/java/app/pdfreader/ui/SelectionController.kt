package app.pdfreader.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import app.pdfreader.tts.NRect
import app.pdfreader.tts.PageChars
import app.pdfreader.tts.PdfiumTextEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/** A selected range of characters [a]..[b] (inclusive) on one page. */
class Sel(val page: Int, val a: Int, val b: Int)

/** Pure helpers that turn character boxes into words, lines and text. */
object TextPick {
    /** The character nearest to the point (page fractions), or -1 when nothing is within [tol]. */
    fun charAt(pc: PageChars, nx: Float, ny: Float, tol: Float): Int {
        var best = -1
        var bestD = Float.MAX_VALUE
        for (i in pc.boxes.indices) {
            val r = pc.boxes[i] ?: continue
            if (r.r <= r.l && r.b <= r.t) continue
            val dx = when {
                nx < r.l -> r.l - nx
                nx > r.r -> nx - r.r
                else -> 0f
            }
            val dy = when {
                ny < r.t -> r.t - ny
                ny > r.b -> ny - r.b
                else -> 0f
            }
            val d = dx * dx + dy * dy
            if (d < bestD) {
                bestD = d
                best = i
                if (d == 0f) break
            }
        }
        return if (best >= 0 && bestD <= tol * tol) best else -1
    }

    /** The word (run of non-space characters) around character [i]. */
    fun word(pc: PageChars, i: Int): IntRange {
        val t = pc.text
        if (t.isEmpty()) return i..i
        var c = i.coerceIn(0, t.length - 1)
        if (t[c].isWhitespace()) {
            c = when {
                c + 1 < t.length && !t[c + 1].isWhitespace() -> c + 1
                c - 1 >= 0 && !t[c - 1].isWhitespace() -> c - 1
                else -> return c..c
            }
        }
        var s = c
        var e = c
        while (s > 0 && !t[s - 1].isWhitespace()) s--
        while (e < t.length - 1 && !t[e + 1].isWhitespace()) e++
        return s..e
    }

    /** One rectangle per text line covered by the range. */
    fun rects(pc: PageChars, a: Int, b: Int): List<NRect> {
        val out = ArrayList<NRect>()
        var l = 0f
        var t = 0f
        var r = 0f
        var bt = 0f
        var open = false
        val last = minOf(b, pc.boxes.size - 1)
        for (i in maxOf(a, 0)..last) {
            val x = pc.boxes[i] ?: continue
            val ch = pc.text.getOrNull(i)
            if (ch == '\n' || ch == '\r') continue
            if (!open) {
                l = x.l; t = x.t; r = x.r; bt = x.b
                open = true
                continue
            }
            val overlap = minOf(bt, x.b) - maxOf(t, x.t)
            val minH = minOf(bt - t, x.b - x.t)
            if (minH > 0f && overlap >= 0.5f * minH) {
                l = minOf(l, x.l); r = maxOf(r, x.r); t = minOf(t, x.t); bt = maxOf(bt, x.b)
            } else {
                out += NRect(l, t, r, bt)
                l = x.l; t = x.t; r = x.r; bt = x.b
            }
        }
        if (open) out += NRect(l, t, r, bt)
        return out
    }

    fun text(pc: PageChars, a: Int, b: Int): String {
        val len = pc.text.length
        val from = a.coerceIn(0, len)
        val to = (b + 1).coerceIn(from, len)
        return pc.text.substring(from, to).replace(Regex("\\s+"), " ").trim()
    }
}

/**
 * Text selection on the PDF pages: long-press selects a word, dragging extends the selection.
 * Page text positions are read once per page from the PDF's text layer (scanned PDFs have none).
 */
class SelectionController(
    private val engine: PdfiumTextEngine,
    private val uri: String,
    private val scope: CoroutineScope,
    private val onMessage: (String) -> Unit,
) {
    var sel by mutableStateOf<Sel?>(null)
        private set

    private val cache = HashMap<Int, PageChars?>() // main thread only
    private var anchorA = 0
    private var anchorB = 0
    private var loading = false

    private suspend fun chars(page: Int): PageChars? {
        if (cache.containsKey(page)) return cache[page]
        val pc = engine.pageChars(uri, page)
        if (pc != null) cache[page] = pc
        return pc
    }

    fun begin(page: Int, nx: Float, ny: Float) {
        if (loading) return
        loading = true
        scope.launch {
            try {
                val pc = chars(page)
                if (pc == null) {
                    onMessage(engine.lastError ?: "انتخاب متن برای این صفحه ممکن نیست")
                    return@launch
                }
                val i = TextPick.charAt(pc, nx, ny, 0.03f)
                if (i < 0) {
                    onMessage("برای انتخاب، روی خود متن نگه دارید")
                    return@launch
                }
                val w = TextPick.word(pc, i)
                anchorA = w.first
                anchorB = w.last
                sel = Sel(page, anchorA, anchorB)
            } finally {
                loading = false
            }
        }
    }

    fun extend(page: Int, nx: Float, ny: Float) {
        val cur = sel ?: return
        if (page != cur.page) return
        val pc = cache[page] ?: return
        val j = TextPick.charAt(pc, nx, ny, 0.06f)
        if (j < 0) return
        val a = minOf(anchorA, j)
        val b = maxOf(anchorB, j)
        if (a != cur.a || b != cur.b) sel = Sel(page, a, b)
    }

    fun clear() { sel = null }

    fun rects(): List<NRect> {
        val s = sel ?: return emptyList()
        val pc = cache[s.page] ?: return emptyList()
        return TextPick.rects(pc, s.a, s.b)
    }

    fun text(): String {
        val s = sel ?: return ""
        val pc = cache[s.page] ?: return ""
        return TextPick.text(pc, s.a, s.b)
    }
}
