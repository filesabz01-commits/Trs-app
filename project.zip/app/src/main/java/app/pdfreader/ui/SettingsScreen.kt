package app.pdfreader.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.pdfreader.ai.ApiKeyEntity
import app.pdfreader.ai.GeminiModels
import app.pdfreader.ai.Lang
import app.pdfreader.ai.Languages
import app.pdfreader.ai.KeyStatus
import app.pdfreader.ai.ProviderEntity
import app.pdfreader.ai.ProviderTypes
import app.pdfreader.ai.ReadingProfile
import app.pdfreader.ai.SecretBox

fun statusLabel(s: String) = when (s) {
    KeyStatus.ACTIVE.name -> "فعال"
    KeyStatus.RATE_LIMITED.name -> "محدودیت نرخ (rate limit)"
    KeyStatus.DAILY_QUOTA_EXCEEDED.name -> "سهمیه‌ی روزانه تمام شده"
    KeyStatus.INVALID.name -> "نامعتبر"
    KeyStatus.TEMPORARILY_UNAVAILABLE.name -> "موقتاً در دسترس نیست"
    KeyStatus.DISABLED.name -> "غیرفعال"
    else -> s
}

/** A cooldown that has already elapsed means the key is usable again. */
fun effectiveStatus(k: ApiKeyEntity, now: Long): String =
    if (k.cooldownUntil in 1..now &&
        (k.status == KeyStatus.RATE_LIMITED.name || k.status == KeyStatus.DAILY_QUOTA_EXCEEDED.name ||
            k.status == KeyStatus.TEMPORARILY_UNAVAILABLE.name)
    ) KeyStatus.ACTIVE.name else k.status

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: AiViewModel, onBack: () -> Unit, onUsage: () -> Unit) {
    val providers by vm.providers.collectAsStateWithLifecycle()
    val models by vm.models.collectAsStateWithLifecycle()
    val keys by vm.keys.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val cacheBytes by vm.cacheBytes.collectAsStateWithLifecycle()
    val tests by vm.testMessages.collectAsStateWithLifecycle()
    val audioBytes by vm.audioBytes.collectAsStateWithLifecycle()

    var addModelFor by remember { mutableStateOf<ProviderEntity?>(null) }
    var addKeyFor by remember { mutableStateOf<ProviderEntity?>(null) }
    var deleteProvider by remember { mutableStateOf<ProviderEntity?>(null) }
    var openLang by remember { mutableStateOf(true) }
    var openRead by remember { mutableStateOf(false) }
    var openProviders by remember { mutableStateOf(true) }
    var openStorage by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("تنظیمات") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت") }
                },
            )
        },
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                SettingsSectionHeader("زبان‌ها و مدل", openLang) { openLang = !openLang }
            }
            if (openLang) item {
                Text("زبان‌ها", style = MaterialTheme.typography.titleMedium)
                Text("زبان متن PDF", style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 8.dp))
                LangRow(selected = settings.sourceLanguage, options = Languages.all, onSelect = vm::setSourceLanguage)
                Text("زبان مقصد ترجمه و توضیح", style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 8.dp))
                LangRow(selected = settings.targetLanguage, options = Languages.targets, onSelect = vm::setTargetLanguage)
                Text(
                    "زبان رابط برنامه فعلاً فارسی است و مستقل از زبان PDF ثابت می‌ماند.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text("نوع متن", style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 12.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ReadingProfile.entries.forEach { p ->
                        FilterChip(selected = settings.profile == p, onClick = { vm.setProfile(p) }, label = { Text(p.label) })
                    }
                }
                if (settings.profile == ReadingProfile.CUSTOM) {
                    OutlinedTextField(
                        value = settings.customInstruction, onValueChange = vm::setCustomInstruction,
                        label = { Text("دستورالعمل دلخواه برای ترجمه/توضیح") },
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    )
                }
                Text("مدل", style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 12.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = settings.preferredModel.isBlank(), onClick = { vm.setPreferredModel("") },
                        label = { Text("خودکار (ترتیب پیش‌فرض)") },
                    )
                    GeminiModels.TEXT.forEach { m ->
                        FilterChip(
                            selected = settings.preferredModel == m, onClick = { vm.setPreferredModel(m) },
                            label = { Text(m.removePrefix("gemini-")) },
                        )
                    }
                }
                Text(
                    "مدل انتخاب‌شده اول امتحان می‌شود؛ اگر جواب نداد، به‌ترتیب سراغ بقیه‌ی مدل‌ها می‌رود. " +
                        "اگر سهمیه‌ی یک کلید تمام شد، کلید بعدی از اول با همین ترتیب امتحان می‌شود.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("ذخیره‌ی دائمی نتیجه‌ی OCR", style = MaterialTheme.typography.bodyLarge)
                        Text(
                            "پیش‌فرض خاموش: متن استخراج‌شده فقط تا بسته شدن برنامه نگه داشته می‌شود. ترجمه‌ها همیشه دائمی ذخیره می‌شوند.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(checked = settings.persistOcr, onCheckedChange = vm::setPersistOcr)
                }
                Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("نمایش متن اصلی کنار ترجمه (دوزبانه)", Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                    Switch(checked = settings.bilingual, onCheckedChange = vm::setBilingual)
                }
                Text("موتور خواندن صوتی", style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 12.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = settings.ttsEngine == "system",
                        onClick = { vm.setTtsEngine("system") },
                        label = { Text("سیستم آفلاین (رایگان)") },
                    )
                    FilterChip(
                        selected = settings.ttsEngine == "gemini",
                        onClick = { vm.setTtsEngine("gemini") },
                        label = { Text("Gemini هوش مصنوعی (طبیعی)") },
                    )
                }
                if (settings.ttsEngine == "gemini") {
                    Text("صدای خواندن", style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 8.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Kore", "Puck", "Charon", "Fenrir", "Aoede", "Leda", "Orus", "Zephyr").forEach { v ->
                            FilterChip(selected = settings.voice == v, onClick = { vm.setVoice(v) }, label = { Text(v) })
                        }
                    }
                }
            }
            item {
                SettingsSectionHeader("ارائه‌دهندگان AI و کلیدها", openProviders) { openProviders = !openProviders }
            }
            if (openProviders) {
                item {
                    Text(
                        "ترتیب لیست = ترتیب fallback. هر provider چند مدل و هر مدل از استخر کلیدهای همان provider استفاده می‌کند.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                items(providers, key = { it.id }) { p ->
                    ProviderCard(
                        p = p,
                        models = models.filter { it.providerId == p.id },
                        keys = keys.filter { it.providerId == p.id },
                        tests = tests, vm = vm,
                        onAddModel = { addModelFor = p }, onAddKey = { addKeyFor = p },
                        onDelete = { deleteProvider = p },
                    )
                }
            }
            item {
                SettingsSectionHeader("مصرف، کش و حریم خصوصی", openStorage) { openStorage = !openStorage }
            }
            if (openStorage) item {
                Text("حجم ترجمه‌ها و نتایج ذخیره‌شده: ${cacheBytes / 1024} کیلوبایت", style = MaterialTheme.typography.bodyMedium)
                Text("حجم فایل‌های صوتی ذخیره‌شده: ${"%.1f".format(audioBytes / 1048576.0)} مگابایت", style = MaterialTheme.typography.bodyMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = vm::clearCache) { Text("پاک کردن کش") }
                    TextButton(onClick = onUsage) { Text("داشبورد مصرف AI") }
                }
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                Text("حریم خصوصی", style = MaterialTheme.typography.titleSmall)
                Text(
                    "خواندن PDF کاملاً روی دستگاه انجام می‌شود. فقط وقتی ترجمه، توضیح، خلاصه یا استخراج متن را بزنید، " +
                        "تصویر همان یک صفحه برای provider انتخابی شما ارسال می‌شود، نه کل فایل. کلیدها با Android Keystore رمزنگاری می‌شوند.",
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }
    }

    addModelFor?.let { p ->
        AddModelDialog(onDismiss = { addModelFor = null }, onAdd = { n, t, v -> vm.addModel(p.id, n, t, v); addModelFor = null })
    }
    addKeyFor?.let { p ->
        AddKeyDialog(onDismiss = { addKeyFor = null }, onAdd = { l, s -> vm.addKey(p.id, l, s); addKeyFor = null })
    }
    deleteProvider?.let { p ->
        AlertDialog(
            onDismissRequest = { deleteProvider = null },
            title = { Text("حذف ${p.name}؟") },
            text = { Text("مدل‌ها و کلیدهای این provider هم حذف می‌شوند.") },
            confirmButton = { TextButton(onClick = { vm.deleteProvider(p); deleteProvider = null }) { Text("حذف") } },
            dismissButton = { TextButton(onClick = { deleteProvider = null }) { Text("انصراف") } },
        )
    }
}

@Composable
private fun ProviderCard(
    p: ProviderEntity,
    models: List<app.pdfreader.ai.ModelEntity>,
    keys: List<ApiKeyEntity>,
    tests: Map<String, String>,
    vm: AiViewModel,
    onAddModel: () -> Unit,
    onAddKey: () -> Unit,
    onDelete: () -> Unit,
) {
    var showModels by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(p.name, style = MaterialTheme.typography.titleMedium)
                    Text(ProviderTypes.label(p.type) + " · " + p.baseUrl, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = p.enabled, onCheckedChange = { vm.setProviderEnabled(p, it) })
            }
            Row {
                TextButton(onClick = { vm.moveProvider(p, -1) }) { Text("بالاتر") }
                TextButton(onClick = { vm.moveProvider(p, 1) }) { Text("پایین‌تر") }
                TextButton(onClick = onDelete) { Text("حذف") }
            }
            Text("مدل‌ها (${models.size}) — به ترتیب fallback", style = MaterialTheme.typography.labelLarge)
            TextButton(onClick = { showModels = !showModels }) { Text(if (showModels) "پنهان کردن فهرست" else "نمایش فهرست") }
            if (showModels) models.forEach { m ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(m.modelName)
                        Text(
                            listOfNotNull("متن".takeIf { m.supportsText }, "تصویر/OCR".takeIf { m.supportsVision }, "صدا".takeIf { m.supportsTts }).joinToString(" · "),
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    Switch(checked = m.enabled, onCheckedChange = { vm.setModelEnabled(m, it) })
                    TextButton(onClick = { vm.deleteModel(m) }) { Text("حذف") }
                }
            }
            TextButton(onClick = onAddModel) { Text("افزودن مدل") }
            Text("کلیدها", style = MaterialTheme.typography.labelLarge)
            keys.forEach { k -> KeyRow(k, tests[k.id], vm) }
            TextButton(onClick = onAddKey) { Text("افزودن کلید") }
        }
    }
}

@Composable
private fun KeyRow(k: ApiKeyEntity, testMessage: String?, vm: AiViewModel) {
    var reveal by remember { mutableStateOf(false) }
    val plain = remember(k.secret) { try { SecretBox.decrypt(k.secret) } catch (e: Exception) { "" } }
    val masked = if (plain.length > 8) "••••••••" + plain.takeLast(4) else "••••••••"
    val st = effectiveStatus(k, System.currentTimeMillis())
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text("${k.label} — ${statusLabel(st)}")
        Text(if (reveal) plain.ifEmpty { "(قابل نمایش نیست)" } else masked, style = MaterialTheme.typography.bodySmall)
        Row {
            TextButton(onClick = { reveal = !reveal }) { Text(if (reveal) "پنهان" else "نمایش") }
            TextButton(onClick = { vm.testKey(k) }) { Text("تست اتصال") }
            TextButton(onClick = { vm.setKeyDisabled(k, k.status != KeyStatus.DISABLED.name) }) {
                Text(if (k.status == KeyStatus.DISABLED.name) "فعال‌سازی" else "غیرفعال")
            }
            TextButton(onClick = { vm.deleteKey(k) }) { Text("حذف") }
        }
        if (testMessage != null) Text(testMessage, style = MaterialTheme.typography.bodySmall)
        HorizontalDivider()
    }
}

@Composable
private fun AddProviderDialog(onDismiss: () -> Unit, onAdd: (String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(ProviderTypes.OPENAI) }
    var url by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("provider جدید") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = type == ProviderTypes.GEMINI, onClick = { type = ProviderTypes.GEMINI }, label = { Text("Gemini") })
                    FilterChip(selected = type == ProviderTypes.OPENAI, onClick = { type = ProviderTypes.OPENAI }, label = { Text("سازگار با OpenAI") })
                }
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("نام") }, singleLine = true)
                OutlinedTextField(
                    value = url, onValueChange = { url = it }, singleLine = true,
                    label = { Text("Base URL") }, placeholder = { Text(ProviderTypes.defaultBaseUrl(type)) },
                )
            }
        },
        confirmButton = { TextButton(onClick = { onAdd(name, type, url) }) { Text("افزودن") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun AddModelDialog(onDismiss: () -> Unit, onAdd: (String, Boolean, Boolean) -> Unit) {
    var name by remember { mutableStateOf("") }
    var text by remember { mutableStateOf(true) }
    var vision by remember { mutableStateOf(true) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("مدل جدید") },
        text = {
            Column {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("نام دقیق مدل") }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = text, onCheckedChange = { text = it }); Text("متن")
                    Checkbox(checked = vision, onCheckedChange = { vision = it }); Text("تصویر")
                }
            }
        },
        confirmButton = { TextButton(onClick = { onAdd(name, text, vision) }) { Text("افزودن") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun AddKeyDialog(onDismiss: () -> Unit, onAdd: (String, String) -> Unit) {
    var label by remember { mutableStateOf("") }
    var secret by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("کلید API جدید") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = label, onValueChange = { label = it }, label = { Text("برچسب (اختیاری)") }, singleLine = true)
                OutlinedTextField(
                    value = secret, onValueChange = { secret = it }, label = { Text("کلید") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                )
            }
        },
        confirmButton = { TextButton(onClick = { onAdd(label, secret) }) { Text("افزودن") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun SettingsSectionHeader(title: String, expanded: Boolean, onToggle: () -> Unit) {
    Surface(
        onClick = onToggle,
        shape = RoundedCornerShape(12.dp),
        tonalElevation = 1.dp,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            Text(if (expanded) "▲" else "▼", style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
private fun LangRow(selected: String, options: List<Lang>, onSelect: (String) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        options.forEach { l ->
            FilterChip(selected = selected == l.code, onClick = { onSelect(l.code) }, label = { Text(l.label) })
        }
    }
}
