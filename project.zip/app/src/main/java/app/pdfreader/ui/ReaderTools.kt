package app.pdfreader.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp

class ToolItem(val icon: AppIcon, val label: String, val accent: Boolean = false, val onClick: () -> Unit)

/** The floating, rounded tool bar at the bottom of the reader. It hides itself; a tap on the page brings it back. */
@Composable
fun ReaderToolsBar(items: List<ToolItem>, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(34.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.97f),
        tonalElevation = 6.dp,
        shadowElevation = 14.dp,
    ) {
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            for (t in items) {
                val bg = if (t.accent) MaterialTheme.colorScheme.primary else androidx.compose.ui.graphics.Color.Transparent
                val fg = if (t.accent) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                Column(
                    Modifier.clip(RoundedCornerShape(24.dp)).background(bg).clickable(onClick = t.onClick).padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(3.dp),
                ) {
                    AppIconView(t.icon, fg, size = 24.dp)
                    Text(t.label, style = MaterialTheme.typography.labelSmall, color = fg, maxLines = 1)
                }
            }
        }
    }
}
