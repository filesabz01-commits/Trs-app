package app.pdfreader.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.pdfreader.ReaderApp
import app.pdfreader.tts.ReadAloudController
import app.pdfreader.tts.ReadState
import kotlinx.coroutines.delay

private val SPEEDS = floatArrayOf(0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)

private fun clock(ms: Long): String {
    val sec = (ms / 1000).coerceAtLeast(0)
    return String.format("%d:%02d", sec / 60, sec % 60)
}

@Composable
fun ReadAloudPanel(read: ReadState, ctrl: ReadAloudController, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val repo = remember { (context.applicationContext as ReaderApp).container.settings }
    val settings = repo.state.collectAsStateWithLifecycle().value

    val wantList = if (read.highlightPossible) settings.readText else !settings.hideFallbackText
    val listVisible = wantList && read.sentences.isNotEmpty()
    val onToggleText = {
        if (read.highlightPossible) repo.update { it.copy(readText = !it.readText) }
        else repo.update { it.copy(hideFallbackText = !it.hideFallbackText) }
    }

    var lastTouch by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var controlsVisible by remember { mutableStateOf(true) }

    LaunchedEffect(lastTouch, read.playing, read.error) {
        controlsVisible = true
        if (read.playing && read.error == null) {
            delay(5_000)
            controlsVisible = false
        }
    }

    val surfaceShown = controlsVisible || listVisible || read.error != null || read.status != null

    Column(modifier.fillMaxWidth()) {
        if (!controlsVisible) {
            // Collapsed round mini-fab in the bottom-end corner
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .then(if (surfaceShown) Modifier else Modifier.navigationBarsPadding())
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.End,
                ) {
                    FloatingActionButton(
                        onClick = { lastTouch = System.currentTimeMillis() },
                        modifier = Modifier.size(56.dp),
                        shape = CircleShape,
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    ) {
                        Text(if (read.playing) "⏸" else "▶", style = MaterialTheme.typography.titleLarge)
                    }
                }
            }
        }

        if (surfaceShown) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                tonalElevation = 6.dp,
                shadowElevation = 12.dp,
                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
            ) {
                Column(
                    Modifier
                        .pointerInput(Unit) {
                            awaitEachGesture {
                                awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                                lastTouch = System.currentTimeMillis()
                            }
                        }
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    val note = read.error ?: read.status
                    if (note != null) {
                        Text(
                            note,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (read.error != null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                        )
                    }

                    if (listVisible) SentenceList(read)

                    if (listVisible && !read.highlightPossible && read.highlightNote != null) {
                        Text(
                            read.highlightNote,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }

                    AnimatedVisibility(visible = controlsVisible, enter = fadeIn(), exit = fadeOut()) {
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Controls(read, ctrl, listVisible, onToggleText)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SentenceList(read: ReadState) {
    val listState = rememberLazyListState()
    LaunchedEffect(read.sentenceIndex) {
        if (read.sentenceIndex >= 0) {
            listState.animateScrollToItem((read.sentenceIndex - 1).coerceAtLeast(0))
        }
    }
    val dir = if (read.rtl) LayoutDirection.Rtl else LayoutDirection.Ltr
    CompositionLocalProvider(LocalLayoutDirection provides dir) {
        LazyColumn(
            Modifier
                .fillMaxWidth()
                .heightIn(max = 190.dp),
            state = listState,
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            itemsIndexed(read.sentences) { i, sentence ->
                val current = i == read.sentenceIndex
                Text(
                    sentence,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            if (current) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                            RoundedCornerShape(12.dp),
                        )
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    style = MaterialTheme.typography.bodyMedium.copy(
                        textDirection = if (read.rtl) TextDirection.Rtl else TextDirection.Ltr,
                        textAlign = TextAlign.Start,
                    ),
                    color = if (current) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun Controls(
    read: ReadState,
    ctrl: ReadAloudController,
    showText: Boolean,
    onToggleText: () -> Unit,
) {
    var drag by remember { mutableStateOf<Float?>(null) }
    val frac = if (read.durationMs > 0) (read.positionMs.toFloat() / read.durationMs).coerceIn(0f, 1f) else 0f

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            val sentenceCount = read.sentences.size
            val currentIdx = if (read.sentenceIndex >= 0) read.sentenceIndex + 1 else 0
            Text(
                if (sentenceCount > 0) "جمله $currentIdx از $sentenceCount" else "در حال خواندن…",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
            )
            TextButton(onClick = onToggleText) {
                Text(
                    if (showText) "پنهان کردن متن" else "نمایش متن جمله‌ها",
                    style = MaterialTheme.typography.labelMedium,
                )
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(clock(read.positionMs), style = MaterialTheme.typography.labelSmall)
            Slider(
                value = drag ?: frac,
                onValueChange = { drag = it },
                onValueChangeFinished = {
                    drag?.let { ctrl.seekToFraction(it) }
                    drag = null
                },
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 8.dp),
            )
            Text(clock(read.durationMs), style = MaterialTheme.typography.labelSmall)
        }

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = {
                val i = SPEEDS.indexOfFirst { it >= read.speed }.let { if (it < 0) 0 else it }
                ctrl.setSpeed(SPEEDS[(i + 1) % SPEEDS.size])
            }) {
                Text(
                    if (read.speed % 1f == 0f) "${read.speed.toInt()}×" else "${read.speed}×",
                    style = MaterialTheme.typography.labelLarge,
                )
            }
            TextButton(onClick = { ctrl.jumpSentence(-1) }) {
                Text("⏮", style = MaterialTheme.typography.titleLarge)
            }
            TextButton(onClick = { ctrl.seekBy(-5_000) }) {
                Text("−5s", style = MaterialTheme.typography.labelMedium)
            }
            FilledTonalButton(
                onClick = ctrl::toggle,
                shape = CircleShape,
                modifier = Modifier.size(54.dp),
            ) {
                Text(if (read.playing) "⏸" else "▶", style = MaterialTheme.typography.titleLarge)
            }
            TextButton(onClick = { ctrl.seekBy(5_000) }) {
                Text("+5s", style = MaterialTheme.typography.labelMedium)
            }
            TextButton(onClick = { ctrl.jumpSentence(1) }) {
                Text("⏭", style = MaterialTheme.typography.titleLarge)
            }
            IconButton(onClick = ctrl::stop) {
                Icon(Icons.Default.Close, contentDescription = "بستن")
            }
        }
    }
}