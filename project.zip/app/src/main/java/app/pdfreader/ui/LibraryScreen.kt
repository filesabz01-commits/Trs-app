package app.pdfreader.ui

import android.graphics.Bitmap
import android.text.format.DateUtils
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.Intent
import androidx.core.content.FileProvider
import app.pdfreader.R
import app.pdfreader.ReaderApp
import app.pdfreader.data.DocumentEntity
import app.pdfreader.data.HandoutEntity
import app.pdfreader.data.Thumbnails
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    docs: List<DocumentEntity>,
    handouts: List<HandoutEntity> = emptyList(),
    onOpenPicker: () -> Unit,
    onOpen: (DocumentEntity) -> Unit,
    onToggleFavorite: (DocumentEntity) -> Unit,
    onRemove: (DocumentEntity) -> Unit,
    onDeleteHandout: (HandoutEntity) -> Unit = {},
    onOpenHandout: (HandoutEntity) -> Unit = {},
    onOpenSettings: () -> Unit,
    onOpenUsage: () -> Unit = {},
) {
    val handoutsByDoc = remember(handouts) { handouts.groupBy { it.docUri } }
    // 0: اخیر (Recent), 1: قفسه (Shelf), 2: من (Me)
    var navTab by rememberSaveable { mutableIntStateOf(0) }
    var shelfFilter by rememberSaveable { mutableIntStateOf(0) } // 0: همه, 1: موردعلاقه‌ها

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        when (navTab) {
                            0 -> stringResource(R.string.app_name)
                            1 -> "قفسه کتاب‌ها"
                            else -> "نمایه من"
                        },
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    )
                },
                actions = {
                    if (navTab != 2) {
                        IconButton(onClick = onOpenSettings) {
                            Icon(Icons.Default.Settings, contentDescription = "تنظیمات")
                        }
                    }
                },
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
            ) {
                NavigationBarItem(
                    selected = navTab == 0,
                    onClick = { navTab = 0 },
                    icon = { AppIconView(AppIcon.Summary, tint = if (navTab == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, size = 22.dp) },
                    label = { Text("اخیر") },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                    ),
                )
                NavigationBarItem(
                    selected = navTab == 1,
                    onClick = { navTab = 1 },
                    icon = { AppIconView(AppIcon.Shelf, tint = if (navTab == 1) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, size = 22.dp) },
                    label = { Text("قفسه") },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                    ),
                )
                NavigationBarItem(
                    selected = navTab == 2,
                    onClick = { navTab = 2 },
                    icon = { AppIconView(AppIcon.Profile, tint = if (navTab == 2) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, size = 22.dp) },
                    label = { Text("من") },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                    ),
                )
            }
        },
        floatingActionButton = {
            if (navTab != 2) {
                ExtendedFloatingActionButton(
                    onClick = onOpenPicker,
                    icon = { Icon(Icons.Default.Add, contentDescription = null) },
                    text = { Text(stringResource(R.string.open_pdf)) },
                    shape = RoundedCornerShape(20.dp),
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                )
            }
        },
    ) { pad ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(pad),
        ) {
            when (navTab) {
                // ------------------ Tab 0: اخیر (Recent + Boox Continue Reading Hero Card)
                0 -> {
                    if (docs.isEmpty()) {
                        EmptyView("هنوز سندی باز نشده است.\nبرای شروع، یک فایل PDF انتخاب کنید.")
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            // Continue-reading hero; handouts are collapsible under each book (like DocRow)
                            item(key = "hero_continue_reading") {
                                val hero = docs.first()
                                Column {
                                    BooxHeroCard(hero, onOpen)
                                    CollapsibleHandouts(
                                        handouts = handoutsByDoc[hero.uri].orEmpty(),
                                        onDeleteHandout = onDeleteHandout,
                                        onOpenHandout = onOpenHandout,
                                        tintSurface = true,
                                    )
                                }
                            }

                            if (docs.size > 1) {
                                item {
                                    Text(
                                        "سایر کتاب‌ها و اسناد",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp),
                                    )
                                }
                                items(docs.drop(1), key = { it.uri }) { d ->
                                    DocRow(
                                        d, onOpen, onToggleFavorite, onRemove,
                                        handouts = handoutsByDoc[d.uri].orEmpty(),
                                        onDeleteHandout = onDeleteHandout,
                                        onOpenHandout = onOpenHandout,
                                    )
                                }
                            }
                        }
                    }
                }

                // ------------------ Tab 1: قفسه (Bookshelf Grid)
                1 -> {
                    val shelfDocs = if (shelfFilter == 0) docs else docs.filter { it.favorite }
                    Column(Modifier.fillMaxSize()) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            FilterChip(
                                selected = shelfFilter == 0,
                                onClick = { shelfFilter = 0 },
                                label = { Text("همه (${docs.size})") },
                                shape = RoundedCornerShape(16.dp),
                            )
                            FilterChip(
                                selected = shelfFilter == 1,
                                onClick = { shelfFilter = 1 },
                                label = { Text("موردعلاقه‌ها (${docs.count { it.favorite }})") },
                                shape = RoundedCornerShape(16.dp),
                            )
                        }

                        if (shelfDocs.isEmpty()) {
                            EmptyView(if (shelfFilter == 0) "قفسه خالی است." else "هنوز کتابی به موردعلاقه‌ها اضافه نشده است.")
                        } else {
                            LazyVerticalGrid(
                                columns = GridCells.Fixed(2),
                                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp),
                                horizontalArrangement = Arrangement.spacedBy(14.dp),
                            ) {
                                items(shelfDocs, key = { it.uri }) { d ->
                                    BookshelfItem(d, onOpen, onToggleFavorite)
                                }
                            }
                        }
                    }
                }

                // ------------------ Tab 2: من (Profile, Reading Stats & Quick Settings)
                2 -> {
                    ProfileTabContent(
                        docs = docs,
                        onOpenSettings = onOpenSettings,
                        onOpenUsage = onOpenUsage,
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyView(msg: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(
            msg,
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 24.sp,
        )
    }
}

/**
 * Boox-style Continue Reading Hero Card:
 * Clean, prominent e-reader card showing cover, reading progress, and a direct Resume button.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BooxHeroCard(doc: DocumentEntity, onOpen: (DocumentEntity) -> Unit) {
    val progress = if (doc.pageCount > 0) ((doc.lastPage + 1f) / doc.pageCount).coerceIn(0f, 1f) else 0f
    val percent = (progress * 100).toInt()
    val whenText = DateUtils.getRelativeTimeSpanString(
        doc.lastOpened, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS,
    ).toString()

    Card(
        onClick = { onOpen(doc) },
        modifier = Modifier
            .fillMaxWidth()
            .shadow(6.dp, RoundedCornerShape(26.dp)),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                ) {
                    Text(
                        "ادامه‌ی مطالعه",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                Text(
                    whenText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f),
                )
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Thumb(
                    doc.uri,
                    Modifier
                        .width(76.dp)
                        .height(108.dp)
                        .shadow(4.dp, RoundedCornerShape(12.dp)),
                )

                Column(
                    Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        doc.name,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )

                    Text(
                        "صفحه ${doc.lastPage + 1} از ${doc.pageCount}  ·  $percent٪ خوانده شده",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                    )

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(50)),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f),
                    )

                    Button(
                        onClick = { onOpen(doc) },
                        modifier = Modifier
                            .padding(top = 4.dp)
                            .height(38.dp),
                        shape = RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 0.dp),
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            AppIconView(AppIcon.Play, tint = MaterialTheme.colorScheme.onPrimary, size = 16.dp)
                            Text("ادامه مطالعه", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        }
    }
}

/**
 * 2-Column Grid item for the Bookshelf view
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BookshelfItem(
    d: DocumentEntity,
    onOpen: (DocumentEntity) -> Unit,
    onToggleFavorite: (DocumentEntity) -> Unit,
) {
    val progress = if (d.pageCount > 0) ((d.lastPage + 1f) / d.pageCount).coerceIn(0f, 1f) else 0f
    val percent = (progress * 100).toInt()

    Card(
        onClick = { onOpen(d) },
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.fillMaxWidth()) {
                Thumb(
                    d.uri,
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(0.72f)
                        .clip(RoundedCornerShape(14.dp)),
                )
                IconButton(
                    onClick = { onToggleFavorite(d) },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .size(32.dp)
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.85f), CircleShape),
                ) {
                    Icon(
                        if (d.favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = null,
                        tint = if (d.favorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp),
                    )
                }
            }

            Text(
                d.name,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "$percent٪",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                )
                Text(
                    "${d.pageCount} صفحه",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(50)),
            )
        }
    }
}


@Composable
private fun CollapsibleHandouts(
    handouts: List<HandoutEntity>,
    onDeleteHandout: (HandoutEntity) -> Unit,
    onOpenHandout: (HandoutEntity) -> Unit,
    tintSurface: Boolean = false,
) {
    if (handouts.isEmpty()) return
    var open by remember { mutableStateOf(false) }
    Column(
        Modifier
            .fillMaxWidth()
            .then(
                if (tintSurface) Modifier.padding(horizontal = 4.dp, vertical = 4.dp) else Modifier
            )
    ) {
        Text(
            text = if (open) "جزوه‌ها (${handouts.size}) ▲" else "جزوه‌ها (${handouts.size}) ▼",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier
                .fillMaxWidth()
                .clickable { open = !open }
                .padding(horizontal = 16.dp, vertical = 8.dp),
        )
        AnimatedVisibility(visible = open) {
            Column(
                Modifier.padding(start = 16.dp, end = 12.dp, bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                handouts.forEach { h ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(
                            Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(
                                Modifier
                                    .weight(1f)
                                    .clickable { onOpenHandout(h) },
                                verticalArrangement = Arrangement.spacedBy(2.dp),
                            ) {
                                Text(
                                    h.title.ifBlank { "جزوه · صفحات ${h.fromPage + 1} تا ${h.toPage + 1}" },
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Text(
                                    "صفحات ${h.fromPage + 1}–${h.toPage + 1}  ·  " +
                                        DateUtils.getRelativeTimeSpanString(h.createdAt).toString(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            IconButton(onClick = { onDeleteHandout(h) }) {
                                Icon(
                                    Icons.Default.Delete,
                                    contentDescription = "حذف جزوه",
                                    modifier = Modifier.size(18.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DocRow(
    d: DocumentEntity,
    onOpen: (DocumentEntity) -> Unit,
    onToggleFavorite: (DocumentEntity) -> Unit,
    onRemove: (DocumentEntity) -> Unit,
    handouts: List<HandoutEntity> = emptyList(),
    onDeleteHandout: (HandoutEntity) -> Unit = {},
    onOpenHandout: (HandoutEntity) -> Unit = {},
) {
    val whenText = DateUtils.getRelativeTimeSpanString(
        d.lastOpened, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS,
    ).toString()

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
    ) {
        Column {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { onOpen(d) }
                    .padding(start = 12.dp, top = 10.dp, bottom = 10.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Thumb(d.uri, Modifier.width(52.dp).height(74.dp).clip(RoundedCornerShape(10.dp)))

                Column(Modifier.weight(1f).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(d.name, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(
                        "${d.pageCount} صفحه  ·  $whenText",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (d.pageCount > 0) {
                        LinearProgressIndicator(
                            progress = { ((d.lastPage + 1f) / d.pageCount).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp)
                                .height(4.dp)
                                .clip(RoundedCornerShape(50)),
                        )
                    }
                }

                Row {
                    IconButton(onClick = { onToggleFavorite(d) }) {
                        Icon(
                            if (d.favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = stringResource(R.string.favorite),
                            tint = if (d.favorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconButton(onClick = { onRemove(d) }) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = stringResource(R.string.remove_from_list),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            CollapsibleHandouts(
                handouts = handouts,
                onDeleteHandout = onDeleteHandout,
                onOpenHandout = onOpenHandout,
            )
        }
    }
}

/**
 * Tab 2: Profile / Me Tab
 */
@Composable
private fun ProfileTabContent(
    docs: List<DocumentEntity>,
    onOpenSettings: () -> Unit,
    onOpenUsage: () -> Unit,
) {
    val context = LocalContext.current
    val container = remember { (context.applicationContext as ReaderApp).container }
    val totalPages = docs.sumOf { it.pageCount }
    val readPages = docs.sumOf { it.lastPage + 1 }
    val favCount = docs.count { it.favorite }
    val settings = container.settings.state.value

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        // User Reading Stats Card
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        "آمار و وضعیت مطالعه",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround,
                    ) {
                        StatItem("کتاب‌ها", docs.size.toString())
                        StatItem("صفحات خوانده", readPages.toString())
                        StatItem("موردعلاقه‌ها", favCount.toString())
                    }
                }
            }
        }

        // AI & Token Optimization Card
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            "مدیریت توکن‌ها و هوش مصنوعی",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        )
                        Button(
                            onClick = onOpenUsage,
                            shape = RoundedCornerShape(50),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer),
                        ) {
                            Text("مشاهده مصرف توکن", style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                        ) {
                            Text(
                                "Gemini AI TTS",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            )
                        }
                        Text(
                            "موتور صوتی هوشمند Gemini",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    }

                    Text(
                        "صوت‌ها با کیفیت طبیعی هوش مصنوعی Gemini تولید شده و به همراه کش هوشمند در حافظه دستگاه ذخیره می‌شوند تا بازخوانی صفحات بعدی بدون مصرف مجدد توکن انجام شود.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        // Quick Settings Actions
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(8.dp)) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .clickable(onClick = onOpenSettings)
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Icon(Icons.Default.Settings, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text("تنظیمات کامل برنامه و کلیدهای API", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                        }
                        Text("‹", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .clickable {
                                container.readAloud.clearAudio()
                                container.pageText.clearSession()
                            }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            AppIconView(AppIcon.Speaker, tint = MaterialTheme.colorScheme.secondary, size = 20.dp)
                            Text("پاکسازی کش صوتی", style = MaterialTheme.typography.bodyMedium)
                        }
                        Text("آزاد کردن فضا", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatItem(title: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(value, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
        Text(title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
    }
}

@Composable
private fun Thumb(uri: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val bmp by produceState<Bitmap?>(initialValue = null, uri) { value = Thumbnails.load(context, uri) }
    Box(
        modifier
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        val b = bmp
        if (b != null) {
            Image(b.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Text("PDF", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
