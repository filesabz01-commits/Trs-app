package app.pdfreader.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.pdfreader.ai.AiAttemptEntity
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Date
import java.util.Locale

private fun formatAttemptTime(ts: Long): String {
    val sdf = SimpleDateFormat("HH:mm:ss (MM/dd)", Locale.getDefault())
    return sdf.format(Date(ts))
}

private fun taskPersian(task: String): String = when (task.uppercase()) {
    "TRANSLATE" -> "ترجمه"
    "SUMMARIZE" -> "خلاصه‌سازی"
    "EXPLAIN" -> "چت / توضیح"
    "EXTRACT" -> "استخراج متن / OCR"
    else -> task
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UsageScreen(vm: AiViewModel, onBack: () -> Unit) {
    val providers by vm.providers.collectAsStateWithLifecycle()
    val keys by vm.keys.collectAsStateWithLifecycle()
    val attempts by vm.attempts.collectAsStateWithLifecycle()
    val tokenTotals by vm.tokenTotals.collectAsStateWithLifecycle()
    val today = LocalDate.now().toString()
    val now = System.currentTimeMillis()

    var filter by remember { mutableStateOf("ALL") }

    val filteredAttempts = remember(attempts, filter) {
        when (filter) {
            "ERRORS" -> attempts.filter { it.outcome != "OK" }
            "TRANSLATE" -> attempts.filter { it.task.equals("TRANSLATE", ignoreCase = true) }
            "SUMMARIZE" -> attempts.filter { it.task.equals("SUMMARIZE", ignoreCase = true) }
            "EXPLAIN" -> attempts.filter { it.task.equals("EXPLAIN", ignoreCase = true) }
            "EXTRACT" -> attempts.filter { it.task.equals("EXTRACT", ignoreCase = true) }
            else -> attempts
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("مصرف AI و تاریخچه تلاش‌ها") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت") }
                },
                actions = {
                    if (attempts.isNotEmpty()) {
                        IconButton(onClick = vm::clearAttempts) {
                            Icon(Icons.Default.Delete, contentDescription = "پاک‌کردن لاگ‌ها")
                        }
                    }
                },
            )
        },
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // Card 1: Actual Token Consumption Summary
            item {
                val totalTokens = tokenTotals.promptTotal + tokenTotals.candidatesTotal + tokenTotals.thoughtsTotal
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                "مجموع کل توکن‌های مصرف‌شده",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            )
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = MaterialTheme.colorScheme.primary,
                            ) {
                                Text(
                                    "%,d توکن".format(totalTokens),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onPrimary,
                                )
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("توکن‌های ورودی (Prompt)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("%,d".format(tokenTotals.promptTotal), style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold))
                            }
                            Column {
                                Text("توکن‌های خروجی (Answer)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("%,d".format(tokenTotals.candidatesTotal), style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold))
                            }
                            Column {
                                Text("توکن‌های فکر (Thinking)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("%,d".format(tokenTotals.thoughtsTotal), style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold))
                            }
                        }

                        // Task Breakdown from attempts
                        val taskGroups = attempts.groupBy { it.task.uppercase() }
                        if (taskGroups.isNotEmpty()) {
                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                            Text("مصرف بر اساس عملیات:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                taskGroups.forEach { (task, list) ->
                                    val taskTokens = list.sumOf { (it.promptTokens + it.candidatesTokens + it.thoughtsTokens).toLong() }
                                    SuggestionChip(
                                        onClick = {},
                                        label = { Text("${taskPersian(task)}: %,d".format(taskTokens)) },
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Card 2: Today's Requests and API Keys Status
            item {
                val active = keys.count { effectiveStatus(it, now) == "ACTIVE" }
                val limited = keys.count { effectiveStatus(it, now).let { s -> s == "RATE_LIMITED" || s == "DAILY_QUOTA_EXCEEDED" } }
                val invalid = keys.count { it.status == "INVALID" }
                val last = keys.filter { it.lastUsedAt > 0 }.maxByOrNull { it.lastUsedAt }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("آمار کلیدها و درخواست‌های امروز", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        Text("درخواست‌های امروز: " + keys.filter { it.usageDay == today }.sumOf { it.requestsToday })
                        Text("خطاهای امروز: " + keys.filter { it.usageDay == today }.sumOf { it.errorsToday })
                        Text("کلیدهای فعال: $active · محدودشده: $limited · نامعتبر: $invalid")
                        Text("آخرین کلید استفاده‌شده: " + (last?.label ?: "—"))
                    }
                }
            }

            // Keys details
            items(keys, key = { it.id }) { k ->
                val st = effectiveStatus(k, now)
                val wait = ((k.cooldownUntil - now) / 1000).coerceAtLeast(0)
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("${providers.firstOrNull { it.id == k.providerId }?.name ?: "?"} · ${k.label}", style = MaterialTheme.typography.titleSmall)
                        Text("وضعیت: ${statusLabel(st)}")
                        Text("درخواست امروز: ${if (k.usageDay == today) k.requestsToday else 0} · خطا: ${if (k.usageDay == today) k.errorsToday else 0}")
                        if (wait > 0) Text("زمان باقی‌مانده‌ی cooldown: ${formatWait(wait)}")
                        k.lastError?.let { Text("آخرین خطا: $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
                    }
                }
            }

            // Section: Attempts Log Header & Filter Chips
            item {
                HorizontalDivider(modifier = Modifier.padding(top = 8.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "لاگ تلاش‌های اخیر (${filteredAttempts.size})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    )
                    if (attempts.isNotEmpty()) {
                        TextButton(onClick = vm::clearAttempts) {
                            Text("پاک‌کردن", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }

                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FilterChip(selected = filter == "ALL", onClick = { filter = "ALL" }, label = { Text("همه") })
                    FilterChip(selected = filter == "TRANSLATE", onClick = { filter = "TRANSLATE" }, label = { Text("ترجمه") })
                    FilterChip(selected = filter == "SUMMARIZE", onClick = { filter = "SUMMARIZE" }, label = { Text("خلاصه") })
                    FilterChip(selected = filter == "EXPLAIN", onClick = { filter = "EXPLAIN" }, label = { Text("چت / توضیح") })
                    FilterChip(selected = filter == "EXTRACT", onClick = { filter = "EXTRACT" }, label = { Text("استخراج / OCR") })
                    FilterChip(selected = filter == "ERRORS", onClick = { filter = "ERRORS" }, label = { Text("فقط خطاها") })
                }
            }

            if (filteredAttempts.isEmpty()) {
                item {
                    Text(
                        "هیچ تلاشی در این بخش ثبت نشده است.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 12.dp),
                    )
                }
            } else {
                items(filteredAttempts, key = { it.id }) { a ->
                    AttemptCard(a)
                }
            }
        }
    }
}

@Composable
private fun AttemptCard(a: AiAttemptEntity) {
    val isOk = a.outcome == "OK"
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isOk) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
            else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f),
        ),
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                    ) {
                        Text(
                            taskPersian(a.task),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                        )
                    }
                    Text(a.model.removePrefix("gemini-"), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (isOk) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error,
                ) {
                    Text(
                        if (isOk) "موفق" else a.outcome,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = Color.White,
                    )
                }
            }

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text("کلید: ${a.keyLabel}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(formatAttemptTime(a.timestamp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    "اولین بایت: ${a.timeToFirstByteMs}ms · کل: ${a.totalTimeMs}ms",
                    style = MaterialTheme.typography.bodySmall,
                )
                if (isOk) {
                    Text(
                        "توکن: ${a.promptTokens} ورودی | ${a.candidatesTokens} خروجی" + (if (a.thoughtsTokens > 0) " | ${a.thoughtsTokens} فکر" else ""),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium,
                    )
                }
            }

            a.errorMessage?.takeIf { it.isNotBlank() }?.let { err ->
                Text("علت: $err", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            }
        }
    }
}
