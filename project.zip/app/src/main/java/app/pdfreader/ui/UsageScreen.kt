package app.pdfreader.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UsageScreen(vm: AiViewModel, onBack: () -> Unit) {
    val providers by vm.providers.collectAsStateWithLifecycle()
    val keys by vm.keys.collectAsStateWithLifecycle()
    val today = LocalDate.now().toString()
    val now = System.currentTimeMillis()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("مصرف AI") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت") }
                },
            )
        },
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                Text(
                    "اعداد زیر فقط شمارنده‌ی داخلی همین برنامه است. مقدار دقیق quota از طرف provider گزارش نشده است " +
                        "و فقط در صورت خطای واقعی (مثل 429) وضعیت کلید تغییر می‌کند.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            item {
                val active = keys.count { effectiveStatus(it, now) == "ACTIVE" }
                val limited = keys.count { effectiveStatus(it, now).let { s -> s == "RATE_LIMITED" || s == "DAILY_QUOTA_EXCEEDED" } }
                val invalid = keys.count { it.status == "INVALID" }
                val last = keys.filter { it.lastUsedAt > 0 }.maxByOrNull { it.lastUsedAt }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("درخواست‌های امروز: " + keys.filter { it.usageDay == today }.sumOf { it.requestsToday })
                        Text("خطاهای امروز: " + keys.filter { it.usageDay == today }.sumOf { it.errorsToday })
                        Text("کلیدهای فعال: $active · محدودشده: $limited · نامعتبر: $invalid")
                        Text("آخرین کلید استفاده‌شده: " + (last?.label ?: "—"))
                    }
                }
            }
            items(keys, key = { it.id }) { k ->
                val st = effectiveStatus(k, now)
                val wait = ((k.cooldownUntil - now) / 1000).coerceAtLeast(0)
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("${providers.firstOrNull { it.id == k.providerId }?.name ?: "?"} · ${k.label}", style = MaterialTheme.typography.titleSmall)
                        Text("وضعیت: ${statusLabel(st)}")
                        Text("درخواست امروز: ${if (k.usageDay == today) k.requestsToday else 0} · خطا: ${if (k.usageDay == today) k.errorsToday else 0}")
                        if (wait > 0) Text("زمان باقی‌مانده‌ی cooldown: ${formatWait(wait)}")
                        k.lastError?.let { Text("آخرین خطا: $it", style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }
        }
    }
}
