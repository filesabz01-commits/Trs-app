package app.pdfreader.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

private val QUICK = listOf(
    "این صفحه را ساده توضیح بده",
    "اصطلاحات مهم این صفحه را تعریف کن",
    "نکته‌های اصلی صفحه را بگو",
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatSheet(
    chat: ChatViewModel,
    currentPage: Int,
    onSend: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val messages by chat.messages.collectAsStateWithLifecycle()
    val busy by chat.busy.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(messages.size, messages.lastOrNull()?.text?.length) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(
            Modifier.fillMaxWidth().fillMaxHeight(0.88f).imePadding().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("دستیار هوشمند 🤖", style = MaterialTheme.typography.titleLarge)
                    Text(
                        "درباره‌ی صفحه‌ی $currentPage بپرس",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (messages.isNotEmpty()) TextButton(onClick = chat::clear) { Text("گفت‌وگوی جدید") }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (messages.isEmpty()) {
                    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🤖", style = MaterialTheme.typography.displayMedium)
                        Text(
                            "هر سؤالی درباره‌ی همین صفحه داری بپرس.",
                            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                } else {
                    LazyColumn(state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(messages) { m -> Bubble(m) }
                    }
                }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QUICK.forEach { q -> AssistChip(onClick = { if (!busy) onSend(q) }, label = { Text(q) }) }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    placeholder = { Text("سؤالت را بنویس…") },
                    modifier = Modifier.weight(1f),
                    maxLines = 4,
                    shape = RoundedCornerShape(20.dp),
                )
                Button(
                    onClick = { onSend(input); input = "" },
                    enabled = input.isNotBlank() && !busy,
                ) { Text("ارسال") }
            }
        }
    }
}

@Composable
private fun Bubble(m: ChatMsg) {
    val rtl = m.text.isBlank() || isRtlParagraph(m.text) || m.text.firstOrNull { it.isLetter() } == null
    val bg = if (m.fromUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.Start else Arrangement.End) {
        // in a right-to-left app "Start" is the right edge: user bubbles on the right, assistant on the left
        Column(
            Modifier.fillMaxWidth(0.88f)
                .background(bg, RoundedCornerShape(18.dp))
                .padding(12.dp),
        ) {
            if (m.text.isBlank()) Text("…")
            else if (m.fromUser) RichText(m.text, rtl, null, forceRtl = false)
            else RichText(m.text, rtl, null, forceRtl = false)
            if (m.pending && m.text.isNotBlank()) {
                Text("در حال نوشتن…", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
