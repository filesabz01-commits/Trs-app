package app.pdfreader.ui

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.media.MediaPlayer
import app.pdfreader.ReaderApp
import app.pdfreader.ai.AiRouter
import app.pdfreader.ai.Wav
import app.pdfreader.ai.plainForSpeech
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.util.Locale

import androidx.compose.material3.FilterChip

private val QUICK = listOf(
    "این بخش را ساده توضیح بده",
    "اصطلاحات مهم این بخش را تعریف کن",
    "نکته‌های اصلی این مبحث را بگو",
    "یک سوال مفهومی از این بخش بپرس",
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatSheet(
    chat: ChatViewModel,
    currentPage: Int,
    totalPages: Int = 1,
    onSend: (String) -> Unit,
    onSendRange: ((Int, Int, String) -> Unit)? = null,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val messages by chat.messages.collectAsStateWithLifecycle()
    val busy by chat.busy.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    var liveMode by remember { mutableStateOf(false) }
    var liveSpeaking by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val app = context.applicationContext as? ReaderApp
    val container = app?.container
    var livePlayer by remember { mutableStateOf<MediaPlayer?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            try { livePlayer?.stop(); livePlayer?.release() } catch (ignored: Exception) {}
            livePlayer = null
        }
    }

    // Auto-read response aloud with natural Gemini AI voice when in Live Mode
    LaunchedEffect(messages.lastOrNull()?.pending, messages.lastOrNull()?.text) {
        val last = messages.lastOrNull()
        if (liveMode && last != null && !last.fromUser && !last.pending && last.text.isNotBlank()) {
            val text = plainForSpeech(last.text.take(600))
            scope.launch(Dispatchers.IO) {
                try {
                    val voice = container?.settings?.state?.value?.voice ?: "Puck"
                    val res = container?.router?.synthesize(text, voice, "")
                    if (res is AiRouter.Outcome.Ok && res.audio != null) {
                        val polished = Wav.polish(res.audio)
                        val tmp = File(context.cacheDir, "live_reply.wav")
                        tmp.writeBytes(polished)
                        withContext(Dispatchers.Main) {
                            try {
                                livePlayer?.release()
                                val mp = MediaPlayer().apply {
                                    setDataSource(tmp.absolutePath)
                                    prepare()
                                    setOnCompletionListener {
                                        liveSpeaking = false
                                        try { release() } catch (e: Exception) {}
                                    }
                                    setOnErrorListener { _, _, _ ->
                                        liveSpeaking = false
                                        try { release() } catch (e: Exception) {}
                                        true
                                    }
                                    start()
                                }
                                livePlayer = mp
                                liveSpeaking = true
                            } catch (e: Exception) {
                                liveSpeaking = false
                            }
                        }
                    } else {
                        withContext(Dispatchers.Main) { liveSpeaking = false }
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) { liveSpeaking = false }
                }
            }
        }
    }

    var isRangeScope by remember { mutableStateOf(false) }
    var fromInput by remember { mutableStateOf(currentPage.toString()) }
    var toInput by remember { mutableStateOf(minOf(currentPage + 9, totalPages.coerceAtLeast(currentPage)).toString()) }

    fun sendQuestion(q: String) {
        val trimmed = q.trim()
        if (trimmed.isEmpty()) return
        if (isRangeScope && onSendRange != null) {
            val f = (fromInput.toIntOrNull() ?: currentPage) - 1
            val t = (toInput.toIntOrNull() ?: currentPage) - 1
            onSendRange(f, t, trimmed)
        } else {
            onSend(trimmed)
        }
    }

    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val matches = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val recognized = matches?.firstOrNull()?.trim()
            if (!recognized.isNullOrBlank()) {
                input = recognized
                sendQuestion(recognized)
                input = ""
            }
        }
    }

    fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "سؤال خود را بپرسید…")
        }
        try {
            speechLauncher.launch(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "سرویس تشخیص صدا در دستگاه یافت نشد", Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(messages.size, messages.lastOrNull()?.text?.length) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }

    ModalBottomSheet(
        onDismissRequest = {
            try { livePlayer?.stop(); livePlayer?.release() } catch (ignored: Exception) {}; livePlayer = null
            chat.clear() // Clear conversation so no memory buildup or persistence
            onDismiss()
        },
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.9f)
                .imePadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            // Header
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Box(
                        Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center,
                    ) {
                        AppIconView(AppIcon.Sparkle, tint = MaterialTheme.colorScheme.primary, size = 20.dp)
                    }
                    Column {
                        Text(
                            "دستیار هوشمند کتاب",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        )
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.padding(top = 2.dp),
                        ) {
                            Text(
                                if (isRangeScope) "بازه صفحات $fromInput تا $toInput" else "صفحه $currentPage",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    // Live Voice Toggle Button
                    AssistChip(
                        onClick = {
                            liveMode = !liveMode
                            if (!liveMode) {
                                try { livePlayer?.stop(); livePlayer?.release() } catch (ignored: Exception) {}; livePlayer = null
                                liveSpeaking = false
                            } else {
                                startVoiceInput()
                            }
                        },
                        label = {
                            Text(
                                if (liveMode) "حالت لایو فعال" else "لایو صوتی",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                            )
                        },
                        leadingIcon = {
                            AppIconView(
                                AppIcon.Mic,
                                tint = if (liveMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                size = 16.dp,
                            )
                        },
                        shape = RoundedCornerShape(50),
                    )

                    if (messages.isNotEmpty()) {
                        TextButton(onClick = {
                            try { livePlayer?.stop(); livePlayer?.release() } catch (ignored: Exception) {}; livePlayer = null
                            chat.clear()
                        }) {
                            Text("پاکسازی", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }

            // Scope Selector: This Page vs Range of Pages
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                FilterChip(
                    selected = !isRangeScope,
                    onClick = { isRangeScope = false },
                    label = { Text("همین صفحه ($currentPage)", style = MaterialTheme.typography.labelSmall) },
                    shape = RoundedCornerShape(16.dp),
                )
                FilterChip(
                    selected = isRangeScope,
                    onClick = { isRangeScope = true },
                    label = { Text("بازه صفحات (فصل / مبحث)", style = MaterialTheme.typography.labelSmall) },
                    shape = RoundedCornerShape(16.dp),
                )
            }

            AnimatedVisibility(visible = isRangeScope) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("از صفحه:", style = MaterialTheme.typography.labelSmall)
                    OutlinedTextField(
                        value = fromInput,
                        onValueChange = { fromInput = it.filter { c -> c.isDigit() }.take(4) },
                        modifier = Modifier.width(68.dp).height(46.dp),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        textStyle = MaterialTheme.typography.bodySmall,
                    )
                    Text("تا صفحه:", style = MaterialTheme.typography.labelSmall)
                    OutlinedTextField(
                        value = toInput,
                        onValueChange = { toInput = it.filter { c -> c.isDigit() }.take(4) },
                        modifier = Modifier.width(68.dp).height(46.dp),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        textStyle = MaterialTheme.typography.bodySmall,
                    )
                    Text("از $totalPages", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            // Live Mode Voice Visualizer Banner
            AnimatedVisibility(visible = liveMode) {
                LiveVoiceBanner(
                    busy = busy,
                    speaking = liveSpeaking,
                    onMicClick = { startVoiceInput() },
                )
            }

            // Chat Messages or Empty Welcome
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth(),
            ) {
                if (messages.isEmpty()) {
                    Column(
                        Modifier
                            .align(Alignment.Center)
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Box(
                            Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center,
                        ) {
                            AppIconView(AppIcon.Sparkle, tint = MaterialTheme.colorScheme.primary, size = 32.dp)
                        }
                        Text(
                            "درباره‌ی این صفحه چه می‌خواهید بدانید؟",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        Text(
                            "می‌توانید سوال بپرسید، بخواهید صفحه را به زبان ساده توضیح دهد یا صوتی مکالمه کنید.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 20.sp,
                        )
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        items(messages) { m -> Bubble(m) }
                    }
                }
            }

            // Suggestion Chips (QUICK) — automatically hide after first message!
            AnimatedVisibility(
                visible = messages.isEmpty() && !busy,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically(),
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        "پرسش‌های پیشنهادی:",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Row(
                        Modifier
                            .horizontalScroll(rememberScrollState())
                            .padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        QUICK.forEach { q ->
                            AssistChip(
                                onClick = { sendQuestion(q) },
                                label = { Text(q, style = MaterialTheme.typography.labelMedium) },
                                shape = RoundedCornerShape(18.dp),
                            )
                        }
                    }
                }
            }

            // Bottom Input Bar with Mic & Send Buttons
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp),
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    placeholder = { Text("سؤالتان را بنویسید…", style = MaterialTheme.typography.bodyMedium) },
                    modifier = Modifier.weight(1f),
                    maxLines = 4,
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
                    ),
                    trailingIcon = {
                        IconButton(onClick = { startVoiceInput() }) {
                            AppIconView(AppIcon.Mic, tint = MaterialTheme.colorScheme.primary, size = 20.dp)
                        }
                    },
                )

                FilledIconButton(
                    onClick = {
                        val q = input.trim()
                        if (q.isNotEmpty()) {
                            sendQuestion(q)
                            input = ""
                        }
                    },
                    enabled = input.isNotBlank() && !busy,
                    modifier = Modifier.size(50.dp),
                    shape = CircleShape,
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                    ),
                ) {
                    AppIconView(
                        AppIcon.Sparkle,
                        tint = if (input.isNotBlank() && !busy) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                        size = 20.dp,
                    )
                }
            }
        }
    }
}

@Composable
private fun LiveVoiceBanner(
    busy: Boolean,
    speaking: Boolean,
    onMicClick: () -> Unit,
) {
    val infiniteTransition = rememberInfiniteTransition()
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onMicClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
        ),
    ) {
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Box(
                Modifier
                    .size(36.dp)
                    .scale(if (busy || speaking) pulseScale else 1f)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center,
            ) {
                AppIconView(AppIcon.Mic, tint = MaterialTheme.colorScheme.onPrimary, size = 18.dp)
            }
            Column(Modifier.weight(1f)) {
                Text(
                    text = when {
                        speaking -> "دستیار در حال پاسخ صوتی است…"
                        busy -> "در حال اندیشیدن و تولید پاسخ…"
                        else -> "برای صحبت کردن ضربه بزنید"
                    },
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
                Text(
                    text = "مکالمه هوشمند به صورت زنده و دوطرفه",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                )
            }
        }
    }
}

@Composable
private fun Bubble(m: ChatMsg) {
    val rtl = m.text.isBlank() || isRtlParagraph(m.text) || m.text.firstOrNull { it.isLetter() } == null
    val bg = if (m.fromUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
    val shape = if (m.fromUser) {
        RoundedCornerShape(topStart = 20.dp, topEnd = 6.dp, bottomStart = 20.dp, bottomEnd = 20.dp)
    } else {
        RoundedCornerShape(topStart = 6.dp, topEnd = 20.dp, bottomStart = 20.dp, bottomEnd = 20.dp)
    }

    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (m.fromUser) Arrangement.Start else Arrangement.End,
    ) {
        Column(
            Modifier
                .fillMaxWidth(0.88f)
                .background(bg, shape)
                .padding(14.dp),
        ) {
            if (m.text.isBlank() && m.pending) {
                TypingDots()
            } else {
                RichText(m.text, rtl, null, forceRtl = false)
                if (m.pending && m.text.isNotBlank()) {
                    Text(
                        "در حال نوشتن…",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun TypingDots() {
    val transition = rememberInfiniteTransition()
    val dotAlpha by transition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
    )

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.padding(vertical = 4.dp),
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = dotAlpha)))
        Box(Modifier.size(8.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = (dotAlpha + 0.3f) % 1f)))
        Box(Modifier.size(8.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = (dotAlpha + 0.6f) % 1f)))
        Text(
            "در حال آماده‌سازی پاسخ…",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 4.dp),
        )
    }
}
