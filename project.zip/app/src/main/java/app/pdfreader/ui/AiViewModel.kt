package app.pdfreader.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.pdfreader.ReaderApp
import app.pdfreader.ai.PT
import app.pdfreader.ai.RTL_LANGS
import app.pdfreader.ai.AiTask
import app.pdfreader.ai.ApiKeyEntity
import app.pdfreader.ai.GeminiModels
import app.pdfreader.ai.KeyStatus
import app.pdfreader.ai.ModelEntity
import app.pdfreader.ai.ProviderEntity
import app.pdfreader.ai.ProviderTypes
import app.pdfreader.ai.ReadingProfile
import app.pdfreader.ai.ReadingSettings
import app.pdfreader.ai.SecretBox
import app.pdfreader.core.pdf.PdfDocument
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

sealed interface AiUi {
    data object Idle : AiUi
    class Loading(val task: AiTask, val page: Int, val phase: String, val rangeTo: Int = -1) : AiUi
    class Streaming(val task: AiTask, val page: Int, val text: String, val rtl: Boolean, val original: String? = null, val rangeTo: Int = -1) : AiUi
    class Done(val task: AiTask, val page: Int, val text: String, val fromCache: Boolean, val model: String, val rtl: Boolean, val original: String? = null, val rangeTo: Int = -1) : AiUi
    class Error(val message: String) : AiUi
}

class AiViewModel(app: Application) : AndroidViewModel(app) {
    private val container = (app as ReaderApp).container
    private val dao = container.aiDao
    private val router = container.router
    private val settingsRepo = container.settings
    private val texts = container.pageText

    val providers = dao.observeProviders().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val models = dao.observeModels().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val keys = dao.observeKeys().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val cacheBytes = dao.observeCacheBytes().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0L)
    val settings: StateFlow<ReadingSettings> = settingsRepo.state

    private val _audioBytes = MutableStateFlow(0L)
    val audioBytes: StateFlow<Long> = _audioBytes.asStateFlow()
    fun refreshAudioBytes() { _audioBytes.value = container.readAloud.audioBytes() }

    private val _ui = MutableStateFlow<AiUi>(AiUi.Idle)
    val ui: StateFlow<AiUi> = _ui.asStateFlow()

    private val _testMessages = MutableStateFlow<Map<String, String>>(emptyMap())
    val testMessages: StateFlow<Map<String, String>> = _testMessages.asStateFlow()

    private var job: Job? = null

    init {
        viewModelScope.launch { seedModels() }
        refreshAudioBytes()
    }

    /** One-time: Gemini provider with the same model order as the original HTML tool. Keys are kept. */
    private suspend fun seedModels() {
        if (settingsRepo.seedVersion() >= 2) return
        if (dao.provider("gemini") == null) {
            dao.upsertProvider(
                ProviderEntity("gemini", "Gemini", ProviderTypes.GEMINI, ProviderTypes.defaultBaseUrl(ProviderTypes.GEMINI), true, 0)
            )
        }
        dao.deleteModelsOf("gemini")
        GeminiModels.TEXT.forEachIndexed { i, m ->
            dao.upsertModel(
                ModelEntity(id = "gemini-t-$i", providerId = "gemini", modelName = m,
                    supportsText = true, supportsVision = true, enabled = true, position = i, supportsTts = false)
            )
        }
        GeminiModels.TTS.forEachIndexed { i, m ->
            dao.upsertModel(
                ModelEntity(id = "gemini-s-$i", providerId = "gemini", modelName = m,
                    supportsText = false, supportsVision = false, enabled = true, position = 100 + i, supportsTts = true)
            )
        }
        settingsRepo.setSeedVersion(2)
    }

    // ---------- page tasks ----------

    /**
     * Pipeline: (1) extract + clean the page text -> (2) translate / explain / summarize it.
     * The page index is fixed at the moment of the request, so text, cache key and result always match.
     */
    fun runPageTask(doc: PdfDocument, docUri: String, requestedPage: Int, task: AiTask, force: Boolean = false) {
        job?.cancel()
        val page = requestedPage.coerceIn(0, (doc.pageCount - 1).coerceAtLeast(0))
        _ui.value = AiUi.Loading(task, page, "در حال آماده‌سازی…")
        job = viewModelScope.launch {
            val s = settings.value
            val targetRtl = s.targetLanguage in RTL_LANGS
            if (!force && task != AiTask.EXTRACT) {
                texts.cached(task, docUri, page, s)?.let {
                    _ui.value = AiUi.Done(task, page, it.text, true, it.model, targetRtl, it.source)
                    return@launch
                }
            }
            val ex = texts.extract(doc, docUri, page, s, force) { phase -> _ui.value = AiUi.Loading(task, page, phase) }
            val text = when (ex) {
                is PT.Fail -> { _ui.value = AiUi.Error(ex.message); return@launch }
                PT.NoText -> {
                    _ui.value = AiUi.Done(task, page, "این صفحه فقط شکل، عکس یا نمودار دارد و متن اصلی قابل‌توجهی ندارد؛ نادیده گرفته شد.", false, "—", false)
                    return@launch
                }
                is PT.Ok -> ex.text
            }
            if (task == AiTask.EXTRACT) {
                _ui.value = AiUi.Done(task, page, text, false, ex.let { (it as PT.Ok).model.ifEmpty { "—" } }, isRtlParagraph(text))
                return@launch
            }
            _ui.value = AiUi.Loading(task, page, "در حال پردازش متن…")
            when (val r = texts.process(task, docUri, page, s, text, force) { partial ->
                _ui.value = AiUi.Streaming(task, page, partial, targetRtl, text)
            }) {
                is PT.Ok -> _ui.value = AiUi.Done(task, page, r.text, r.fromCache, r.model, targetRtl, if (task == AiTask.TRANSLATE) (r.source ?: text) else null)
                is PT.Fail -> _ui.value = AiUi.Error(r.message)
                PT.NoText -> _ui.value = AiUi.Idle
            }
        }
    }

    /** Review summary for pages [fromPage]..[toPage] (0-based, inclusive). */
    fun runRangeSummary(doc: PdfDocument, docUri: String, fromPage: Int, toPage: Int, force: Boolean = false) {
        job?.cancel()
        val last = (doc.pageCount - 1).coerceAtLeast(0)
        val from = minOf(fromPage, toPage).coerceIn(0, last)
        val to = maxOf(fromPage, toPage).coerceIn(0, last)
        _ui.value = AiUi.Loading(AiTask.SUMMARIZE, from, "در حال آماده‌سازی…", to)
        job = viewModelScope.launch {
            val s = settings.value
            val rtl = s.targetLanguage in RTL_LANGS
            val r = texts.summarizeRange(
                doc, docUri, from, to, s, force,
                onProgress = { phase -> _ui.value = AiUi.Loading(AiTask.SUMMARIZE, from, phase, to) },
                onPartial = { partial -> _ui.value = AiUi.Streaming(AiTask.SUMMARIZE, from, partial, rtl, null, to) },
            )
            _ui.value = when (r) {
                is PT.Ok -> AiUi.Done(AiTask.SUMMARIZE, from, r.text, r.fromCache, r.model, rtl, null, to)
                is PT.Fail -> AiUi.Error(r.message)
                PT.NoText -> AiUi.Done(AiTask.SUMMARIZE, from, "در این بازه متن قابل‌توجهی پیدا نشد (فقط شکل یا تصویر).", false, "—", false, null, to)
            }
        }
    }

    fun dismissResult() {
        job?.cancel()
        _ui.value = AiUi.Idle
    }

    // ---------- settings ----------
    fun setSourceLanguage(v: String) = settingsRepo.update { it.copy(sourceLanguage = v) }
    fun setTargetLanguage(v: String) = settingsRepo.update { it.copy(targetLanguage = v) }
    fun setProfile(v: ReadingProfile) = settingsRepo.update { it.copy(profile = v) }
    fun setCustomInstruction(v: String) = settingsRepo.update { it.copy(customInstruction = v) }
    fun setPreferredModel(v: String) = settingsRepo.update { it.copy(preferredModel = v) }
    fun setPersistOcr(v: Boolean) = settingsRepo.update { it.copy(persistOcr = v) }
    fun setBilingual(v: Boolean) = settingsRepo.update { it.copy(bilingual = v) }
    fun setVoice(v: String) = settingsRepo.update { it.copy(voice = v) }
    fun clearCache() {
        texts.clearSession()
        container.readAloud.clearAudio()
        viewModelScope.launch { dao.clearCache() }
        refreshAudioBytes()
    }

    // ---------- providers / models / keys ----------
    fun setProviderEnabled(p: ProviderEntity, enabled: Boolean) {
        viewModelScope.launch { dao.upsertProvider(p.copy(enabled = enabled)) }
    }

    fun moveProvider(p: ProviderEntity, delta: Int) {
        viewModelScope.launch {
            val list = dao.providers()
            val i = list.indexOfFirst { it.id == p.id }
            val j = i + delta
            if (i < 0 || j !in list.indices) return@launch
            val a = list[i]
            val b = list[j]
            dao.upsertProvider(a.copy(position = b.position))
            dao.upsertProvider(b.copy(position = a.position))
        }
    }

    fun deleteProvider(p: ProviderEntity) {
        viewModelScope.launch {
            dao.deleteKeysOf(p.id)
            dao.deleteModelsOf(p.id)
            dao.deleteProvider(p.id)
        }
    }

    fun addModel(providerId: String, name: String, text: Boolean, vision: Boolean) {
        if (name.isBlank()) return
        viewModelScope.launch {
            val pos = (models.value.filter { it.providerId == providerId }.maxOfOrNull { it.position } ?: -1) + 1
            dao.upsertModel(ModelEntity(UUID.randomUUID().toString(), providerId, name.trim(), text, vision, true, pos))
        }
    }

    fun setModelEnabled(m: ModelEntity, enabled: Boolean) {
        viewModelScope.launch { dao.upsertModel(m.copy(enabled = enabled)) }
    }

    fun deleteModel(m: ModelEntity) { viewModelScope.launch { dao.deleteModel(m.id) } }

    fun addKey(providerId: String, label: String, secret: String) {
        if (secret.isBlank()) return
        viewModelScope.launch {
            val pos = (keys.value.filter { it.providerId == providerId }.maxOfOrNull { it.position } ?: -1) + 1
            dao.upsertKey(
                ApiKeyEntity(
                    id = UUID.randomUUID().toString(), providerId = providerId,
                    label = label.trim().ifEmpty { "کلید ${pos + 1}" },
                    secret = SecretBox.encrypt(secret.trim()), position = pos,
                )
            )
        }
    }

    fun setKeyDisabled(k: ApiKeyEntity, disabled: Boolean) {
        viewModelScope.launch {
            dao.upsertKey(
                k.copy(
                    status = if (disabled) KeyStatus.DISABLED.name else KeyStatus.ACTIVE.name,
                    cooldownUntil = 0,
                )
            )
        }
    }

    fun deleteKey(k: ApiKeyEntity) { viewModelScope.launch { dao.deleteKey(k.id) } }

    fun testKey(k: ApiKeyEntity) {
        _testMessages.value = _testMessages.value + (k.id to "در حال تست…")
        viewModelScope.launch {
            val msg = try { router.test(k.id) } catch (e: CancellationException) { throw e } catch (e: Exception) { "خطا: ${e.message}" }
            _testMessages.value = _testMessages.value + (k.id to msg)
        }
    }
}

fun formatWait(seconds: Long): String = when {
    seconds < 90 -> "$seconds ثانیه"
    seconds < 5400 -> "${seconds / 60} دقیقه"
    else -> "${seconds / 3600} ساعت"
}
