package app.pdfreader.ui

import android.app.Application
import android.graphics.Bitmap
import android.util.LruCache
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.pdfreader.ReaderApp
import app.pdfreader.ai.AiRouter
import app.pdfreader.ai.AiTask
import app.pdfreader.ai.ApiKeyEntity
import app.pdfreader.ai.CacheEntity
import app.pdfreader.ai.Capability
import app.pdfreader.ai.GeminiModels
import app.pdfreader.ai.KeyStatus
import app.pdfreader.ai.ModelEntity
import app.pdfreader.ai.Prompts
import app.pdfreader.ai.ProviderEntity
import app.pdfreader.ai.ProviderTypes
import app.pdfreader.ai.ReadingProfile
import app.pdfreader.ai.ReadingSettings
import app.pdfreader.ai.SecretBox
import app.pdfreader.ai.sha256
import app.pdfreader.core.pdf.PdfDocument
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.UUID

sealed interface AiUi {
    data object Idle : AiUi
    class Loading(val task: AiTask, val page: Int, val phase: String) : AiUi
    class Streaming(val task: AiTask, val page: Int, val text: String) : AiUi
    class Done(val task: AiTask, val page: Int, val text: String, val fromCache: Boolean, val model: String) : AiUi
    class Error(val message: String) : AiUi
}

class AiViewModel(app: Application) : AndroidViewModel(app) {
    private val container = (app as ReaderApp).container
    private val dao = container.aiDao
    private val router = container.router
    private val settingsRepo = container.settings

    val providers = dao.observeProviders().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val models = dao.observeModels().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val keys = dao.observeKeys().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val cacheBytes = dao.observeCacheBytes().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0L)
    val settings: StateFlow<ReadingSettings> = settingsRepo.state

    private val _ui = MutableStateFlow<AiUi>(AiUi.Idle)
    val ui: StateFlow<AiUi> = _ui.asStateFlow()

    private val _testMessages = MutableStateFlow<Map<String, String>>(emptyMap())
    val testMessages: StateFlow<Map<String, String>> = _testMessages.asStateFlow()

    private var job: Job? = null

    /** OCR/extracted text lives only in memory (lost when the app closes) unless the user turns persistence on. */
    private val sessionText = LruCache<String, String>(300)

    init {
        viewModelScope.launch { seedModels() }
    }

    /** One-time: Gemini provider with the same model order as the original HTML tool. Keys are kept. */
    private suspend fun seedModels() {
        if (settingsRepo.seedVersion() >= 2) return
        if (dao.provider("gemini") == null) {
            dao.upsertProvider(
                ProviderEntity("gemini", "Gemini", ProviderTypes.GEMINI, ProviderTypes.defaultBaseUrl(ProviderTypes.GEMINI), true, 0)
            )
        }
        dao.deleteModelsOf("gemini")
        GeminiModels.TEXT.forEachIndexed { i, m ->
            dao.upsertModel(
                ModelEntity(id = "gemini-t-$i", providerId = "gemini", modelName = m,
                    supportsText = true, supportsVision = true, enabled = true, position = i, supportsTts = false)
            )
        }
        GeminiModels.TTS.forEachIndexed { i, m ->
            dao.upsertModel(
                ModelEntity(id = "gemini-s-$i", providerId = "gemini", modelName = m,
                    supportsText = false, supportsVision = false, enabled = true, position = 100 + i, supportsTts = true)
            )
        }
        settingsRepo.setSeedVersion(2)
    }

    // ---------- page tasks ----------

    /**
     * Pipeline: (1) extract + clean the page text (vision) -> (2) translate / explain / summarize that text.
     * The page index is fixed at the moment of the request, so text, cache key and result always match.
     */
    fun runPageTask(doc: PdfDocument, docUri: String, requestedPage: Int, task: AiTask) {
        job?.cancel()
        val page = requestedPage.coerceIn(0, (doc.pageCount - 1).coerceAtLeast(0))
        _ui.value = AiUi.Loading(task, page, "در حال آماده‌سازی…")
        job = viewModelScope.launch {
            val s = settings.value
            val finalKey = if (task == AiTask.EXTRACT) null else sha256(
                "$docUri|$page|${task.name}|${s.sourceLanguage}|${s.targetLanguage}|${s.profile.name}|" +
                    (if (s.profile == ReadingProfile.CUSTOM) s.customInstruction else "")
            )
            if (finalKey != null) {
                dao.cached(finalKey)?.let {
                    _ui.value = AiUi.Done(task, page, it.text, true, it.model)
                    return@launch
                }
            }

            val extracted = obtainText(doc, docUri, page, task, s) ?: return@launch
            if (extracted == Prompts.NO_TEXT) {
                _ui.value = AiUi.Done(task, page, "این صفحه فقط شکل، عکس یا نمودار دارد و متن اصلی قابل‌توجهی ندارد؛ نادیده گرفته شد.", false, "—")
                return@launch
            }
            if (task == AiTask.EXTRACT) {
                _ui.value = AiUi.Done(task, page, extracted, false, "—")
                return@launch
            }

            _ui.value = AiUi.Loading(task, page, "در حال پردازش متن…")
            val outcome = router.run(
                Capability.TEXT,
                Prompts.buildText(task, s, extracted),
                s.preferredModel,
                onPartial = { partial -> _ui.value = AiUi.Streaming(task, page, partial) },
            )
            when (outcome) {
                is AiRouter.Outcome.Ok -> {
                    dao.upsertCache(CacheEntity(finalKey!!, outcome.text, outcome.model, System.currentTimeMillis()))
                    _ui.value = AiUi.Done(task, page, outcome.text, false, outcome.model)
                }
                is AiRouter.Outcome.Failed -> _ui.value = AiUi.Error(describe(outcome))
            }
        }
    }

    /** Returns cleaned page text, [Prompts.NO_TEXT], or null when an error was already shown. */
    private suspend fun obtainText(doc: PdfDocument, docUri: String, page: Int, task: AiTask, s: ReadingSettings): String? {
        val key = sha256("$docUri|$page|${s.sourceLanguage}")
        sessionText.get(key)?.let { return it }
        if (s.persistOcr) {
            dao.cached("ocr|$key")?.let {
                sessionText.put(key, it.text)
                return it.text
            }
        }
        _ui.value = AiUi.Loading(task, page, "در حال استخراج متن صفحه…")
        val jpeg = try {
            withContext(Dispatchers.IO) {
                val bmp = doc.render(page, 1400)
                val out = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 82, out)
                bmp.recycle()
                out.toByteArray()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            _ui.value = AiUi.Error("رندر صفحه برای پردازش ممکن نشد.")
            return null
        }
        return when (val o = router.run(Capability.VISION, Prompts.buildExtract(s, jpeg), s.preferredModel)) {
            is AiRouter.Outcome.Ok -> {
                var text = o.text.trim()
                if (text.contains("NO_TEXT")) text = Prompts.NO_TEXT
                sessionText.put(key, text)
                if (s.persistOcr && text != Prompts.NO_TEXT) {
                    dao.upsertCache(CacheEntity("ocr|$key", text, o.model, System.currentTimeMillis()))
                }
                text
            }
            is AiRouter.Outcome.Failed -> {
                _ui.value = AiUi.Error(describe(o))
                null
            }
        }
    }

    fun dismissResult() {
        job?.cancel()
        _ui.value = AiUi.Idle
    }

    private fun describe(f: AiRouter.Outcome.Failed): String = when (f.reason) {
        AiRouter.Reason.NOT_CONFIGURED ->
            "هیچ کلید معتبری تنظیم نشده است. از تنظیمات، کلید Gemini را اضافه کنید."
        AiRouter.Reason.ALL_COOLING_DOWN -> {
            val sec = ((f.retryAtMs ?: 0L) - System.currentTimeMillis()).coerceAtLeast(0L) / 1000
            "سهمیه‌ی همه‌ی کلیدها/مدل‌ها موقتاً تمام شده. حدود ${formatWait(sec)} دیگر دوباره تلاش کنید."
        }
        AiRouter.Reason.NETWORK -> "اتصال اینترنت برقرار نیست یا سرویس در دسترس نیست."
        AiRouter.Reason.ALL_FAILED -> "درخواست روی همه‌ی کلیدها و مدل‌ها ناموفق بود.\n" + f.detail.take(500)
    }

    // ---------- settings ----------
    fun setSourceLanguage(v: String) = settingsRepo.update { it.copy(sourceLanguage = v) }
    fun setTargetLanguage(v: String) = settingsRepo.update { it.copy(targetLanguage = v) }
    fun setProfile(v: ReadingProfile) = settingsRepo.update { it.copy(profile = v) }
    fun setCustomInstruction(v: String) = settingsRepo.update { it.copy(customInstruction = v) }
    fun setPreferredModel(v: String) = settingsRepo.update { it.copy(preferredModel = v) }
    fun setPersistOcr(v: Boolean) = settingsRepo.update { it.copy(persistOcr = v) }
    fun clearCache() {
        sessionText.evictAll()
        viewModelScope.launch { dao.clearCache() }
    }

    // ---------- providers / models / keys ----------
    fun setProviderEnabled(p: ProviderEntity, enabled: Boolean) {
        viewModelScope.launch { dao.upsertProvider(p.copy(enabled = enabled)) }
    }

    fun moveProvider(p: ProviderEntity, delta: Int) {
        viewModelScope.launch {
            val list = dao.providers()
            val i = list.indexOfFirst { it.id == p.id }
            val j = i + delta
            if (i < 0 || j !in list.indices) return@launch
            val a = list[i]
            val b = list[j]
            dao.upsertProvider(a.copy(position = b.position))
            dao.upsertProvider(b.copy(position = a.position))
        }
    }

    fun deleteProvider(p: ProviderEntity) {
        viewModelScope.launch {
            dao.deleteKeysOf(p.id)
            dao.deleteModelsOf(p.id)
            dao.deleteProvider(p.id)
        }
    }

    fun addModel(providerId: String, name: String, text: Boolean, vision: Boolean) {
        if (name.isBlank()) return
        viewModelScope.launch {
            val pos = (models.value.filter { it.providerId == providerId }.maxOfOrNull { it.position } ?: -1) + 1
            dao.upsertModel(ModelEntity(UUID.randomUUID().toString(), providerId, name.trim(), text, vision, true, pos))
        }
    }

    fun setModelEnabled(m: ModelEntity, enabled: Boolean) {
        viewModelScope.launch { dao.upsertModel(m.copy(enabled = enabled)) }
    }

    fun deleteModel(m: ModelEntity) { viewModelScope.launch { dao.deleteModel(m.id) } }

    fun addKey(providerId: String, label: String, secret: String) {
        if (secret.isBlank()) return
        viewModelScope.launch {
            val pos = (keys.value.filter { it.providerId == providerId }.maxOfOrNull { it.position } ?: -1) + 1
            dao.upsertKey(
                ApiKeyEntity(
                    id = UUID.randomUUID().toString(), providerId = providerId,
                    label = label.trim().ifEmpty { "کلید ${pos + 1}" },
                    secret = SecretBox.encrypt(secret.trim()), position = pos,
                )
            )
        }
    }

    fun setKeyDisabled(k: ApiKeyEntity, disabled: Boolean) {
        viewModelScope.launch {
            dao.upsertKey(
                k.copy(
                    status = if (disabled) KeyStatus.DISABLED.name else KeyStatus.ACTIVE.name,
                    cooldownUntil = 0,
                )
            )
        }
    }

    fun deleteKey(k: ApiKeyEntity) { viewModelScope.launch { dao.deleteKey(k.id) } }

    fun testKey(k: ApiKeyEntity) {
        _testMessages.value = _testMessages.value + (k.id to "در حال تست…")
        viewModelScope.launch {
            val msg = try { router.test(k.id) } catch (e: CancellationException) { throw e } catch (e: Exception) { "خطا: ${e.message}" }
            _testMessages.value = _testMessages.value + (k.id to msg)
        }
    }
}

fun formatWait(seconds: Long): String = when {
    seconds < 90 -> "$seconds ثانیه"
    seconds < 5400 -> "${seconds / 60} دقیقه"
    else -> "${seconds / 3600} ساعت"
}
