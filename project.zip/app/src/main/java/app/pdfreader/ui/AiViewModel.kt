package app.pdfreader.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.pdfreader.ReaderApp
import app.pdfreader.ai.AiRouter
import app.pdfreader.ai.AiTask
import app.pdfreader.ai.ApiKeyEntity
import app.pdfreader.ai.CacheEntity
import app.pdfreader.ai.Capability
import app.pdfreader.ai.KeyStatus
import app.pdfreader.ai.ModelEntity
import app.pdfreader.ai.Prompts
import app.pdfreader.ai.ProviderEntity
import app.pdfreader.ai.ProviderTypes
import app.pdfreader.ai.ReadingProfile
import app.pdfreader.ai.ReadingSettings
import app.pdfreader.ai.SecretBox
import app.pdfreader.core.pdf.PdfDocument
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.util.UUID

sealed interface AiUi {
    data object Idle : AiUi
    class Loading(val task: AiTask) : AiUi
    class Done(val task: AiTask, val text: String, val fromCache: Boolean, val model: String) : AiUi
    class Error(val message: String) : AiUi
}

class AiViewModel(app: Application) : AndroidViewModel(app) {
    private val container = (app as ReaderApp).container
    private val dao = container.aiDao
    private val router = container.router
    private val settingsRepo = container.settings

    val providers = dao.observeProviders().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val models = dao.observeModels().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val keys = dao.observeKeys().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val cacheBytes = dao.observeCacheBytes().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0L)
    val settings: StateFlow<ReadingSettings> = settingsRepo.state

    private val _ui = MutableStateFlow<AiUi>(AiUi.Idle)
    val ui: StateFlow<AiUi> = _ui.asStateFlow()

    private val _testMessages = MutableStateFlow<Map<String, String>>(emptyMap())
    val testMessages: StateFlow<Map<String, String>> = _testMessages.asStateFlow()

    private var job: Job? = null

    init {
        viewModelScope.launch {
            if (dao.providerCount() == 0) {
                // Starter entry only: names are editable and nothing here is hard-wired into the router.
                dao.upsertProvider(
                    ProviderEntity("gemini", "Gemini", ProviderTypes.GEMINI, ProviderTypes.defaultBaseUrl(ProviderTypes.GEMINI), true, 0)
                )
                dao.upsertModel(ModelEntity(UUID.randomUUID().toString(), "gemini", "gemini-2.5-flash", true, true, true, 0))
            }
        }
    }

    // ---------- page tasks ----------
    fun runPageTask(doc: PdfDocument, docUri: String, page: Int, task: AiTask) {
        job?.cancel()
        _ui.value = AiUi.Loading(task)
        job = viewModelScope.launch {
            val s = settings.value
            val ck = cacheKey(docUri, page, task, s)
            dao.cached(ck)?.let {
                _ui.value = AiUi.Done(task, it.text, true, it.model)
                return@launch
            }
            val jpeg = try {
                withContext(Dispatchers.IO) {
                    val bmp = doc.render(page, 1400)
                    val out = ByteArrayOutputStream()
                    bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, out)
                    bmp.recycle()
                    out.toByteArray()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _ui.value = AiUi.Error("رندر صفحه برای ارسال به AI ممکن نشد.")
                return@launch
            }
            when (val o = router.run(Capability.VISION, Prompts.build(task, s, jpeg))) {
                is AiRouter.Outcome.Ok -> {
                    dao.upsertCache(CacheEntity(ck, o.text, o.model, System.currentTimeMillis()))
                    _ui.value = AiUi.Done(task, o.text, false, o.model)
                }
                is AiRouter.Outcome.Failed -> _ui.value = AiUi.Error(describe(o))
            }
        }
    }

    fun dismissResult() {
        job?.cancel()
        _ui.value = AiUi.Idle
    }

    private fun describe(f: AiRouter.Outcome.Failed): String = when (f.reason) {
        AiRouter.Reason.NOT_CONFIGURED ->
            "هیچ کلید معتبری با مدل دارای قابلیت تصویر تنظیم نشده است. از تنظیمات، کلید و مدل را اضافه کنید."
        AiRouter.Reason.ALL_COOLING_DOWN -> {
            val sec = ((f.retryAtMs ?: 0L) - System.currentTimeMillis()).coerceAtLeast(0L) / 1000
            "همه‌ی کلیدها موقتاً در انتظار (cooldown) هستند. حدود ${formatWait(sec)} دیگر دوباره تلاش کنید."
        }
        AiRouter.Reason.NETWORK -> "اتصال اینترنت برقرار نیست یا سرویس در دسترس نیست."
        AiRouter.Reason.ALL_FAILED -> "درخواست روی همه‌ی مسیرها ناموفق بود.\n" + f.detail.take(400)
    }

    private fun cacheKey(docUri: String, page: Int, task: AiTask, s: ReadingSettings): String {
        val raw = "$docUri|$page|${task.name}|${s.targetLanguage}|${s.profile.name}|" +
            (if (s.profile == ReadingProfile.CUSTOM) s.customInstruction else "")
        return MessageDigest.getInstance("SHA-256").digest(raw.toByteArray())
            .joinToString("") { "%02x".format(it) }
    }

    // ---------- settings ----------
    fun setLanguage(v: String) = settingsRepo.update { it.copy(targetLanguage = v) }
    fun setProfile(v: ReadingProfile) = settingsRepo.update { it.copy(profile = v) }
    fun setCustomInstruction(v: String) = settingsRepo.update { it.copy(customInstruction = v) }
    fun clearCache() { viewModelScope.launch { dao.clearCache() } }

    // ---------- providers / models / keys ----------
    fun addProvider(name: String, type: String, baseUrl: String) {
        viewModelScope.launch {
            val pos = (providers.value.maxOfOrNull { it.position } ?: -1) + 1
            dao.upsertProvider(
                ProviderEntity(UUID.randomUUID().toString(), name.trim().ifEmpty { ProviderTypes.label(type) }, type,
                    baseUrl.trim().ifEmpty { ProviderTypes.defaultBaseUrl(type) }, true, pos)
            )
        }
    }

    fun setProviderEnabled(p: ProviderEntity, enabled: Boolean) {
        viewModelScope.launch { dao.upsertProvider(p.copy(enabled = enabled)) }
    }

    fun moveProvider(p: ProviderEntity, delta: Int) {
        viewModelScope.launch {
            val list = dao.providers()
            val i = list.indexOfFirst { it.id == p.id }
            val j = i + delta
            if (i < 0 || j !in list.indices) return@launch
            val a = list[i]
            val b = list[j]
            dao.upsertProvider(a.copy(position = b.position))
            dao.upsertProvider(b.copy(position = a.position))
        }
    }

    fun deleteProvider(p: ProviderEntity) {
        viewModelScope.launch {
            dao.deleteKeysOf(p.id)
            dao.deleteModelsOf(p.id)
            dao.deleteProvider(p.id)
        }
    }

    fun addModel(providerId: String, name: String, text: Boolean, vision: Boolean) {
        if (name.isBlank()) return
        viewModelScope.launch {
            val pos = (models.value.filter { it.providerId == providerId }.maxOfOrNull { it.position } ?: -1) + 1
            dao.upsertModel(ModelEntity(UUID.randomUUID().toString(), providerId, name.trim(), text, vision, true, pos))
        }
    }

    fun setModelEnabled(m: ModelEntity, enabled: Boolean) {
        viewModelScope.launch { dao.upsertModel(m.copy(enabled = enabled)) }
    }

    fun deleteModel(m: ModelEntity) { viewModelScope.launch { dao.deleteModel(m.id) } }

    fun addKey(providerId: String, label: String, secret: String) {
        if (secret.isBlank()) return
        viewModelScope.launch {
            val pos = (keys.value.filter { it.providerId == providerId }.maxOfOrNull { it.position } ?: -1) + 1
            dao.upsertKey(
                ApiKeyEntity(
                    id = UUID.randomUUID().toString(), providerId = providerId,
                    label = label.trim().ifEmpty { "کلید ${pos + 1}" },
                    secret = SecretBox.encrypt(secret.trim()), position = pos,
                )
            )
        }
    }

    fun setKeyDisabled(k: ApiKeyEntity, disabled: Boolean) {
        viewModelScope.launch {
            dao.upsertKey(
                k.copy(
                    status = if (disabled) KeyStatus.DISABLED.name else KeyStatus.ACTIVE.name,
                    cooldownUntil = 0,
                )
            )
        }
    }

    fun deleteKey(k: ApiKeyEntity) { viewModelScope.launch { dao.deleteKey(k.id) } }

    fun testKey(k: ApiKeyEntity) {
        _testMessages.value = _testMessages.value + (k.id to "در حال تست…")
        viewModelScope.launch {
            val msg = try { router.test(k.id) } catch (e: CancellationException) { throw e } catch (e: Exception) { "خطا: ${e.message}" }
            _testMessages.value = _testMessages.value + (k.id to msg)
        }
    }
}

fun formatWait(seconds: Long): String = when {
    seconds < 90 -> "$seconds ثانیه"
    seconds < 5400 -> "${seconds / 60} دقیقه"
    else -> "${seconds / 3600} ساعت"
}
