package app.pdfreader.ui

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.annotation.StringRes
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.pdfreader.R
import app.pdfreader.ReaderApp
import app.pdfreader.core.pdf.PdfDocument
import app.pdfreader.core.pdf.PdfError
import app.pdfreader.core.pdf.PdfOpenResult
import app.pdfreader.data.DocumentEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface ReaderState {
    data object Closed : ReaderState
    data object Loading : ReaderState
    data class Error(@StringRes val message: Int) : ReaderState
    class Open(
        val uri: String,
        val name: String,
        val doc: PdfDocument,
        val aspects: List<Float>,
        val startPage: Int,
        val startOffset: Int,
    ) : ReaderState
}

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val container = (app as ReaderApp).container
    private val dao = container.db.documentDao()

    val documents: StateFlow<List<DocumentEntity>> =
        dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _reader = MutableStateFlow<ReaderState>(ReaderState.Closed)
    val reader: StateFlow<ReaderState> = _reader.asStateFlow()

    private var openJob: Job? = null

    fun openDocument(uri: Uri) {
        openJob?.cancel()
        closeCurrentDoc()
        _reader.value = ReaderState.Loading
        openJob = viewModelScope.launch {
            when (val result = container.engine.open(uri)) {
                is PdfOpenResult.Error -> _reader.value = ReaderState.Error(
                    when (result.kind) {
                        PdfError.ENCRYPTED -> R.string.err_encrypted
                        PdfError.CORRUPT -> R.string.err_corrupt
                        PdfError.UNREADABLE -> R.string.err_unreadable
                    }
                )
                is PdfOpenResult.Ok -> {
                    val doc = result.doc
                    try {
                        val key = uri.toString()
                        val old = dao.get(key)
                        val name = old?.name ?: displayName(uri)
                        val aspects = loadAspects(doc)
                        val page = (old?.lastPage ?: 0).coerceIn(0, doc.pageCount - 1)
                        val offset = old?.lastOffset ?: 0
                        dao.upsert(
                            DocumentEntity(
                                uri = key, name = name, pageCount = doc.pageCount,
                                lastPage = page, lastOffset = offset,
                                favorite = old?.favorite ?: false,
                                lastOpened = System.currentTimeMillis(),
                            )
                        )
                        _reader.value = ReaderState.Open(key, name, doc, aspects, page, offset)
                    } catch (e: CancellationException) {
                        doc.close()
                        throw e
                    } catch (e: Exception) {
                        doc.close()
                        _reader.value = ReaderState.Error(R.string.err_corrupt)
                    }
                }
            }
        }
    }

    private suspend fun loadAspects(doc: PdfDocument): List<Float> {
        val first = doc.pageAspect(0)
        return List(doc.pageCount) { first }
    }

    private fun displayName(uri: Uri): String {
        val fromProvider = try {
            getApplication<Application>().contentResolver
                .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (e: Exception) {
            null
        }
        val raw = fromProvider ?: uri.lastPathSegment ?: "PDF"
        return raw.removeSuffix(".pdf").removeSuffix(".PDF")
    }

    fun saveProgress(uri: String, page: Int, offset: Int) {
        viewModelScope.launch { dao.updateProgress(uri, page, offset) }
    }

    fun toggleFavorite(doc: DocumentEntity) {
        viewModelScope.launch { dao.setFavorite(doc.uri, !doc.favorite) }
    }

    fun removeFromList(doc: DocumentEntity) {
        viewModelScope.launch { dao.delete(doc.uri) }
    }

    fun closeReader() {
        openJob?.cancel()
        closeCurrentDoc()
        _reader.value = ReaderState.Closed
    }

    private fun closeCurrentDoc() {
        (_reader.value as? ReaderState.Open)?.doc?.close()
    }

    override fun onCleared() {
        closeCurrentDoc()
        super.onCleared()
    }

    private companion object {
        const val MAX_EXACT_PAGES = 1500
    }
}
