package app.pdfreader.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import app.pdfreader.ai.AiTask

private fun taskTitle(t: AiTask) = when (t) {
    AiTask.EXTRACT -> "متن استخراج‌شده"
    AiTask.TRANSLATE -> "ترجمه‌ی صفحه"
    AiTask.EXPLAIN -> "توضیح صفحه"
    AiTask.SUMMARIZE -> "خلاصه‌ی صفحه"
}

fun looksRtl(s: String): Boolean {
    for (ch in s) {
        when (Character.getDirectionality(ch)) {
            Character.DIRECTIONALITY_RIGHT_TO_LEFT, Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC -> return true
            Character.DIRECTIONALITY_LEFT_TO_RIGHT -> return false
            else -> {}
        }
    }
    return false
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiResultSheet(state: AiUi, onDismiss: () -> Unit) {
    if (state is AiUi.Idle) return
    val clipboard = LocalClipboardManager.current
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            when (state) {
                is AiUi.Loading -> {
                    Text(taskTitle(state.task), style = MaterialTheme.typography.titleMedium)
                    CircularProgressIndicator()
                }
                is AiUi.Done -> {
                    Text(taskTitle(state.task), style = MaterialTheme.typography.titleMedium)
                    val dir = if (looksRtl(state.text)) LayoutDirection.Rtl else LayoutDirection.Ltr
                    CompositionLocalProvider(LocalLayoutDirection provides dir) {
                        Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
                            SelectionContainer {
                                Text(state.text, style = MaterialTheme.typography.bodyLarge)
                            }
                        }
                    }
                    Text(
                        (if (state.fromCache) "از حافظه‌ی نهان (بدون درخواست جدید)" else "مدل: ${state.model}"),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Row {
                        TextButton(onClick = { clipboard.setText(AnnotatedString(state.text)) }) { Text("کپی") }
                        TextButton(onClick = onDismiss) { Text("بستن") }
                    }
                }
                is AiUi.Error -> {
                    Text(state.message, color = MaterialTheme.colorScheme.error)
                    TextButton(onClick = onDismiss) { Text("بستن") }
                }
                AiUi.Idle -> {}
            }
        }
    }
}
