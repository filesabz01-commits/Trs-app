package app.pdfreader.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import app.pdfreader.ai.AiTask

private fun taskTitle(t: AiTask, page: Int) = when (t) {
    AiTask.EXTRACT -> "متن صفحه ${page + 1}"
    AiTask.TRANSLATE -> "ترجمه‌ی صفحه ${page + 1}"
    AiTask.EXPLAIN -> "توضیح صفحه ${page + 1}"
    AiTask.SUMMARIZE -> "خلاصه‌ی صفحه ${page + 1}"
}

/** True when RTL letters dominate this paragraph (so a Persian paragraph that starts with "P&ID" stays RTL). */
fun isRtlParagraph(s: String): Boolean {
    var rtl = 0
    var ltr = 0
    for (ch in s) {
        when (Character.getDirectionality(ch)) {
            Character.DIRECTIONALITY_RIGHT_TO_LEFT, Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC -> rtl++
            Character.DIRECTIONALITY_LEFT_TO_RIGHT -> ltr++
            else -> {}
        }
    }
    return rtl > 0 && rtl >= ltr
}

/** The model sometimes answers with Markdown; show it as clean text. */
fun cleanMarkdown(s: String): String = s.lines().joinToString("\n") { line ->
    line.replace("**", "").replace("__", "")
        .replace(Regex("^\\s*#{1,6}\\s*"), "")
        .replace(Regex("^(\\s*)[*\\-]\\s+"), "\$1• ")
}

@Composable
private fun ResultText(text: String) {
    val blocks = cleanMarkdown(text).split(Regex("\n\\s*\n")).filter { it.isNotBlank() }
    Column(
        Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        SelectionContainer {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                for (b in blocks) {
                    val dir = if (isRtlParagraph(b)) LayoutDirection.Rtl else LayoutDirection.Ltr
                    CompositionLocalProvider(LocalLayoutDirection provides dir) {
                        Text(b.trim(), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiResultSheet(state: AiUi, onDismiss: () -> Unit) {
    if (state is AiUi.Idle) return
    val clipboard = LocalClipboardManager.current
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            when (state) {
                is AiUi.Loading -> {
                    Text(taskTitle(state.task, state.page), style = MaterialTheme.typography.titleMedium)
                    CircularProgressIndicator()
                    Text(state.phase, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                is AiUi.Streaming -> {
                    Text(taskTitle(state.task, state.page), style = MaterialTheme.typography.titleMedium)
                    ResultText(state.text)
                    Text(
                        "در حال دریافت…",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                is AiUi.Done -> {
                    Text(taskTitle(state.task, state.page), style = MaterialTheme.typography.titleMedium)
                    ResultText(state.text)
                    Text(
                        (if (state.fromCache) "از حافظه‌ی نهان (بدون درخواست جدید)" else "مدل: ${state.model}"),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Row {
                        TextButton(onClick = { clipboard.setText(AnnotatedString(state.text)) }) { Text("کپی") }
                        TextButton(onClick = onDismiss) { Text("بستن") }
                    }
                }
                is AiUi.Error -> {
                    Text(state.message, color = MaterialTheme.colorScheme.error)
                    TextButton(onClick = onDismiss) { Text("بستن") }
                }
                AiUi.Idle -> {}
            }
        }
    }
}
