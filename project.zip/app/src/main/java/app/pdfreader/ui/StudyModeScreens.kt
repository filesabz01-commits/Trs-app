package app.pdfreader.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import app.pdfreader.ai.AiTask
import app.pdfreader.ai.Capability
import app.pdfreader.ai.AiRouter
import app.pdfreader.ai.PageTextService
import app.pdfreader.ai.PT
import app.pdfreader.ai.Prompts
import app.pdfreader.ai.ReadingSettings
import app.pdfreader.core.pdf.PdfDocument
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class StudyTool { Vocab, Grammar, Quiz, Exercise }

/**
 * Full-screen Study Mode tool. Reuses extract/OCR cache via [PageTextService]
 * so Vocab / Grammar / Quiz share one page text and avoid extra OCR tokens.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyToolScreen(
    tool: StudyTool,
    doc: PdfDocument,
    docUri: String,
    page: Int,
    settings: ReadingSettings,
    pageText: PageTextService,
    router: AiRouter,
    onDismiss: () -> Unit,
) {
    val title = when (tool) {
        StudyTool.Vocab -> "واژگان صفحه"
        StudyTool.Grammar -> "گرامر صفحه"
        StudyTool.Quiz -> "آزمون صفحه"
        StudyTool.Exercise -> "حل تمرین صفحه"
    }
    var phase by remember { mutableStateOf("در حال آماده‌سازی…") }
    var body by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    val clipboard = LocalClipboardManager.current

    LaunchedEffect(tool, page) {
        loading = true
        error = null
        phase = "خواندن متن صفحه (کش OCR در صورت وجود)…"
        try {
            // Prefer cache; if empty, force OCR so scanned / cleaned-away pages still work
            var ex = pageText.extract(doc, docUri, page, settings, force = false)
            if (ex is PT.NoText) {
                phase = "متن خالی بود؛ OCR اجباری…"
                ex = pageText.extract(doc, docUri, page, settings, force = true)
            }
            val text = when (ex) {
                is PT.Ok -> ex.text
                PT.NoText -> {
                    error = "متن این صفحه استخراج نشد (اسکن نامشخص یا صفحهٔ خالی)."
                    loading = false
                    return@LaunchedEffect
                }
                is PT.Fail -> {
                    error = ex.message
                    loading = false
                    return@LaunchedEffect
                }
            }
            phase = "در حال تولید محتوا با AI…"
            val prompt = when (tool) {
                StudyTool.Vocab -> """
                    You are a study coach. From the PAGE TEXT extract ONLY important lesson-relevant vocabulary
                    (technical terms, key nouns/verbs, acronyms). Skip trivial words.
                    Output Markdown in the user's target study language (${settings.handoutLanguage}):
                    ## واژگان کلیدی
                    For each item:
                    - **word** /phonetic/
                      - معنی:
                      - مثال از متن:
                      - مترادف (اختیاری):
                    Max 12 items. PAGE TEXT:
                    $text
                """.trimIndent()
                StudyTool.Grammar -> """
                    Analyze grammar patterns in this page for a language learner. Reply in ${settings.handoutLanguage} Markdown:
                    ## ساختارهای گرامری
                    ## نکات مهم
                    ## مثال‌ها از متن
                    PAGE TEXT:
                    $text
                """.trimIndent()
                StudyTool.Quiz -> """
                    Create a multiple-choice quiz (8–12 questions, 4 options A-D) from the page.
                    Language: ${settings.handoutLanguage}. Markdown format:
                    ## کوئیز
                    ### Q1. ...
                    A) ...
                    B) ...
                    C) ...
                    D) ...
                    At the end:
                    ## پاسخ‌نامه
                    1-B (brief reason)
                    PAGE TEXT:
                    $text
                """.trimIndent()
                StudyTool.Exercise -> """
                    If the page contains exercises (blanks, questions), solve them step by step.
                    If not, invent 5 short comprehension exercises from the page then answer them.
                    Language: ${settings.handoutLanguage}. Markdown with ## تمرین‌ها and ## پاسخ‌ها.
                    PAGE TEXT:
                    $text
                """.trimIndent()
            }
            val req = app.pdfreader.ai.AiRequest(prompt = prompt, task = AiTask.EXPLAIN, maxOutputTokens = 4096)
            when (val o = withContext(Dispatchers.IO) {
                router.run(Capability.TEXT, req, settings.preferredModel)
            }) {
                is AiRouter.Outcome.Ok -> body = o.text
                is AiRouter.Outcome.Failed -> error = pageText.describe(o)
            }
        } catch (e: Exception) {
            error = e.message ?: e.javaClass.simpleName
        } finally {
            loading = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "بستن")
                    }
                },
                actions = {
                    if (body.isNotBlank()) {
                        TextButton(onClick = { clipboard.setText(AnnotatedString(body)) }) {
                            Text("کپی")
                        }
                    }
                },
            )
        },
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .padding(16.dp),
        ) {
            when {
                loading -> {
                    Column(
                        Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        CircularProgressIndicator()
                        Spacer(Modifier.height(12.dp))
                        Text(phase, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                error != null -> {
                    Text(error!!, color = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = onDismiss) { Text("بستن") }
                }
                else -> {
                    Column(
                        Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        AiMarkdownBody(text = body, isRtl = true)
                    }
                }
            }
        }
    }
}
