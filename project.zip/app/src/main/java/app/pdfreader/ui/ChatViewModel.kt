package app.pdfreader.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.pdfreader.ReaderApp
import app.pdfreader.ai.AiRouter
import app.pdfreader.ai.Capability
import app.pdfreader.ai.PT
import app.pdfreader.ai.Prompts
import app.pdfreader.core.pdf.PdfDocument
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ChatMsg(val fromUser: Boolean, val text: String, val page: Int, val pending: Boolean = false)

/** Chat about the page the user is looking at. The page text comes from the same cached extraction as translation. */
class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val container = (app as ReaderApp).container
    private val texts = container.pageText
    private val router = container.router
    private val settings = container.settings

    private val _messages = MutableStateFlow<List<ChatMsg>>(emptyList())
    val messages: StateFlow<List<ChatMsg>> = _messages.asStateFlow()
    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()
    private var job: Job? = null

    private fun replaceLast(text: String, pending: Boolean) {
        val list = _messages.value
        if (list.isEmpty()) return
        val last = list.last()
        _messages.value = list.dropLast(1) + ChatMsg(false, text, last.page, pending)
    }

    private fun selectRelevantContext(text: String, question: String, maxChars: Int = 6000): String {
        if (text.length <= maxChars) return text
        val paragraphs = text.split(Regex("\n{2,}"))
        if (paragraphs.size <= 1) return text.take(maxChars)

        val keywords = question.lowercase()
            .split(Regex("[\\s.,;:!؟?()\\-\"']+"))
            .filter { it.length >= 3 }
            .toSet()

        val scored = paragraphs.mapIndexed { idx, p ->
            val pLower = p.lowercase()
            val score = keywords.count { kw -> pLower.contains(kw) } + (if (idx == 0) 1 else 0)
            Triple(idx, p, score)
        }

        val selected = mutableListOf<Pair<Int, String>>()
        var curLen = 0
        val first = scored.first()
        selected.add(first.first to first.second)
        curLen += first.second.length + 2

        val sortedByScore = scored.drop(1).sortedByDescending { it.third }
        for (item in sortedByScore) {
            if (curLen + item.second.length + 2 <= maxChars) {
                selected.add(item.first to item.second)
                curLen += item.second.length + 2
            }
        }
        return selected.sortedBy { it.first }.joinToString("\n\n") { it.second }
    }

    fun send(doc: PdfDocument, docUri: String, page: Int, question: String) {
        val q = question.trim()
        if (q.isEmpty() || _busy.value) return
        // Last 3 turns (max 6 messages: user + assistant), assistant replies capped to 500 chars
        val history = _messages.value.filter { !it.pending }.takeLast(6)
            .joinToString("\n") { (if (it.fromUser) "User: " else "Assistant: ") + it.text.take(500) }
        _messages.value = _messages.value + ChatMsg(true, q, page) + ChatMsg(false, "", page, pending = true)
        _busy.value = true
        job = viewModelScope.launch {
            try {
                val s = settings.state.value
                replaceLast("در حال خواندن صفحه ${page + 1}…", true)
                val rawPageText = when (val ex = texts.extract(doc, docUri, page, s)) {
                    is PT.Ok -> ex.text
                    PT.NoText -> ""
                    is PT.Fail -> {
                        replaceLast("⚠ " + ex.message, false)
                        return@launch
                    }
                }
                val pageText = selectRelevantContext(rawPageText, q, 6000)
                replaceLast("…", true)
                val req = Prompts.buildChat(s, page, pageText, history, q)
                when (val o = router.run(Capability.TEXT, req, s.preferredModel) { partial -> replaceLast(partial, true) }) {
                    is AiRouter.Outcome.Ok -> replaceLast(o.text, false)
                    is AiRouter.Outcome.Failed -> replaceLast("⚠ " + texts.describe(o), false)
                }
            } finally {
                _busy.value = false
            }
        }
    }

    fun clear() {
        job?.cancel()
        _busy.value = false
        _messages.value = emptyList()
    }
}
