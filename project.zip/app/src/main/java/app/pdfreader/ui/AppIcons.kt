package app.pdfreader.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Small, soft, hand-drawn icons (no emoji): the same look on every phone and every language. */
enum class AppIcon { Speaker, ReadTranslate, Globe, Summary, Sparkle, More, Explain, Ocr, Range, Play, Pause, Next, Prev }

@Composable
fun AppIconView(icon: AppIcon, tint: Color, modifier: Modifier = Modifier, size: Dp = 24.dp) {
    Canvas(modifier.size(size)) {
        val u = this.size.minDimension / 24f // everything is designed on a 24 x 24 grid
        val stroke = Stroke(width = 1.9f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun p(x: Float, y: Float) = Offset(x * u, y * u)
        fun line(x1: Float, y1: Float, x2: Float, y2: Float) =
            drawLine(tint, p(x1, y1), p(x2, y2), strokeWidth = 1.9f * u, cap = StrokeCap.Round)
        when (icon) {
            AppIcon.Speaker -> {
                speaker(tint, u)
                arc(tint, u, 12f, 12f, 4.5f, stroke)
                arc(tint, u, 12f, 12f, 8f, stroke)
            }
            AppIcon.Globe -> globe(tint, u, 12f, 12f, 9f, stroke)
            AppIcon.ReadTranslate -> {
                globe(tint, u, 10f, 12f, 7f, stroke)
                arc(tint, u, 17f, 12f, 3f, stroke)
                arc(tint, u, 17f, 12f, 6f, stroke)
            }
            AppIcon.Summary -> {
                line(4f, 7f, 20f, 7f); line(4f, 12f, 16f, 12f); line(4f, 17f, 11f, 17f)
            }
            AppIcon.Sparkle -> {
                val path = Path().apply {
                    moveTo(12f * u, 2f * u)
                    cubicTo(12.8f * u, 8f * u, 16f * u, 11.2f * u, 22f * u, 12f * u)
                    cubicTo(16f * u, 12.8f * u, 12.8f * u, 16f * u, 12f * u, 22f * u)
                    cubicTo(11.2f * u, 16f * u, 8f * u, 12.8f * u, 2f * u, 12f * u)
                    cubicTo(8f * u, 11.2f * u, 11.2f * u, 8f * u, 12f * u, 2f * u)
                    close()
                }
                drawPath(path, tint, style = Fill)
            }
            AppIcon.More -> {
                drawCircle(tint, 1.9f * u, p(5f, 12f)); drawCircle(tint, 1.9f * u, p(12f, 12f)); drawCircle(tint, 1.9f * u, p(19f, 12f))
            }
            AppIcon.Explain -> {
                drawCircle(tint, 6f * u, p(12f, 10f), style = stroke)
                line(9.5f, 18f, 14.5f, 18f); line(10.5f, 21f, 13.5f, 21f)
            }
            AppIcon.Ocr -> {
                line(4f, 8f, 4f, 4f); line(4f, 4f, 8f, 4f)
                line(16f, 4f, 20f, 4f); line(20f, 4f, 20f, 8f)
                line(20f, 16f, 20f, 20f); line(20f, 20f, 16f, 20f)
                line(8f, 20f, 4f, 20f); line(4f, 20f, 4f, 16f)
                line(8f, 12f, 16f, 12f)
            }
            AppIcon.Range -> {
                drawRoundRect(tint, p(3f, 7f), Size(12f * u, 14f * u), androidx.compose.ui.geometry.CornerRadius(3f * u, 3f * u), style = stroke)
                drawRoundRect(tint, p(9f, 3f), Size(12f * u, 14f * u), androidx.compose.ui.geometry.CornerRadius(3f * u, 3f * u), style = stroke)
            }
            AppIcon.Play -> {
                val path = Path().apply { moveTo(8f * u, 5f * u); lineTo(19f * u, 12f * u); lineTo(8f * u, 19f * u); close() }
                drawPath(path, tint, style = Fill)
            }
            AppIcon.Pause -> {
                val r = androidx.compose.ui.geometry.CornerRadius(1.5f * u, 1.5f * u)
                drawRoundRect(tint, p(6.5f, 5f), Size(4f * u, 14f * u), r)
                drawRoundRect(tint, p(13.5f, 5f), Size(4f * u, 14f * u), r)
            }
            AppIcon.Next -> {
                val path = Path().apply { moveTo(6f * u, 5f * u); lineTo(16f * u, 12f * u); lineTo(6f * u, 19f * u); close() }
                drawPath(path, tint, style = Fill)
                drawRoundRect(tint, p(17f, 5f), Size(2.6f * u, 14f * u), androidx.compose.ui.geometry.CornerRadius(1.3f * u, 1.3f * u))
            }
            AppIcon.Prev -> {
                val path = Path().apply { moveTo(18f * u, 5f * u); lineTo(8f * u, 12f * u); lineTo(18f * u, 19f * u); close() }
                drawPath(path, tint, style = Fill)
                drawRoundRect(tint, p(4.4f, 5f), Size(2.6f * u, 14f * u), androidx.compose.ui.geometry.CornerRadius(1.3f * u, 1.3f * u))
            }
        }
    }
}

private fun DrawScope.speaker(tint: Color, u: Float) {
    val path = Path().apply {
        moveTo(3f * u, 9.5f * u); lineTo(7f * u, 9.5f * u); lineTo(12f * u, 5f * u)
        lineTo(12f * u, 19f * u); lineTo(7f * u, 14.5f * u); lineTo(3f * u, 14.5f * u); close()
    }
    drawPath(path, tint, style = Fill)
}

/** A sound wave: an arc on the right of the point (cx, cy). */
private fun DrawScope.arc(tint: Color, u: Float, cx: Float, cy: Float, r: Float, stroke: Stroke) {
    drawArc(
        color = tint, startAngle = -40f, sweepAngle = 80f, useCenter = false,
        topLeft = Offset((cx - r + 4f) * u, (cy - r) * u), size = Size(2 * r * u, 2 * r * u), style = stroke,
    )
}

private fun DrawScope.globe(tint: Color, u: Float, cx: Float, cy: Float, r: Float, stroke: Stroke) {
    drawCircle(tint, r * u, Offset(cx * u, cy * u), style = stroke)
    drawOval(tint, Offset((cx - r * 0.42f) * u, (cy - r) * u), Size(r * 0.84f * u, 2 * r * u), style = stroke)
    drawLine(tint, Offset((cx - r) * u, cy * u), Offset((cx + r) * u, cy * u), strokeWidth = 1.9f * u, cap = StrokeCap.Round)
}
