package app.pdfreader.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.util.LruCache
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import app.pdfreader.R
import app.pdfreader.ai.AiTask
import app.pdfreader.core.pdf.PdfDocument
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.launch

private const val MAX_SCALE = 5f
private const val DOUBLE_TAP_SCALE = 2.5f

private val InvertMatrix = ColorMatrix(
    floatArrayOf(
        -1f, 0f, 0f, 0f, 255f,
        0f, -1f, 0f, 0f, 255f,
        0f, 0f, -1f, 0f, 255f,
        0f, 0f, 0f, 1f, 0f,
    )
)

@OptIn(FlowPreview::class, ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(
    state: ReaderState.Open,
    favorite: Boolean,
    onBack: () -> Unit,
    onToggleFavorite: () -> Unit,
    onProgress: (page: Int, offset: Int) -> Unit,
    ai: AiUi,
    onAiTask: (AiTask, Int) -> Unit,
    onAiDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val doc = state.doc
    val listState = rememberLazyListState(state.startPage, state.startOffset)

    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var barsVisible by remember { mutableStateOf(true) }
    var night by rememberSaveable { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var jumpOpen by remember { mutableStateOf(false) }
    // The page under the CENTER of the screen (not the first partly-visible one).
    val currentPage by remember {
        derivedStateOf {
            val info = listState.layoutInfo
            val center = (info.viewportStartOffset + info.viewportEndOffset) / 2
            val hit = info.visibleItemsInfo.minByOrNull {
                val end = it.offset + it.size
                if (center in it.offset until end) 0 else minOf(kotlin.math.abs(center - it.offset), kotlin.math.abs(center - end))
            }
            (hit?.index ?: listState.firstVisibleItemIndex) + 1
        }
    }
    // Page proportions start uniform (fast open) and are corrected as each page is rendered.
    val aspects = remember(doc) { mutableStateListOf<Float>().apply { addAll(state.aspects) } }

    // Resume reading: remember the exact spot (page + pixel offset), debounced.
    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex to listState.firstVisibleItemScrollOffset }
            .debounce(600)
            .collect { (p, o) -> onProgress(p, o) }
    }
    DisposableEffect(listState) {
        onDispose { onProgress(listState.firstVisibleItemIndex, listState.firstVisibleItemScrollOffset) }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(if (night) Color.Black else MaterialTheme.colorScheme.surfaceVariant)
    ) {
        BoxWithConstraints(
            Modifier
                .fillMaxSize()
                .clipToBounds()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onDoubleTap = {
                            if (scale > 1f) {
                                scale = 1f
                                offsetX = 0f
                            } else {
                                scale = DOUBLE_TAP_SCALE
                            }
                        },
                        onTap = { barsVisible = !barsVisible },
                    )
                }
                .pointerInput(Unit) {
                    // Pinch-zoom + pan. Runs in the Initial pass so it can take over from the list
                    // only when two fingers are down or the page is already zoomed in.
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                        do {
                            val event = awaitPointerEvent(PointerEventPass.Initial)
                            val multi = event.changes.count { it.pressed } >= 2
                            if (multi || scale > 1f) {
                                val zoom = event.calculateZoom()
                                val pan = event.calculatePan()
                                if (zoom != 1f || pan != Offset.Zero) {
                                    val newScale = (scale * zoom).coerceIn(1f, MAX_SCALE)
                                    scale = newScale
                                    val maxX = size.width * (newScale - 1f) / 2f
                                    offsetX = if (newScale <= 1f) 0f else (offsetX + pan.x).coerceIn(-maxX, maxX)
                                    listState.dispatchRawDelta(-pan.y / newScale)
                                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                                }
                            }
                        } while (event.changes.any { it.pressed })
                    }
                }
        ) {
            val renderWidth = (constraints.maxWidth * 1.25f).toInt().coerceIn(600, 1400)
            val cache = remember(doc, renderWidth) {
                val maxBytes = (Runtime.getRuntime().maxMemory() / 4).toInt()
                object : LruCache<Int, Bitmap>(maxBytes) {
                    override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
                }
            }
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        translationX = offsetX
                    },
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                items(count = doc.pageCount, key = { it }) { index ->
                    PageItem(
                        index = index,
                        aspect = aspects.getOrElse(index) { 1.414f },
                        onAspect = { i, a ->
                            if (i in aspects.indices && kotlin.math.abs(aspects[i] - a) > 0.01f) aspects[i] = a
                        },
                        doc = doc,
                        cache = cache,
                        renderWidth = renderWidth,
                        night = night,
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = barsVisible,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn() + slideInVertically { -it },
            exit = fadeOut() + slideOutVertically { -it },
        ) {
            TopAppBar(
                title = { Text(state.name, maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                },
                actions = {
                    IconButton(onClick = onToggleFavorite) {
                        Icon(
                            if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = stringResource(R.string.favorite),
                        )
                    }
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = stringResource(R.string.more))
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        for ((task, label) in listOf(
                            AiTask.TRANSLATE to "ترجمه‌ی این صفحه",
                            AiTask.EXPLAIN to "توضیح این صفحه",
                            AiTask.SUMMARIZE to "خلاصه‌ی این صفحه",
                            AiTask.EXTRACT to "استخراج متن صفحه (OCR)",
                        )) {
                            DropdownMenuItem(
                                text = { Text(label) },
                                onClick = {
                                    onAiTask(task, (currentPage - 1).coerceIn(0, doc.pageCount - 1))
                                    menuOpen = false
                                },
                            )
                        }
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.night_mode)) },
                            trailingIcon = { if (night) Icon(Icons.Default.Check, contentDescription = null) },
                            onClick = { night = !night; menuOpen = false },
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.go_to_page)) },
                            onClick = { jumpOpen = true; menuOpen = false },
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.share)) },
                            onClick = { sharePdf(context, Uri.parse(state.uri)); menuOpen = false },
                        )
                    }
                },
            )
        }

        AnimatedVisibility(
            visible = barsVisible,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(),
            exit = fadeOut(),
        ) {
            Surface(
                shape = RoundedCornerShape(50),
                tonalElevation = 3.dp,
                shadowElevation = 3.dp,
                modifier = Modifier
                    .navigationBarsPadding()
                    .padding(16.dp)
                    .clickable { jumpOpen = true },
            ) {
                Text(
                    stringResource(R.string.page_of, currentPage.coerceAtMost(doc.pageCount), doc.pageCount),
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    style = MaterialTheme.typography.labelLarge,
                )
            }
        }
    }

    AiResultSheet(state = ai, onDismiss = onAiDismiss)

    if (jumpOpen) {
        var text by remember { mutableStateOf(currentPage.toString()) }
        AlertDialog(
            onDismissRequest = { jumpOpen = false },
            title = { Text(stringResource(R.string.go_to_page)) },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it.filter(Char::isDigit).take(6) },
                    label = { Text(stringResource(R.string.page_number)) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    text.toIntOrNull()?.let { n ->
                        scope.launch { listState.scrollToItem((n - 1).coerceIn(0, doc.pageCount - 1)) }
                    }
                    jumpOpen = false
                }) { Text(stringResource(R.string.ok)) }
            },
            dismissButton = {
                TextButton(onClick = { jumpOpen = false }) { Text(stringResource(R.string.cancel)) }
            },
        )
    }
}

@Composable
private fun PageItem(
    index: Int,
    aspect: Float,
    doc: PdfDocument,
    cache: LruCache<Int, Bitmap>,
    renderWidth: Int,
    night: Boolean,
    onAspect: (Int, Float) -> Unit,
) {
    val bitmap by produceState<Bitmap?>(initialValue = cache.get(index), index, cache) {
        if (value == null) {
            value = try {
                doc.render(index, renderWidth).also {
                    cache.put(index, it)
                    onAspect(index, it.height.toFloat() / it.width.toFloat())
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null // closed document or render failure: show the blank placeholder
            }
        }
    }
    val shape = Modifier
        .fillMaxWidth()
        .aspectRatioOf(aspect)
    val bmp = bitmap
    if (bmp == null) {
        Box(shape.background(if (night) Color.DarkGray else Color.White))
    } else {
        Image(
            bitmap = bmp.asImageBitmap(),
            contentDescription = null,
            modifier = shape,
            contentScale = ContentScale.FillWidth,
            colorFilter = if (night) ColorFilter.colorMatrix(InvertMatrix) else null,
        )
    }
}

private fun Modifier.aspectRatioOf(heightOverWidth: Float): Modifier =
    this.then(Modifier.aspectRatio(1f / heightOverWidth))

private fun sharePdf(context: Context, uri: Uri) {
    try {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(send, null))
    } catch (e: Exception) {
        Toast.makeText(context, R.string.err_share, Toast.LENGTH_SHORT).show()
    }
}
