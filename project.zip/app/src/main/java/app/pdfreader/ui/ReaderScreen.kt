package app.pdfreader.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.util.LruCache
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import app.pdfreader.R
import app.pdfreader.ReaderApp
import app.pdfreader.ai.AiTask
import app.pdfreader.core.pdf.PdfDocument
import app.pdfreader.data.Annot
import app.pdfreader.data.HIGHLIGHT_COLORS
import app.pdfreader.data.markerPoint
import app.pdfreader.tts.NRect
import app.pdfreader.tts.ReadMode
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID

private val InvertMatrix = ColorMatrix(
    floatArrayOf(
        -1f,  0f,  0f, 0f, 255f,
         0f, -1f,  0f, 0f, 255f,
         0f,  0f, -1f, 0f, 255f,
         0f,  0f,  0f, 1f,   0f,
    )
)

private const val MAX_SCALE = 4.0f
private const val DOUBLE_TAP_SCALE = 2.0f

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(
    state: ReaderState.Open,
    favorite: Boolean,
    onBack: () -> Unit,
    onToggleFavorite: () -> Unit,
    onProgress: (page: Int, offset: Int) -> Unit,
    ai: AiUi,
    bilingual: Boolean,
    onBilingual: (Boolean) -> Unit,
    onAiTask: (AiTask, Int, Boolean) -> Unit,
    onRangeSummary: (Int, Int, Boolean) -> Unit,
    onAiDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val ctrl = remember { (context.applicationContext as ReaderApp).container.readAloud }
    val read by ctrl.state.collectAsStateWithLifecycle()
    val chat: ChatViewModel = viewModel()
    var chatOpen by remember { mutableStateOf(false) }
    var rangeOpen by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val doc = state.doc
    val container = remember { (context.applicationContext as ReaderApp).container }
    val clipboard = LocalClipboardManager.current

    val annots = remember(state.uri) { mutableStateListOf<Annot>() }
    LaunchedEffect(state.uri) {
        val saved = container.annotations.load(state.uri)
        annots.clear()
        annots.addAll(saved)
    }

    val selection = remember(state.uri) {
        SelectionController(container.pdfiumText, state.uri, scope) { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
    }

    var selecting by remember { mutableStateOf(false) }
    var activeAnnot by remember { mutableStateOf<Annot?>(null) }
    var noteOpen by remember { mutableStateOf(false) }
    var listOpen by remember { mutableStateOf(false) }

    fun persistAnnots() {
        val snapshot = annots.toList()
        scope.launch { container.annotations.save(state.uri, snapshot) }
    }

    fun commitSelection(color: Int, note: String, kind: Int = 0) {
        val s = selection.sel ?: return
        val rects = selection.rects()
        if (rects.isEmpty()) return
        annots.add(Annot(UUID.randomUUID().toString(), s.page, color, rects, selection.text(), note.trim(), System.currentTimeMillis(), kind))
        persistAnnots()
        selection.clear()
    }

    val listState = rememberLazyListState(state.startPage, state.startOffset)
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }

    // Auto-hide toolbar state (Adobe Acrobat style)
    var barsVisible by remember { mutableStateOf(true) }
    var lastInteractionTime by remember { mutableLongStateOf(System.currentTimeMillis()) }

    fun registerInteraction() {
        lastInteractionTime = System.currentTimeMillis()
        barsVisible = true
    }

    // Auto-hide bottom toolbar and top bar after ~3s of no interaction
    LaunchedEffect(lastInteractionTime, barsVisible, read.active) {
        if (!read.active && barsVisible) {
            kotlinx.coroutines.delay(3_000L)
            barsVisible = false
        }
    }

    // Reappear on user scroll
    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemScrollOffset }
            .collect { registerInteraction() }
    }

    val readerSettings by container.settings.state.collectAsStateWithLifecycle()
    val night = readerSettings.nightMode
    var menuOpen by remember { mutableStateOf(false) }
    var jumpOpen by remember { mutableStateOf(false) }

    // Collapsible processing status indicator state
    var statusCardExpanded by remember { mutableStateOf(false) }
    val activeStatus = read.status ?: when (ai) {
        is AiUi.Loading -> ai.phase
        is AiUi.Streaming -> "در حال دریافت پاسخ هوش مصنوعی…"
        else -> null
    }

    // Auto-collapse status card when done
    LaunchedEffect(activeStatus) {
        if (activeStatus == null) {
            statusCardExpanded = false
        }
    }

    // Center page index
    val currentPage by remember {
        derivedStateOf {
            val info = listState.layoutInfo
            val center = (info.viewportStartOffset + info.viewportEndOffset) / 2
            val hit = info.visibleItemsInfo.minByOrNull {
                val end = it.offset + it.size
                if (center in it.offset until end) 0 else minOf(kotlin.math.abs(center - it.offset), kotlin.math.abs(center - end))
            }
            (hit?.index ?: listState.firstVisibleItemIndex) + 1
        }
    }

    // Notify ReadAloudController of page scrolling to prioritize prefetching
    LaunchedEffect(currentPage) {
        ctrl.onPageScrolled((currentPage - 1).coerceIn(0, doc.pageCount - 1))
    }

    DisposableEffect(ctrl) { onDispose { ctrl.stop() } }

    LaunchedEffect(read.page, read.active) {
        if (read.active) listState.animateScrollToItem(read.page)
    }

    LaunchedEffect(read.highlight) {
        val r = read.highlight.firstOrNull() ?: return@LaunchedEffect
        if (selecting) return@LaunchedEffect
        val item = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == read.page } ?: return@LaunchedEffect
        val vh = (listState.layoutInfo.viewportEndOffset - listState.layoutInfo.viewportStartOffset).toFloat()
        val y = item.offset + r.t * item.size
        if (y < vh * 0.12f || y > vh * 0.55f) listState.animateScrollBy(y - vh * 0.25f)
    }

    val aspects = remember(doc) { mutableStateListOf<Float>().apply { addAll(state.aspects) } }

    fun hitPage(p: Offset, w: Float, h: Float): Triple<Int, Float, Float>? {
        if (w <= 0f || h <= 0f) return null
        val ux = w / 2f + (p.x - w / 2f - offsetX) / scale
        val uy = h / 2f + (p.y - h / 2f) / scale
        val item = listState.layoutInfo.visibleItemsInfo.firstOrNull { uy >= it.offset && uy < it.offset + it.size } ?: return null
        if (item.size <= 0) return null
        return Triple(item.index, (ux / w).coerceIn(0f, 1f), ((uy - item.offset) / item.size).coerceIn(0f, 1f))
    }

    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex to listState.firstVisibleItemScrollOffset }
            .debounce(600)
            .collect { (p, o) -> onProgress(p, o) }
    }

    DisposableEffect(listState) {
        onDispose { onProgress(listState.firstVisibleItemIndex, listState.firstVisibleItemScrollOffset) }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(if (night) Color.Black else MaterialTheme.colorScheme.surfaceVariant)
    ) {
        BoxWithConstraints(
            Modifier
                .fillMaxSize()
                .clipToBounds()
                .pointerInput(state.uri) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                        val gw = size.width.toFloat()
                        val gh = size.height.toFloat()

                        val grabbed = if (selection.sel == null) 0 else
                            hitPage(down.position, gw, gh)?.let { selection.grab(it.first, it.second, it.third, aspects.getOrElse(it.first) { 1.414f }) } ?: 0

                        if (grabbed != 0) {
                            selecting = true
                            registerInteraction()
                            try {
                                down.consume()
                                while (true) {
                                    val ev = awaitPointerEvent(PointerEventPass.Initial)
                                    val c = ev.changes.firstOrNull { it.id == down.id }
                                    ev.changes.forEach { it.consume() }
                                    if (c == null || !c.pressed) break
                                    hitPage(c.position, gw, gh)?.let { selection.moveHandle(grabbed, it.first, it.second, it.third) }
                                    if (c.position.y < 90f) listState.dispatchRawDelta(-18f)
                                    else if (c.position.y > gh - 90f) listState.dispatchRawDelta(18f)
                                }
                            } finally {
                                selecting = false
                            }
                            return@awaitEachGesture
                        }

                        val slop = viewConfiguration.touchSlop
                        val aborted: Boolean? = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                            var stop = false
                            while (!stop) {
                                val ev = awaitPointerEvent(PointerEventPass.Initial)
                                val c = ev.changes.firstOrNull { it.id == down.id }
                                stop = c == null || !c.pressed || ev.changes.count { it.pressed } > 1 ||
                                    (c.position - down.position).getDistance() > slop
                            }
                            true
                        }

                        if (aborted == null) {
                            val w = size.width.toFloat()
                            val h = size.height.toFloat()
                            selecting = true
                            registerInteraction()
                            try {
                                selection.clear()
                                hitPage(down.position, w, h)?.let { selection.begin(it.first, it.second, it.third) }
                                while (true) {
                                    val ev = awaitPointerEvent(PointerEventPass.Initial)
                                    val c = ev.changes.firstOrNull { it.id == down.id }
                                    ev.changes.forEach { it.consume() }
                                    if (c == null || !c.pressed) break
                                    hitPage(c.position, w, h)?.let { selection.extend(it.first, it.second, it.third) }
                                    if (c.position.y < 90f) listState.dispatchRawDelta(-18f)
                                    else if (c.position.y > h - 90f) listState.dispatchRawDelta(18f)
                                }
                            } finally {
                                selecting = false
                            }
                        }
                    }
                }
                .pointerInput(state.uri) {
                    detectTapGestures(
                        onDoubleTap = {
                            registerInteraction()
                            if (scale > 1f) {
                                scale = 1f
                                offsetX = 0f
                            } else {
                                scale = DOUBLE_TAP_SCALE
                            }
                        },
                        onTap = { pos ->
                            registerInteraction()
                            if (selection.sel != null) {
                                selection.clear()
                            } else {
                                val hit = hitPage(pos, size.width.toFloat(), size.height.toFloat())
                                val tapped = hit?.let { (pg, nx, ny) ->
                                    annots.lastOrNull { a ->
                                        a.page == pg && (a.rects.any { r ->
                                            nx >= r.l - 0.01f && nx <= r.r + 0.01f && ny >= r.t - 0.01f && ny <= r.b + 0.01f
                                        } || (a.note.isNotBlank() && a.markerPoint()?.let { (mx, my) ->
                                            kotlin.math.abs(nx - mx) < 0.05f && kotlin.math.abs((ny - my) * aspects.getOrElse(pg) { 1.414f }) < 0.05f
                                        } == true))
                                    }
                                }
                                if (tapped != null) activeAnnot = tapped else barsVisible = !barsVisible
                            }
                        },
                    )
                }
                .pointerInput(Unit) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                        do {
                            val event = awaitPointerEvent(PointerEventPass.Initial)
                            val multi = event.changes.count { it.pressed } >= 2
                            if (!selecting && (multi || scale > 1f)) {
                                val zoom = event.calculateZoom()
                                val pan = event.calculatePan()
                                if (zoom != 1f || pan != Offset.Zero) {
                                    val newScale = (scale * zoom).coerceIn(1f, MAX_SCALE)
                                    scale = newScale
                                    val maxX = size.width * (newScale - 1f) / 2f
                                    offsetX = if (newScale <= 1f) 0f else (offsetX + pan.x).coerceIn(-maxX, maxX)
                                    listState.dispatchRawDelta(-pan.y / newScale)
                                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                                }
                            }
                        } while (event.changes.any { it.pressed })
                    }
                }
        ) {
            val renderWidth = (constraints.maxWidth * 1.25f).toInt().coerceIn(600, 1400)
            val cache = remember(doc, renderWidth) {
                val maxBytes = (Runtime.getRuntime().maxMemory() / 4).toInt()
                object : LruCache<Int, Bitmap>(maxBytes) {
                    override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
                }
            }

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        translationX = offsetX
                    },
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                items(count = doc.pageCount, key = { it }) { index ->
                    PageItem(
                        index = index,
                        aspect = aspects.getOrElse(index) { 1.414f },
                        onAspect = { i, a ->
                            if (i in aspects.indices && kotlin.math.abs(aspects[i] - a) > 0.01f) aspects[i] = a
                        },
                        doc = doc,
                        cache = cache,
                        renderWidth = renderWidth,
                        night = night,
                        highlight = if (read.active && read.page == index) read.highlight else emptyList(),
                        annots = annots.filter { it.page == index },
                        selection = if (selection.sel?.page == index) selection.rects() else emptyList(),
                        handles = if (selection.sel?.page == index) selection.handles() else null,
                        wordHighlight = emptyList(),
                    )
                }
            }

            // Anchored text selection popup: positioned directly above selected text rect with a small gap
            selection.sel?.let { sel ->
                val selRects = selection.rects()
                if (selRects.isNotEmpty()) {
                    val density = LocalDensity.current
                    val visibleItem = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == sel.page }
                    if (visibleItem != null && constraints.maxWidth > 0 && constraints.maxHeight > 0) {
                        val wPx = constraints.maxWidth.toFloat()
                        val hPx = constraints.maxHeight.toFloat()
                        val topRect = selRects.minByOrNull { it.t } ?: selRects.first()
                        val bottomRect = selRects.maxByOrNull { it.b } ?: selRects.last()

                        val unscaledTopY = visibleItem.offset + topRect.t * visibleItem.size
                        val unscaledBottomY = visibleItem.offset + bottomRect.b * visibleItem.size
                        val screenTopY = (unscaledTopY - hPx / 2f) * scale + hPx / 2f
                        val screenBottomY = (unscaledBottomY - hPx / 2f) * scale + hPx / 2f

                        val toolbarHeightPx = with(density) { 54.dp.toPx() }
                        val gapPx = with(density) { 10.dp.toPx() }
                        val topSafeBoundPx = with(density) { 72.dp.toPx() }
                        val bottomSafeBoundPx = hPx - with(density) { 88.dp.toPx() }

                        // Place above if space permits, otherwise place directly below selection
                        val placeAbove = (screenTopY - toolbarHeightPx - gapPx) >= topSafeBoundPx
                        val targetYPx = if (placeAbove) {
                            screenTopY - toolbarHeightPx - gapPx
                        } else {
                            (screenBottomY + gapPx).coerceAtMost(bottomSafeBoundPx)
                        }

                        val targetYDp = with(density) { targetYPx.toDp() }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .offset(y = targetYDp),
                            contentAlignment = Alignment.TopCenter,
                        ) {
                            AnchoredSelectionToolbar(
                                onHighlight = { color -> commitSelection(color, "") },
                                onUnderline = { commitSelection(0xFFE53935.toInt(), "", 1) },
                                onStrikethrough = { commitSelection(0xFFE53935.toInt(), "", 2) },
                                onCopy = {
                                    clipboard.setText(AnnotatedString(selection.text()))
                                    Toast.makeText(context, "کپی شد", Toast.LENGTH_SHORT).show()
                                    selection.clear()
                                },
                                onAddNote = { noteOpen = true },
                                onTranslateSelection = {
                                    onAiTask(AiTask.TRANSLATE, sel.page, false)
                                    selection.clear()
                                },
                                onExplainSelection = {
                                    onAiTask(AiTask.EXPLAIN, sel.page, false)
                                    selection.clear()
                                },
                            )
                        }
                    }
                }
            }
        }

        // Top App Bar with secondary overflow menu actions
        AnimatedVisibility(
            visible = barsVisible,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn() + slideInVertically { -it },
            exit = fadeOut() + slideOutVertically { -it },
        ) {
            TopAppBar(
                title = { Text(state.name, maxLines = 1, style = MaterialTheme.typography.titleMedium) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                },
                actions = {
                    IconButton(onClick = onToggleFavorite) {
                        Icon(
                            if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = stringResource(R.string.favorite),
                            tint = if (favorite) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurface,
                        )
                    }
                    IconButton(onClick = { menuOpen = true; registerInteraction() }) {
                        Icon(Icons.Default.MoreVert, contentDescription = stringResource(R.string.more))
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("هایلایت‌ها و یادداشت‌ها (${annots.size})") },
                            onClick = { listOpen = true; menuOpen = false },
                        )
                        DropdownMenuItem(
                            text = { Text("حالت شب (برای همه‌ی PDFها)") },
                            leadingIcon = { Checkbox(checked = night, onCheckedChange = null) },
                            onClick = { container.settings.update { it.copy(nightMode = !it.nightMode) } },
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.go_to_page)) },
                            onClick = { jumpOpen = true; menuOpen = false },
                        )
                        DropdownMenuItem(
                            text = { Text("استخراج متن صفحه (OCR)") },
                            onClick = {
                                onAiTask(AiTask.EXTRACT, (currentPage - 1).coerceIn(0, doc.pageCount - 1), false)
                                menuOpen = false
                            },
                        )
                        DropdownMenuItem(
                            text = { Text("خلاصه‌ی بازه‌ی صفحه‌ها") },
                            onClick = { rangeOpen = true; menuOpen = false },
                        )
                        DropdownMenuItem(
                            text = { Text("ترجمه و خواندن با صدا (فقط صوت)") },
                            onClick = {
                                ctrl.start(doc, state.uri, (currentPage - 1).coerceIn(0, doc.pageCount - 1), ReadMode.TRANSLATE_AUDIO)
                                menuOpen = false
                            },
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.share)) },
                            onClick = { sharePdf(context, Uri.parse(state.uri)); menuOpen = false },
                        )
                    }
                },
            )
        }

        // Collapsible Processing Status Indicator near bottom bar (Req #5)
        if (activeStatus != null && !read.active) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = if (barsVisible) 88.dp else 24.dp)
                    .padding(horizontal = 20.dp)
            ) {
                CollapsibleStatusIndicator(
                    status = activeStatus,
                    expanded = statusCardExpanded,
                    onToggleExpand = { statusCardExpanded = !statusCardExpanded }
                )
            }
        }

        // Floating Bottom Toolbar with Auto-Hide (Adobe Acrobat style) (Req #1)
        if (!read.active) {
            FloatingReaderBottomBar(
                visible = barsVisible,
                onReadAloud = {
                    registerInteraction()
                    ctrl.start(doc, state.uri, (currentPage - 1).coerceIn(0, doc.pageCount - 1), ReadMode.ORIGINAL)
                },
                onTranslate = {
                    registerInteraction()
                    onAiTask(AiTask.TRANSLATE, (currentPage - 1).coerceIn(0, doc.pageCount - 1), false)
                },
                onSummarize = {
                    registerInteraction()
                    onAiTask(AiTask.SUMMARIZE, (currentPage - 1).coerceIn(0, doc.pageCount - 1), false)
                },
                onChat = {
                    registerInteraction()
                    chatOpen = true
                },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 16.dp),
            )
        } else {
            ReadAloudPanel(read, ctrl, Modifier.align(Alignment.BottomCenter))
        }
    }

    AiResultSheet(
        state = ai,
        bilingual = bilingual,
        onBilingualChange = onBilingual,
        onDismiss = onAiDismiss,
        onRetry = { d ->
            if (d.rangeTo >= 0) onRangeSummary(d.page, d.rangeTo, true) else onAiTask(d.task, d.page, true)
        },
    )

    if (chatOpen) {
        ChatSheet(
            chat = chat,
            currentPage = currentPage.coerceAtMost(doc.pageCount),
            onSend = { q -> chat.send(doc, state.uri, (currentPage - 1).coerceIn(0, doc.pageCount - 1), q) },
            onDismiss = { chatOpen = false },
        )
    }

    if (rangeOpen) {
        RangeDialog(
            current = currentPage.coerceAtMost(doc.pageCount),
            total = doc.pageCount,
            onDismiss = { rangeOpen = false },
            onStart = { f, t ->
                rangeOpen = false
                onRangeSummary(f, t, false)
            },
        )
    }

    if (jumpOpen) {
        var pageInput by remember { mutableStateOf(currentPage.toString()) }
        AlertDialog(
            onDismissRequest = { jumpOpen = false },
            title = { Text(stringResource(R.string.go_to_page)) },
            text = {
                OutlinedTextField(
                    value = pageInput,
                    onValueChange = { pageInput = it.filter(Char::isDigit).take(6) },
                    label = { Text("شماره‌ی صفحه (۱ تا ${doc.pageCount})") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val p = pageInput.toIntOrNull()
                    if (p != null && p in 1..doc.pageCount) {
                        scope.launch { listState.scrollToItem(p - 1) }
                        jumpOpen = false
                    }
                }) { Text("برو") }
            },
            dismissButton = { TextButton(onClick = { jumpOpen = false }) { Text("انصراف") } },
        )
    }

    if (listOpen) {
        ModalBottomSheet(
            onDismissRequest = { listOpen = false },
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        ) {
            if (annots.isEmpty()) {
                Text(
                    "هنوز هایلایت یا یادداشتی ندارید. روی متن نگه دارید تا انتخاب شود.",
                    modifier = Modifier.padding(24.dp),
                    style = MaterialTheme.typography.bodyMedium,
                )
            } else {
                LazyColumn(Modifier.padding(bottom = 24.dp)) {
                    items(annots.sortedWith(compareBy({ it.page }, { it.created })), key = { it.id }) { a ->
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    listOpen = false
                                    scope.launch { listState.animateScrollToItem(a.page) }
                                }
                                .padding(horizontal = 20.dp, vertical = 10.dp)
                        ) {
                            Text("صفحه ${a.page + 1}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            Text(a.text, maxLines = 2, style = MaterialTheme.typography.bodyMedium)
                            if (a.note.isNotBlank()) Text(a.note, maxLines = 3, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row {
                                TextButton(onClick = { activeAnnot = a; listOpen = false }) { Text("ویرایش") }
                                TextButton(onClick = {
                                    annots.removeAll { it.id == a.id }
                                    persistAnnots()
                                }) { Text("حذف") }
                            }
                        }
                    }
                }
            }
        }
    }

    if (noteOpen) {
        var note by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { noteOpen = false },
            title = { Text("افزودن یادداشت") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(selection.text(), maxLines = 4, style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(
                        value = note, onValueChange = { note = it }, label = { Text("یادداشت") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    commitSelection(0xFFFFB300.toInt(), note, 3)
                    noteOpen = false
                }) { Text("ذخیره") }
            },
            dismissButton = { TextButton(onClick = { noteOpen = false }) { Text("انصراف") } },
        )
    }

    activeAnnot?.let { a ->
        var note by remember(a.id) { mutableStateOf(a.note) }
        AlertDialog(
            onDismissRequest = { activeAnnot = null },
            title = { Text(if (a.note.isBlank()) "هایلایت" else "یادداشت") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(a.text, maxLines = 6, style = MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(
                        value = note, onValueChange = { note = it }, label = { Text("یادداشت") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val idx = annots.indexOfFirst { it.id == a.id }
                    if (idx >= 0) annots[idx] = a.copy(note = note.trim())
                    persistAnnots()
                    activeAnnot = null
                }) { Text("ذخیره") }
            },
            dismissButton = { TextButton(onClick = { activeAnnot = null }) { Text("انصراف") } },
        )
    }
}

/**
 * Modern Adobe Acrobat-style Floating Bottom Toolbar with Material 3 styling.
 */
@Composable
private fun FloatingReaderBottomBar(
    visible: Boolean,
    onReadAloud: () -> Unit,
    onTranslate: () -> Unit,
    onSummarize: () -> Unit,
    onChat: () -> Unit,
    modifier: Modifier = Modifier,
) {
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn() + slideInVertically { it / 2 },
        exit = fadeOut() + slideOutVertically { it / 2 },
        modifier = modifier,
    ) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.96f),
            tonalElevation = 6.dp,
            shadowElevation = 10.dp,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
            modifier = Modifier.padding(horizontal = 16.dp),
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                FloatingBarItem(
                    title = "خواندن",
                    icon = { SpeakerIcon(tint = MaterialTheme.colorScheme.onSurface) },
                    onClick = onReadAloud,
                )
                FloatingBarItem(
                    title = "ترجمه",
                    icon = { TranslateIcon(tint = MaterialTheme.colorScheme.onSurface) },
                    onClick = onTranslate,
                )
                FloatingBarItem(
                    title = "خلاصه",
                    icon = { SummaryIcon(tint = MaterialTheme.colorScheme.onSurface) },
                    onClick = onSummarize,
                )
                FloatingBarItem(
                    title = "دستیار AI",
                    icon = { SparkleIcon(tint = MaterialTheme.colorScheme.primary) },
                    isSpecial = true,
                    onClick = onChat,
                )
            }
        }
    }
}

@Composable
private fun FloatingBarItem(
    title: String,
    icon: @Composable () -> Unit,
    onClick: () -> Unit,
    isSpecial: Boolean = false,
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = if (isSpecial) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
        modifier = Modifier.height(44.dp),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            icon()
            Text(
                title,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = if (isSpecial) FontWeight.Bold else FontWeight.Medium,
                color = if (isSpecial) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
            )
        }
    }
}

/**
 * Collapsible processing status indicator near the bottom bar (Req #5).
 * Replaces intrusive status text with a tiny animated pulsing dot/icon.
 * Tapping it expands a small card with current step; auto-collapses when done.
 */
@Composable
private fun CollapsibleStatusIndicator(
    status: String,
    expanded: Boolean,
    onToggleExpand: () -> Unit,
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "alpha",
    )

    Surface(
        onClick = onToggleExpand,
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHighest,
        tonalElevation = 6.dp,
        shadowElevation = 8.dp,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
        modifier = Modifier.animateContentSize(),
    ) {
        if (!expanded) {
            // Compact micro badge: pulsing dot + icon
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = pulseAlpha))
                )
                Text(
                    "در حال پردازش…",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
        } else {
            // Expanded small card showing current processing step
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = pulseAlpha))
                    )
                    Text(
                        "وضعیت پردازش",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                Text(
                    status,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface,
                )
            }
        }
    }
}

/**
 * Text selection action toolbar: anchored directly above the selected text's Rect (Req #6).
 */
@Composable
private fun AnchoredSelectionToolbar(
    onHighlight: (Int) -> Unit,
    onUnderline: () -> Unit,
    onStrikethrough: () -> Unit,
    onCopy: () -> Unit,
    onAddNote: () -> Unit,
    onTranslateSelection: () -> Unit,
    onExplainSelection: () -> Unit,
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHighest,
            tonalElevation = 6.dp,
            shadowElevation = 8.dp,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
        ) {
            Row(
                Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                for (col in HIGHLIGHT_COLORS) {
                    Box(
                        Modifier
                            .padding(horizontal = 3.dp)
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(Color(col))
                            .clickable { onHighlight(col) }
                    )
                }
                val labelStyle = MaterialTheme.typography.labelMedium
                TextButton(onClick = onUnderline) { Text("خط‌زیر", style = labelStyle) }
                TextButton(onClick = onStrikethrough) { Text("خط‌خورده", style = labelStyle) }
                TextButton(onClick = onCopy) { Text("کپی", style = labelStyle) }
                TextButton(onClick = onAddNote) { Text("یادداشت", style = labelStyle) }
                TextButton(onClick = onTranslateSelection) { Text("ترجمه", style = labelStyle) }
                TextButton(onClick = onExplainSelection) { Text("توضیح", style = labelStyle) }
            }
        }
    }
}

/**
 * Page item rendering: shows PDF bitmap and draws sentence-level rounded highlight (Req #4).
 */
@Composable
private fun PageItem(
    index: Int,
    aspect: Float,
    onAspect: (Int, Float) -> Unit,
    doc: PdfDocument,
    cache: LruCache<Int, Bitmap>,
    renderWidth: Int,
    night: Boolean,
    highlight: List<NRect>,
    annots: List<Annot>,
    selection: List<NRect>,
    handles: Pair<NPoint, NPoint>?,
    wordHighlight: List<NRect>,
) {
    val bitmap by produceState<Bitmap?>(initialValue = cache.get(index), index, cache) {
        if (value == null) {
            value = try {
                doc.render(index, renderWidth).also {
                    cache.put(index, it)
                    onAspect(index, it.height.toFloat() / it.width.toFloat())
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
        }
    }

    val shape = Modifier
        .fillMaxWidth()
        .aspectRatioOf(aspect)

    val bmp = bitmap
    Box(shape) {
        if (bmp == null) {
            Box(Modifier.fillMaxSize().background(if (night) Color.DarkGray else Color.White))
        } else {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillWidth,
                colorFilter = if (night) ColorFilter.colorMatrix(InvertMatrix) else null,
            )
        }

        if (highlight.isNotEmpty() || annots.isNotEmpty() || selection.isNotEmpty() || wordHighlight.isNotEmpty() || handles != null) {
            Canvas(Modifier.fillMaxSize()) {
                // Annotations
                for (a in annots) {
                    val col = Color(a.color)
                    for (r in a.rects) {
                        when (a.kind) {
                            1, 2, 3 -> {
                                val y = if (a.kind == 2) (r.t + r.b) / 2f else r.b
                                drawLine(
                                    color = col.copy(alpha = 1f),
                                    start = Offset(r.l * size.width, y * size.height),
                                    end = Offset(r.r * size.width, y * size.height),
                                    strokeWidth = 1.dp.toPx(),
                                )
                            }
                            else -> drawRoundRect(
                                color = col,
                                topLeft = Offset(r.l * size.width, r.t * size.height),
                                size = Size((r.r - r.l) * size.width, (r.b - r.t) * size.height),
                                cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx()),
                            )
                        }
                    }
                    if (a.note.isNotBlank()) {
                        a.markerPoint()?.let { (mx, my) ->
                            val cx = mx * size.width
                            val cy = my * size.height
                            val sz = 9.dp.toPx()
                            drawRoundRect(Color(0xFFFFB300), Offset(cx - sz, cy - sz), Size(2 * sz, 2 * sz), CornerRadius(5.dp.toPx(), 5.dp.toPx()))
                            drawLine(Color.White, Offset(cx - sz * 0.5f, cy - sz * 0.25f), Offset(cx + sz * 0.5f, cy - sz * 0.25f), strokeWidth = 1.5f.dp.toPx())
                            drawLine(Color.White, Offset(cx - sz * 0.5f, cy + sz * 0.3f), Offset(cx + sz * 0.25f, cy + sz * 0.3f), strokeWidth = 1.5f.dp.toPx())
                        }
                    }
                }

                // Selection rects
                for (r in selection) {
                    drawRoundRect(
                        color = Color(0x663D5AFE),
                        topLeft = Offset(r.l * size.width, r.t * size.height),
                        size = Size((r.r - r.l) * size.width, (r.b - r.t) * size.height),
                        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx()),
                    )
                }

                // Sentence-level highlight during TTS: semi-transparent rounded background (Req #4)
                for (r in highlight) {
                    val padY = (r.b - r.t) * 0.15f * size.height
                    val padX = 2.dp.toPx()
                    drawRoundRect(
                        color = Color(0x403F51B5), // Soft semi-transparent indigo marker
                        topLeft = Offset(r.l * size.width - padX, r.t * size.height - padY),
                        size = Size((r.r - r.l) * size.width + 2 * padX, (r.b - r.t) * size.height + 2 * padY),
                        cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx()),
                    )
                }

                // Word highlight
                for (r in wordHighlight) {
                    drawRoundRect(
                        color = Color(0x80FF9800),
                        topLeft = Offset(r.l * size.width, r.t * size.height),
                        size = Size((r.r - r.l) * size.width, (r.b - r.t) * size.height),
                        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx()),
                    )
                }

                // Drag handles
                handles?.let { (p1, p2) ->
                    for (p in listOf(p1, p2)) {
                        val x = p.x * size.width
                        val y = p.y * size.height
                        drawLine(Color(0xFF3D5AFE), Offset(x, y), Offset(x, y + 5.dp.toPx()), strokeWidth = 2.dp.toPx())
                        drawCircle(Color(0xFF3D5AFE), radius = 6.dp.toPx(), center = Offset(x, y + 10.dp.toPx()))
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Cohesive Custom Modern Icons

@Composable
private fun SpeakerIcon(tint: Color) {
    Canvas(Modifier.size(20.dp)) {
        val w = size.width
        val h = size.height
        // Speaker body
        val path = Path().apply {
            moveTo(w * 0.15f, h * 0.35f)
            lineTo(w * 0.35f, h * 0.35f)
            lineTo(w * 0.6f, h * 0.15f)
            lineTo(w * 0.6f, h * 0.85f)
            lineTo(w * 0.35f, h * 0.65f)
            lineTo(w * 0.15f, h * 0.65f)
            close()
        }
        drawPath(path, color = tint)
        // Sound waves
        drawArc(
            color = tint,
            startAngle = -45f,
            sweepAngle = 90f,
            useCenter = false,
            topLeft = Offset(w * 0.45f, h * 0.25f),
            size = Size(w * 0.4f, h * 0.5f),
            style = Stroke(width = 1.8.dp.toPx()),
        )
    }
}

@Composable
private fun TranslateIcon(tint: Color) {
    Canvas(Modifier.size(20.dp)) {
        val w = size.width
        val h = size.height
        // Globe circle
        drawCircle(
            color = tint,
            radius = w * 0.42f,
            center = Offset(w * 0.5f, h * 0.5f),
            style = Stroke(width = 1.8.dp.toPx()),
        )
        // Latitude horizontal line
        drawLine(
            color = tint,
            start = Offset(w * 0.1f, h * 0.5f),
            end = Offset(w * 0.9f, h * 0.5f),
            strokeWidth = 1.5.dp.toPx(),
        )
        // Longitude curved ellipse
        drawOval(
            color = tint,
            topLeft = Offset(w * 0.3f, h * 0.08f),
            size = Size(w * 0.4f, h * 0.84f),
            style = Stroke(width = 1.5.dp.toPx()),
        )
    }
}

@Composable
private fun SummaryIcon(tint: Color) {
    Canvas(Modifier.size(20.dp)) {
        val w = size.width
        val h = size.height
        // Document page with bullet text lines
        drawLine(color = tint, start = Offset(w * 0.2f, h * 0.25f), end = Offset(w * 0.8f, h * 0.25f), strokeWidth = 2.dp.toPx())
        drawLine(color = tint, start = Offset(w * 0.2f, h * 0.5f), end = Offset(w * 0.7f, h * 0.5f), strokeWidth = 2.dp.toPx())
        drawLine(color = tint, start = Offset(w * 0.2f, h * 0.75f), end = Offset(w * 0.55f, h * 0.75f), strokeWidth = 2.dp.toPx())
    }
}

@Composable
private fun SparkleIcon(tint: Color) {
    Canvas(Modifier.size(20.dp)) {
        val w = size.width
        val h = size.height
        // 4-pointed sparkle
        val p = Path().apply {
            moveTo(w * 0.5f, h * 0.1f)
            quadraticTo(w * 0.5f, h * 0.5f, w * 0.9f, h * 0.5f)
            quadraticTo(w * 0.5f, h * 0.5f, w * 0.5f, h * 0.9f)
            quadraticTo(w * 0.5f, h * 0.5f, w * 0.1f, h * 0.5f)
            quadraticTo(w * 0.5f, h * 0.5f, w * 0.5f, h * 0.1f)
            close()
        }
        drawPath(p, color = tint)
    }
}

private fun Modifier.aspectRatioOf(heightOverWidth: Float): Modifier =
    this.then(Modifier.aspectRatio(1f / heightOverWidth))

private fun sharePdf(context: Context, uri: Uri) {
    try {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(send, null))
    } catch (e: Exception) {
        Toast.makeText(context, R.string.err_share, Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun RangeDialog(current: Int, total: Int, onDismiss: () -> Unit, onStart: (Int, Int) -> Unit) {
    var from by remember { mutableStateOf(current.toString()) }
    var to by remember { mutableStateOf(minOf(total, current + 9).toString()) }
    val f = from.toIntOrNull()
    val t = to.toIntOrNull()
    val valid = f != null && t != null && f in 1..total && t in 1..total
    val n = if (valid) kotlin.math.abs(t!! - f!!) + 1 else 0
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("خلاصه‌ی بازه‌ی صفحه‌ها") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = from, onValueChange = { from = it.filter(Char::isDigit).take(6) },
                        label = { Text("از صفحه") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        value = to, onValueChange = { to = it.filter(Char::isDigit).take(6) },
                        label = { Text("تا صفحه") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                    )
                }
                Text(
                    if (valid) "برای خواندن این $n صفحه تا $n درخواست به هوش مصنوعی فرستاده می‌شود و سپس خلاصه تهیه می‌شود."
                    else "شماره‌ی صفحه‌ها را درست وارد کنید (۱ تا $total).",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { if (valid) onStart(f!! - 1, t!! - 1) }, enabled = valid) { Text("شروع") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}
