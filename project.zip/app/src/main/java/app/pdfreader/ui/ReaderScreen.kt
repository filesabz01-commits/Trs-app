package app.pdfreader.ui

import androidx.compose.ui.text.style.TextOverflow

import app.pdfreader.tts.NRect
import app.pdfreader.data.Annot
import app.pdfreader.data.HIGHLIGHT_COLORS
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import java.util.UUID
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.shape.RoundedCornerShape as RoundShape
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Checkbox
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import app.pdfreader.data.markerPoint
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.foundation.Canvas
import app.pdfreader.tts.ReadMode
import app.pdfreader.ReaderApp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.material3.FloatingActionButton
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.util.LruCache
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import app.pdfreader.R
import app.pdfreader.ai.AiTask
import app.pdfreader.core.pdf.PdfDocument
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val MAX_SCALE = 5f
private const val DOUBLE_TAP_SCALE = 2.5f

private val InvertMatrix = ColorMatrix(
    floatArrayOf(
        -1f, 0f, 0f, 0f, 255f,
        0f, -1f, 0f, 0f, 255f,
        0f, 0f, -1f, 0f, 255f,
        0f, 0f, 0f, 1f, 0f,
    )
)

@OptIn(FlowPreview::class, ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(
    state: ReaderState.Open,
    favorite: Boolean,
    onBack: () -> Unit,
    onToggleFavorite: () -> Unit,
    onProgress: (page: Int, offset: Int) -> Unit,
    ai: AiUi,
    bilingual: Boolean,
    onBilingual: (Boolean) -> Unit,
    onAiTask: (AiTask, Int, Boolean) -> Unit,
    onRangeSummary: (Int, Int, Boolean) -> Unit,
    onAiDismiss: () -> Unit,
    onOpenSettings: () -> Unit,
    onAiCancel: () -> Unit = {},
    onAiNextModel: () -> Unit = {},
) {
    val context = LocalContext.current
    val ctrl = remember { (context.applicationContext as ReaderApp).container.readAloud }
    val read by ctrl.state.collectAsStateWithLifecycle()
    val chat: ChatViewModel = viewModel()
    var chatOpen by remember { mutableStateOf(false) }
    var rangeOpen by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val doc = state.doc
    val container = remember { (context.applicationContext as ReaderApp).container }
    val clipboard = LocalClipboardManager.current

    // highlights and notes of this document (kept in a small file next to the app data)
    val annots = remember(state.uri) { mutableStateListOf<Annot>() }
    LaunchedEffect(state.uri) {
        val saved = container.annotations.load(state.uri)
        annots.clear()
        annots.addAll(saved)
    }
    val selection = remember(state.uri) {
        SelectionController(container.pdfiumText, state.uri, scope) { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
    }
    var selecting by remember { mutableStateOf(false) }
    var activeAnnot by remember { mutableStateOf<Annot?>(null) }
    var noteOpen by remember { mutableStateOf(false) }
    var listOpen by remember { mutableStateOf(false) }
    fun persistAnnots() {
        val snapshot = annots.toList()
        scope.launch { container.annotations.save(state.uri, snapshot) }
    }
    fun commitSelection(color: Int, note: String, kind: Int = 0) {
        val s = selection.sel ?: return
        val rects = selection.rects()
        if (rects.isEmpty()) return
        annots.add(Annot(UUID.randomUUID().toString(), s.page, color, rects, selection.text(), note.trim(), System.currentTimeMillis(), kind))
        persistAnnots()
        selection.clear()
    }
    val listState = rememberLazyListState(state.startPage, state.startOffset)

    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var barsVisible by remember { mutableStateOf(true) }
    val readerSettings = container.settings.state.collectAsState().value
    val night = readerSettings.nightMode
    var moreOpen by remember { mutableStateOf(false) }
    val rtlRoot = androidx.compose.ui.platform.LocalLayoutDirection.current == LayoutDirection.Rtl
    val padPx = with(LocalDensity.current) { PAGE_SIDE_PAD.toPx() }
    var menuOpen by remember { mutableStateOf(false) }
    var jumpOpen by remember { mutableStateOf(false) }
    // The page under the CENTER of the screen (not the first partly-visible one).
    val currentPage by remember {
        derivedStateOf {
            val info = listState.layoutInfo
            val center = (info.viewportStartOffset + info.viewportEndOffset) / 2
            val hit = info.visibleItemsInfo.minByOrNull {
                val end = it.offset + it.size
                if (center in it.offset until end) 0 else minOf(kotlin.math.abs(center - it.offset), kotlin.math.abs(center - end))
            }
            (hit?.index ?: listState.firstVisibleItemIndex) + 1
        }
    }
    // While reading aloud, the PDF follows the page that is being read.
    // the bars hide themselves a few seconds after they appeared (not while a menu or sheet is open)
    LaunchedEffect(barsVisible, menuOpen, moreOpen, read.active) {
        if (barsVisible && !menuOpen && !moreOpen && !read.active) {
            delay(6_000)
            barsVisible = false
        }
    }
    // leaving the reader ends read-aloud completely (player, audio requests, preparation of the next pages)
    DisposableEffect(ctrl) { onDispose { ctrl.stop() } }
    LaunchedEffect(read.page, read.active) {
        if (read.active && read.page in 0 until (doc?.pageCount ?: 0)) {
            try { listState.animateScrollToItem(read.page) } catch (ignored: Throwable) {}
        }
    }
    // While reading aloud, keep the spoken line on screen (not under the player, not off the edge).
    LaunchedEffect(read.highlight) {
        try {
            val r = read.highlight.firstOrNull() ?: return@LaunchedEffect
            if (selecting) return@LaunchedEffect
            val item = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == read.page } ?: return@LaunchedEffect
            val vh = (listState.layoutInfo.viewportEndOffset - listState.layoutInfo.viewportStartOffset).toFloat()
            if (vh > 0f) {
                val y = item.offset + r.t * item.size
                if (y < vh * 0.12f || y > vh * 0.55f) listState.animateScrollBy(y - vh * 0.25f)
            }
        } catch (ignored: Throwable) {}
    }
    // Page proportions start uniform (fast open) and are corrected as each page is rendered.
    val aspects = remember(doc) { mutableStateListOf<Float>().apply { addAll(state.aspects) } }

    // Screen point -> (page index, x fraction, y fraction), undoing the zoom/pan transform of the page list.
    fun hitPage(p: Offset, w: Float, h: Float): Triple<Int, Float, Float>? {
        if (w <= 0f || h <= 0f) return null
        val ux = w / 2f + (p.x - w / 2f - offsetX) / scale
        val uy = h / 2f + (p.y - h / 2f) / scale
        val item = listState.layoutInfo.visibleItemsInfo.firstOrNull { uy >= it.offset && uy < it.offset + it.size } ?: return null
        if (item.size <= 0) return null
        return Triple(item.index, ((ux - padPx) / (w - 2 * padPx)).coerceIn(0f, 1f), ((uy - item.offset) / item.size).coerceIn(0f, 1f))
    }

    // Resume reading: remember the exact spot (page + pixel offset), debounced.
    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex to listState.firstVisibleItemScrollOffset }
            .debounce(600)
            .collect { (p, o) -> onProgress(p, o) }
    }
    DisposableEffect(listState) {
        onDispose { onProgress(listState.firstVisibleItemIndex, listState.firstVisibleItemScrollOffset) }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(if (night) Color.Black else MaterialTheme.colorScheme.surfaceVariant)
    ) {
        BoxWithConstraints(
            Modifier
                .fillMaxSize()
                .clipToBounds()
                .pointerInput(state.uri) {
                    // Long-press selection. It watches in the Initial pass (before the list and the zoom handler);
                    // once the long press is confirmed it consumes the rest of the gesture so the page does not scroll.
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                        val gw = size.width.toFloat()
                        val gh = size.height.toFloat()
                        // 1) a drag on one of the two selection handles starts at once (no long press needed)
                        val grabbed = if (selection.sel == null) 0 else
                            hitPage(down.position, gw, gh)?.let { selection.grab(it.first, it.second, it.third, aspects.getOrElse(it.first) { 1.414f }) } ?: 0
                        if (grabbed != 0) {
                            selecting = true
                            try {
                                down.consume()
                                while (true) {
                                    val ev = awaitPointerEvent(PointerEventPass.Initial)
                                    val c = ev.changes.firstOrNull { it.id == down.id }
                                    ev.changes.forEach { it.consume() }
                                    if (c == null || !c.pressed) break
                                    hitPage(c.position, gw, gh)?.let { selection.moveHandle(grabbed, it.first, it.second, it.third) }
                                    if (c.position.y < 90f) listState.dispatchRawDelta(-18f)
                                    else if (c.position.y > gh - 90f) listState.dispatchRawDelta(18f)
                                }
                            } finally {
                                selecting = false
                            }
                            return@awaitEachGesture
                        }
                        val slop = viewConfiguration.touchSlop
                        val aborted: Boolean? = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                            var stop = false
                            while (!stop) {
                                val ev = awaitPointerEvent(PointerEventPass.Initial)
                                val c = ev.changes.firstOrNull { it.id == down.id }
                                stop = c == null || !c.pressed || ev.changes.count { it.pressed } > 1 ||
                                    (c.position - down.position).getDistance() > slop
                            }
                            true
                        }
                        if (aborted == null) {
                            val w = size.width.toFloat()
                            val h = size.height.toFloat()
                            selecting = true
                            try {
                                selection.clear()
                                hitPage(down.position, w, h)?.let { selection.begin(it.first, it.second, it.third) }
                                while (true) {
                                    val ev = awaitPointerEvent(PointerEventPass.Initial)
                                    val c = ev.changes.firstOrNull { it.id == down.id }
                                    ev.changes.forEach { it.consume() }
                                    if (c == null || !c.pressed) break
                                    hitPage(c.position, w, h)?.let { selection.extend(it.first, it.second, it.third) }
                                    if (c.position.y < 90f) listState.dispatchRawDelta(-18f)
                                    else if (c.position.y > h - 90f) listState.dispatchRawDelta(18f)
                                }
                            } finally {
                                selecting = false
                            }
                        }
                    }
                }
                .pointerInput(state.uri) {
                    detectTapGestures(
                        onDoubleTap = {
                            if (scale > 1f) {
                                scale = 1f
                                offsetX = 0f
                            } else {
                                scale = DOUBLE_TAP_SCALE
                            }
                        },
                        onTap = { pos ->
                            if (selection.sel != null) {
                                selection.clear()
                            } else {
                                val hit = hitPage(pos, size.width.toFloat(), size.height.toFloat())
                                val tapped = hit?.let { (pg, nx, ny) ->
                                    annots.lastOrNull { a ->
                                        a.page == pg && (a.rects.any { r ->
                                            nx >= r.l - 0.01f && nx <= r.r + 0.01f && ny >= r.t - 0.01f && ny <= r.b + 0.01f
                                        } || (a.note.isNotBlank() && a.markerPoint()?.let { (mx, my) ->
                                            kotlin.math.abs(nx - mx) < 0.05f && kotlin.math.abs((ny - my) * aspects.getOrElse(pg) { 1.414f }) < 0.05f
                                        } == true))
                                    }
                                }
                                if (tapped != null) activeAnnot = tapped else barsVisible = !barsVisible
                            }
                        },
                    )
                }
                .pointerInput(Unit) {
                    // Pinch-zoom + pan. Runs in the Initial pass so it can take over from the list
                    // only when two fingers are down or the page is already zoomed in.
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                        do {
                            val event = awaitPointerEvent(PointerEventPass.Initial)
                            val multi = event.changes.count { it.pressed } >= 2
                            if (!selecting && (multi || scale > 1f)) {
                                val zoom = event.calculateZoom()
                                val pan = event.calculatePan()
                                if (zoom != 1f || pan != Offset.Zero) {
                                    val newScale = (scale * zoom).coerceIn(1f, MAX_SCALE)
                                    scale = newScale
                                    val maxX = size.width * (newScale - 1f) / 2f
                                    offsetX = if (newScale <= 1f) 0f else (offsetX + pan.x).coerceIn(-maxX, maxX)
                                    listState.dispatchRawDelta(-pan.y / newScale)
                                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                                }
                            }
                        } while (event.changes.any { it.pressed })
                    }
                }
        ) {
            val renderWidth = (constraints.maxWidth * 1.25f).toInt().coerceIn(600, 1400)
            val cache = remember(doc, renderWidth) {
                val maxBytes = (Runtime.getRuntime().maxMemory() / 4).toInt()
                object : LruCache<Int, Bitmap>(maxBytes) {
                    override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
                }
            }
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        translationX = offsetX
                    },
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(horizontal = PAGE_SIDE_PAD, vertical = 10.dp),
            ) {
                items(count = doc.pageCount, key = { it }) { index ->
                    PageItem(
                        index = index,
                        aspect = aspects.getOrElse(index) { 1.414f },
                        onAspect = { i, a ->
                            if (i in aspects.indices && kotlin.math.abs(aspects[i] - a) > 0.01f) aspects[i] = a
                        },
                        doc = doc,
                        cache = cache,
                        renderWidth = renderWidth,
                        night = night,
                        highlight = if (read.active && read.page == index) read.highlight else emptyList(),
                        annots = annots.filter { it.page == index },
                        selection = if (selection.sel?.page == index) selection.rects() else emptyList(),
                        handles = if (selection.sel?.page == index) selection.handles() else null,
                        wordHighlight = emptyList(),
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = barsVisible,
            modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding(),
            enter = fadeIn() + slideInVertically { -it },
            exit = fadeOut() + slideOutVertically { -it },
        ) {
            val activity = context as? android.app.Activity
            TopAppBar(
                title = {
                    Column(Modifier.fillMaxWidth(0.9f)) {
                        Text(
                            text = state.name,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        )
                        Text(
                            text = "صفحه $currentPage از ${doc.pageCount}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                },
                actions = {
                    // Oval Day / Night Switch with Sun and Moon
                    DayNightSwitch(
                        night = night,
                        onToggle = { container.settings.update { it.copy(nightMode = !it.nightMode) } },
                        modifier = Modifier.padding(end = 2.dp),
                    )
                    // Screen Rotation Button
                    IconButton(onClick = {
                        val act = activity ?: return@IconButton
                        act.requestedOrientation = if (act.requestedOrientation == android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE) {
                            android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                        } else {
                            android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                        }
                    }) {
                        AppIconView(AppIcon.Rotate, tint = MaterialTheme.colorScheme.onSurface, size = 20.dp)
                    }
                    IconButton(onClick = onToggleFavorite) {
                        Icon(
                            if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = stringResource(R.string.favorite),
                            tint = if (favorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                        )
                    }
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = stringResource(R.string.more))
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("هایلایت‌ها و یادداشت‌ها (${annots.size})") },
                            onClick = { listOpen = true; menuOpen = false },
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.go_to_page)) },
                            onClick = { jumpOpen = true; menuOpen = false },
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.share)) },
                            onClick = { sharePdf(context, Uri.parse(state.uri)); menuOpen = false },
                        )
                        DropdownMenuItem(
                            text = { Text("تنظیمات") },
                            onClick = { menuOpen = false; onOpenSettings() },
                        )
                    }
                },
            )
        }

        // selection actions: appear near the bottom of the reading area (closer to the selection)
        // instead of the far top of the screen
        selection.sel?.let {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(bottom = if (read.active) 160.dp else if (barsVisible) 88.dp else 24.dp)
                        .padding(horizontal = 8.dp),
                    shape = RoundedCornerShape(50),
                    tonalElevation = 8.dp,
                    shadowElevation = 10.dp,
                ) {
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(0.dp),
                    ) {
                        for (col in HIGHLIGHT_COLORS) {
                            Box(
                                Modifier
                                    .padding(horizontal = 4.dp)
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(Color(col).copy(alpha = 1f))
                                    .clickable { commitSelection(col, "") }
                            )
                        }
                        val small = MaterialTheme.typography.labelMedium
                        TextButton(onClick = { commitSelection(0xFFE53935.toInt(), "", 1) }) { Text("خط‌زیر", style = small) }
                        TextButton(onClick = { commitSelection(0xFFE53935.toInt(), "", 2) }) { Text("خط‌خورده", style = small) }
                        TextButton(onClick = {
                            clipboard.setText(AnnotatedString(selection.text()))
                            Toast.makeText(context, "کپی شد", Toast.LENGTH_SHORT).show()
                            selection.clear()
                        }) { Text("کپی", style = small) }
                        TextButton(onClick = { noteOpen = true }) { Text("یادداشت", style = small) }
                        // Dictionary / lookup — opens Wiktionary (or Google Translate for multi-word)
                        TextButton(onClick = {
                            val q = selection.text().trim()
                            if (q.isNotBlank()) {
                                val url = if (q.split(Regex("\\s+")).size <= 2) {
                                    "https://en.wiktionary.org/wiki/" + java.net.URLEncoder.encode(q, "UTF-8")
                                } else {
                                    "https://translate.google.com/?sl=auto&tl=fa&text=" + java.net.URLEncoder.encode(q, "UTF-8")
                                }
                                try {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                } catch (_: Exception) {
                                    Toast.makeText(context, "باز کردن دیکشنری ممکن نشد", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }) { Text("دیکشنری", style = small) }
                        TextButton(onClick = { selection.clear() }) { Text("✕", style = small) }
                    }
                }
            }
        }

        // Side scrollbar removed: it was too easy to touch accidentally and jump pages.
        // Page number is already shown in the top app bar. Jump dialog remains available via long-press / toolbar if needed.

        // floating tool bar: hides by itself, a tap on the page brings it back
        if (!read.active) {
            val page0 = (currentPage - 1).coerceIn(0, doc.pageCount - 1)
            AnimatedVisibility(
                visible = barsVisible,
                modifier = Modifier.align(Alignment.BottomCenter),
                enter = fadeIn() + androidx.compose.animation.slideInVertically { it },
                exit = fadeOut() + androidx.compose.animation.slideOutVertically { it },
            ) {
                ReaderToolsBar(
                    items = listOf(
                        ToolItem(AppIcon.Speaker, "خواندن") { ctrl.start(doc, state.uri, page0, ReadMode.ORIGINAL) },
                        ToolItem(AppIcon.ReadTranslate, "خواندن با ترجمه") { ctrl.start(doc, state.uri, page0, ReadMode.TRANSLATE_AUDIO) },
                        ToolItem(AppIcon.Globe, "ترجمه") { onAiTask(AiTask.TRANSLATE, page0, false) },
                        ToolItem(AppIcon.Summary, "خلاصه") { onAiTask(AiTask.SUMMARIZE, page0, false) },
                        ToolItem(AppIcon.More, "بیشتر") { moreOpen = true },
                        ToolItem(AppIcon.Sparkle, "دستیار AI", accent = true) { chatOpen = true },
                    ),
                    modifier = Modifier.navigationBarsPadding().padding(horizontal = 12.dp, vertical = 12.dp),
                )
            }
        } else {
            ReadAloudPanel(read, ctrl, Modifier.align(Alignment.BottomCenter))
        }
    }

    AiResultSheet(
        state = ai,
        bilingual = bilingual,
        onBilingualChange = onBilingual,
        onDismiss = onAiDismiss,
        onRetry = { d ->
            if (d.rangeTo >= 0) onRangeSummary(d.page, d.rangeTo, true) else onAiTask(d.task, d.page, true)
        },
        onCancel = onAiCancel,
        onNextModel = onAiNextModel,
    )
    if (chatOpen) {
        ChatSheet(
            chat = chat,
            currentPage = currentPage.coerceAtMost(doc.pageCount),
            onSend = { q -> chat.send(doc, state.uri, (currentPage - 1).coerceIn(0, doc.pageCount - 1), q) },
            onDismiss = { chatOpen = false },
        )
    }
    if (rangeOpen) {
        RangeDialog(
            current = currentPage.coerceAtMost(doc.pageCount),
            total = doc.pageCount,
            onDismiss = { rangeOpen = false },
            onStart = { f, t ->
                rangeOpen = false
                onRangeSummary(f, t, false)
            },
        )
    }

    if (moreOpen) {
        ModalBottomSheet(onDismissRequest = { moreOpen = false }) {
            val page0 = (currentPage - 1).coerceIn(0, doc.pageCount - 1)
            Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                for ((icon, label, action) in listOf(
                    Triple<AppIcon, String, () -> Unit>(AppIcon.Explain, "توضیح این صفحه", { onAiTask(AiTask.EXPLAIN, page0, false) }),
                    Triple<AppIcon, String, () -> Unit>(AppIcon.Ocr, "استخراج متن صفحه (OCR)", { onAiTask(AiTask.EXTRACT, page0, false) }),
                    Triple<AppIcon, String, () -> Unit>(AppIcon.Range, "خلاصه‌ی بازه‌ی صفحه‌ها", { rangeOpen = true }),
                )) {
                    Surface(
                        shape = RoundedCornerShape(22.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth().clickable { moreOpen = false; action() },
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            AppIconView(icon, MaterialTheme.colorScheme.primary, size = 26.dp)
                            Text(label, style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            }
        }
    }
    if (listOpen) {
        ModalBottomSheet(onDismissRequest = { listOpen = false }) {
            if (annots.isEmpty()) {
                Text(
                    "هنوز هایلایت یا یادداشتی ندارید. روی متن نگه دارید تا انتخاب شود.",
                    modifier = Modifier.padding(24.dp),
                    style = MaterialTheme.typography.bodyMedium,
                )
            } else {
                LazyColumn(Modifier.padding(bottom = 24.dp)) {
                    items(annots.sortedWith(compareBy({ it.page }, { it.created })), key = { it.id }) { a ->
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    listOpen = false
                                    scope.launch { listState.animateScrollToItem(a.page) }
                                }
                                .padding(horizontal = 20.dp, vertical = 10.dp)
                        ) {
                            Text("صفحه ${a.page + 1}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            Text(a.text, maxLines = 2, style = MaterialTheme.typography.bodyMedium)
                            if (a.note.isNotBlank()) Text(a.note, maxLines = 3, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row {
                                TextButton(onClick = { activeAnnot = a; listOpen = false }) { Text("ویرایش") }
                                TextButton(onClick = {
                                    annots.removeAll { it.id == a.id }
                                    persistAnnots()
                                }) { Text("حذف") }
                            }
                        }
                    }
                }
            }
        }
    }
    if (noteOpen) {
        var note by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { noteOpen = false },
            title = { Text("افزودن یادداشت") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(selection.text(), maxLines = 4, style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(
                        value = note, onValueChange = { note = it }, label = { Text("یادداشت") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    commitSelection(0xFFFFB300.toInt(), note, 3)
                    noteOpen = false
                }) { Text("ذخیره") }
            },
            dismissButton = { TextButton(onClick = { noteOpen = false }) { Text("انصراف") } },
        )
    }
    activeAnnot?.let { a ->
        var note by remember(a.id) { mutableStateOf(a.note) }
        AlertDialog(
            onDismissRequest = { activeAnnot = null },
            title = { Text(if (a.note.isBlank()) "هایلایت" else "یادداشت") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(a.text, maxLines = 6, style = MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(
                        value = note, onValueChange = { note = it }, label = { Text("یادداشت") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row {
                        TextButton(onClick = {
                            clipboard.setText(AnnotatedString(a.text))
                            Toast.makeText(context, "کپی شد", Toast.LENGTH_SHORT).show()
                        }) { Text("کپی متن") }
                        TextButton(onClick = {
                            annots.removeAll { it.id == a.id }
                            persistAnnots()
                            activeAnnot = null
                        }) { Text("حذف") }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val i = annots.indexOfFirst { it.id == a.id }
                    if (i >= 0) {
                        annots[i] = a.copy(note = note.trim())
                        persistAnnots()
                    }
                    activeAnnot = null
                }) { Text("ذخیره") }
            },
            dismissButton = { TextButton(onClick = { activeAnnot = null }) { Text("بستن") } },
        )
    }

    if (jumpOpen) {
        var text by remember { mutableStateOf(currentPage.toString()) }
        AlertDialog(
            onDismissRequest = { jumpOpen = false },
            title = { Text(stringResource(R.string.go_to_page)) },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it.filter(Char::isDigit).take(6) },
                    label = { Text(stringResource(R.string.page_number)) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    text.toIntOrNull()?.let { n ->
                        scope.launch { listState.scrollToItem((n - 1).coerceIn(0, doc.pageCount - 1)) }
                    }
                    jumpOpen = false
                }) { Text(stringResource(R.string.ok)) }
            },
            dismissButton = {
                TextButton(onClick = { jumpOpen = false }) { Text(stringResource(R.string.cancel)) }
            },
        )
    }
}

@Composable
private fun PageItem(
    index: Int,
    aspect: Float,
    doc: PdfDocument,
    cache: LruCache<Int, Bitmap>,
    renderWidth: Int,
    night: Boolean,
    onAspect: (Int, Float) -> Unit,
    highlight: List<NRect> = emptyList(),
    annots: List<Annot> = emptyList(),
    selection: List<NRect> = emptyList(),
    handles: Pair<NPoint, NPoint>? = null,
    wordHighlight: List<NRect> = emptyList(),
) {
    val bitmap by produceState<Bitmap?>(initialValue = cache.get(index), index, cache) {
        if (value == null) {
            value = try {
                doc.render(index, renderWidth).also {
                    cache.put(index, it)
                    onAspect(index, it.height.toFloat() / it.width.toFloat())
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null // closed document or render failure: show the blank placeholder
            }
        }
    }
    val shape = Modifier
        .fillMaxWidth()
        .aspectRatioOf(aspect)
        .shadow(3.dp, RoundShape(16.dp))
        .clip(RoundShape(16.dp))
    val bmp = bitmap
    Box(shape) {
        if (bmp == null) {
            Box(Modifier.fillMaxSize().background(if (night) Color.DarkGray else Color.White))
        } else {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillWidth,
                colorFilter = if (night) ColorFilter.colorMatrix(InvertMatrix) else null,
            )
        }
        if (highlight.isNotEmpty() || annots.isNotEmpty() || selection.isNotEmpty() || wordHighlight.isNotEmpty() || handles != null) {
            Canvas(Modifier.fillMaxSize()) {
                for (a in annots) {
                    val col = Color(a.color)
                    for (r in a.rects) {
                        when (a.kind) {
                            1, 2, 3 -> {
                                val y = if (a.kind == 2) (r.t + r.b) / 2f else r.b
                                drawLine(
                                    color = col.copy(alpha = 1f),
                                    start = Offset(r.l * size.width, y * size.height),
                                    end = Offset(r.r * size.width, y * size.height),
                                    strokeWidth = 1.dp.toPx(),
                                )
                            }
                            else -> drawRoundRect(
                                color = col,
                                topLeft = Offset(r.l * size.width, r.t * size.height),
                                size = Size((r.r - r.l) * size.width, (r.b - r.t) * size.height),
                                cornerRadius = CornerRadius(3f, 3f),
                            )
                        }
                    }
                    if (a.note.isNotBlank()) {
                        a.markerPoint()?.let { (mx, my) ->
                            val cx = mx * size.width
                            val cy = my * size.height
                            val sz = 9.dp.toPx()
                            drawRoundRect(Color(0xFFFFB300), Offset(cx - sz, cy - sz), Size(2 * sz, 2 * sz), CornerRadius(5.dp.toPx(), 5.dp.toPx()))
                            drawLine(Color.White, Offset(cx - sz * 0.5f, cy - sz * 0.25f), Offset(cx + sz * 0.5f, cy - sz * 0.25f), strokeWidth = 1.5f.dp.toPx())
                            drawLine(Color.White, Offset(cx - sz * 0.5f, cy + sz * 0.3f), Offset(cx + sz * 0.25f, cy + sz * 0.3f), strokeWidth = 1.5f.dp.toPx())
                        }
                    }
                }
                for (r in selection) {
                    drawRoundRect(
                        color = Color(0x663D5AFE),
                        topLeft = Offset(r.l * size.width, r.t * size.height),
                        size = Size((r.r - r.l) * size.width, (r.b - r.t) * size.height),
                        cornerRadius = CornerRadius(3f, 3f),
                    )
                }
                for (r in highlight) {
                    // lighter and a little taller than the text line, so it reads like a marker pen
                    val padY = (r.b - r.t) * 0.2f * size.height
                    val padX = 3.dp.toPx()
                    drawRoundRect(
                        color = Color(0x40FFC400),
                        topLeft = Offset(r.l * size.width - padX, r.t * size.height - padY),
                        size = Size((r.r - r.l) * size.width + 2 * padX, (r.b - r.t) * size.height + 2 * padY),
                        cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx()),
                    )
                }
                for (r in wordHighlight) {
                    drawRoundRect(
                        color = Color(0x99FF9100),
                        topLeft = Offset(r.l * size.width, r.t * size.height),
                        size = Size((r.r - r.l) * size.width, (r.b - r.t) * size.height),
                        cornerRadius = CornerRadius(4f, 4f),
                    )
                }
                handles?.let { (p1, p2) ->
                    for (p in listOf(p1, p2)) {
                        val x = p.x * size.width
                        val y = p.y * size.height
                        drawLine(Color(0xFF3D5AFE), Offset(x, y), Offset(x, y + 5.dp.toPx()), strokeWidth = 2.dp.toPx())
                        drawCircle(Color(0xFF3D5AFE), radius = 6.dp.toPx(), center = Offset(x, y + 10.dp.toPx()))
                    }
                }
            }
        }
    }
}

private val PAGE_SIDE_PAD = 10.dp

private fun Modifier.aspectRatioOf(heightOverWidth: Float): Modifier =
    this.then(Modifier.aspectRatio(1f / heightOverWidth))

private fun sharePdf(context: Context, uri: Uri) {
    try {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(send, null))
    } catch (e: Exception) {
        Toast.makeText(context, R.string.err_share, Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun RangeDialog(current: Int, total: Int, onDismiss: () -> Unit, onStart: (Int, Int) -> Unit) {
    var from by remember { mutableStateOf(current.toString()) }
    var to by remember { mutableStateOf(minOf(total, current + 9).toString()) }
    val f = from.toIntOrNull()
    val t = to.toIntOrNull()
    val valid = f != null && t != null && f in 1..total && t in 1..total
    val n = if (valid) kotlin.math.abs(t!! - f!!) + 1 else 0
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("خلاصه‌ی بازه‌ی صفحه‌ها") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = from, onValueChange = { from = it.filter(Char::isDigit).take(6) },
                        label = { Text("از صفحه") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        value = to, onValueChange = { to = it.filter(Char::isDigit).take(6) },
                        label = { Text("تا صفحه") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                    )
                }
                Text(
                    if (valid) "برای خواندن این $n صفحه تا $n درخواست به هوش مصنوعی فرستاده می‌شود (صفحه‌هایی که در این نشست قبلاً خوانده شده‌اند دوباره درخواست نمی‌شوند) و بعد خلاصه تهیه می‌شود."
                    else "شماره‌ی صفحه‌ها را درست وارد کنید (۱ تا $total).",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { if (valid) onStart(f!! - 1, t!! - 1) }, enabled = valid) { Text("شروع") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun DayNightSwitch(
    night: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val bg = if (night) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surfaceContainerHigh
    val thumbBg = if (night) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primaryContainer
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .clickable(onClick = onToggle)
            .padding(2.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(if (!night) thumbBg else Color.Transparent),
                contentAlignment = Alignment.Center,
            ) {
                AppIconView(
                    icon = AppIcon.Sun,
                    tint = if (!night) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    size = 15.dp,
                )
            }
            Box(
                modifier = Modifier
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(if (night) thumbBg else Color.Transparent),
                contentAlignment = Alignment.Center,
            ) {
                AppIconView(
                    icon = AppIcon.Moon,
                    tint = if (night) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    size = 15.dp,
                )
            }
        }
    }
}
