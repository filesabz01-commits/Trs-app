package app.pdfreader.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.util.LruCache
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import app.pdfreader.R
import app.pdfreader.ReaderApp
import app.pdfreader.ai.AiTask
import app.pdfreader.core.pdf.PdfDocument
import app.pdfreader.data.Annot
import app.pdfreader.data.HIGHLIGHT_COLORS
import app.pdfreader.data.markerPoint
import app.pdfreader.tts.NRect
import app.pdfreader.tts.ReadMode
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID

private val InvertMatrix = ColorMatrix(
    floatArrayOf(
        -1f,  0f,  0f, 0f, 255f,
         0f, -1f,  0f, 0f, 255f,
         0f,  0f, -1f, 0f, 255f,
         0f,  0f,  0f, 1f,   0f,
    )
)

private const val MAX_SCALE = 4.0f
private const val DOUBLE_TAP_SCALE = 2.0f

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(
    state: ReaderState.Open,
    favorite: Boolean,
    onBack: () -> Unit,
    onToggleFavorite: () -> Unit,
    onProgress: (page: Int, offset: Int) -> Unit,
    ai: AiUi,
    bilingual: Boolean,
    onBilingual: (Boolean) -> Unit,
    onAiTask: (AiTask, Int, Boolean) -> Unit,
    onRangeSummary: (Int, Int, Boolean) -> Unit,
    onAiDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val ctrl = remember { (context.applicationContext as ReaderApp).container.readAloud }
    val read by ctrl.state.collectAsStateWithLifecycle()
    val chat: ChatViewModel = viewModel()
    var chatOpen by remember { mutableStateOf(false) }
    var rangeOpen by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val doc = state.doc
    val container = remember { (context.applicationContext as ReaderApp).container }
    val clipboard = LocalClipboardManager.current

    val annots = remember(state.uri) { mutableStateListOf<Annot>() }
    LaunchedEffect(state.uri) {
        val saved = container.annotations.load(state.uri)
        annots.clear()
        annots.addAll(saved)
    }

    val selection = remember(state.uri) {
        SelectionController(container.pdfiumText, state.uri, scope) { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
    }

    var selecting by remember { mutableStateOf(false) }
    var activeAnnot by remember { mutableStateOf<Annot?>(null) }
    var noteOpen by remember { mutableStateOf(false) }
    var listOpen by remember { mutableStateOf(false) }

    fun persistAnnots() {
        val snapshot = annots.toList()
        scope.launch { container.annotations.save(state.uri, snapshot) }
    }

    fun commitSelection(color: Int, note: String, kind: Int = 0) {
        val s = selection.sel ?: return
        val rects = selection.rects()
        if (rects.isEmpty()) return
        annots.add(Annot(UUID.randomUUID().toString(), s.page, color, rects, selection.text(), note.trim(), System.currentTimeMillis(), kind))
        persistAnnots()
        selection.clear()
    }

    val listState = rememberLazyListState(state.startPage, state.startOffset)
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }

    // Auto-hide toolbar state (Adobe Acrobat style)
    var barsVisible by remember { mutableStateOf(true) }
    var lastInteractionTime by remember { mutableLongStateOf(System.currentTimeMillis()) }

    fun registerInteraction() {
        lastInteractionTime = System.currentTimeMillis()
        barsVisible = true
    }

    // Auto-hide bottom toolbar and top bar after ~3s of no interaction
    LaunchedEffect(lastInteractionTime, barsVisible, read.active) {
        if (!read.active && barsVisible) {
            kotlinx.coroutines.delay(3_000L)
            barsVisible = false
        }
    }

    // Reappear on user scroll
    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemScrollOffset }
            .collect { registerInteraction() }
    }

    val readerSettings by container.settings.state.collectAsStateWithLifecycle()
    val night = readerSettings.nightMode
    var menuOpen by remember { mutableStateOf(false) }
    var jumpOpen by remember { mutableStateOf(false) }

    // Collapsible processing status indicator state
    var statusCardExpanded by remember { mutableStateOf(false) }
    val activeStatus = read.status ?: when (ai) {
        is AiUi.Loading -> ai.phase
        is AiUi.Streaming -> "در حال دریافت پاسخ هوش مصنوعی…"
        else -> null
    }

    // Auto-collapse status card when done
    LaunchedEffect(activeStatus) {
        if (activeStatus == null) {
            statusCardExpanded = false
        }
    }

    // Center page index
    val currentPage by remember {
        derivedStateOf {
            val info = listState.layoutInfo
            val center = (info.viewportStartOffset + info.viewportEndOffset) / 2
            val hit = info.visibleItemsInfo.minByOrNull {
                val end = it.offset + it.size
                if (center in it.offset until end) 0 else minOf(kotlin.math.abs(center - it.offset), kotlin.math.abs(center - end))
            }
            (hit?.index ?: listState.firstVisibleItemIndex) + 1
        }
    }

    // Notify ReadAloudController of page scrolling to prioritize prefetching
    LaunchedEffect(currentPage) {
        ctrl.onPageScrolled((currentPage - 1).coerceIn(0, doc.pageCount - 1))
    }

    DisposableEffect(ctrl) { onDispose { ctrl.stop() } }

    LaunchedEffect(read.page, read.active) {
        if (read.active) listState.animateScrollToItem(read.page)
    }

    LaunchedEffect(read.highlight) {
        val r = read.highlight.firstOrNull() ?: return@LaunchedEffect
        if (selecting) return@LaunchedEffect
        val item = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == read.page } ?: return@LaunchedEffect
        val vh = (listState.layoutInfo.viewportEndOffset - listState.layoutInfo.viewportStartOffset).toFloat()
        val y = item.offset + r.t * item.size
        if (y < vh * 0.12f || y > vh * 0.55f) listState.animateScrollBy(y - vh * 0.25f)
    }

    val aspects = remember(doc) { mutableStateListOf<Float>().apply { addAll(state.aspects) } }

    fun hitPage(p: Offset, w: Float, h: Float): Triple<Int, Float, Float>? {
        if (w <= 0f || h <= 0f) return null
        val ux = w / 2f + (p.x - w / 2f - offsetX) / scale
        val uy = h / 2f + (p.y - h / 2f) / scale
        val item = listState.layoutInfo.visibleItemsInfo.firstOrNull { uy >= it.offset && uy < it.offset + it.size } ?: return null
        if (item.size <= 0) return null
        return Triple(item.index, (ux / w).coerceIn(0f, 1f), ((uy - item.offset) / item.size).coerceIn(0f, 1f))
    }

    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex to listState.firstVisibleItemScrollOffset }
            .debounce(600)
            .collect { (p, o) -> onProgress(p, o) }
    }

    DisposableEffect(listState) {
        onDispose { onProgress(listState.firstVisibleItemIndex, listState.firstVisibleItemScrollOffset) }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(if (night) Color.Black else MaterialTheme.colorScheme.surfaceVariant)
    ) {
        BoxWithConstraints(
            Modifier
                .fillMaxSize()
                .clipToBounds()
                .pointerInput(state.uri) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                        val gw = size.width.toFloat()
                        val gh = size.height.toFloat()

                        val grabbed = if (selection.sel == null) 0 else
                            hitPage(down.position, gw, gh)?.let { selection.grab(it.first, it.second, it.third, aspects.getOrElse(it.first) { 1.414f }) } ?: 0

                        if (grabbed != 0) {
                            selecting = true
                            registerInteraction()
                            try {
                                down.consume()
                                while (true) {
                                    val ev = awaitPointerEvent(PointerEventPass.Initial)
                                    val c = ev.changes.firstOrNull { it.id == down.id }
                                    ev.changes.forEach { it.consume() }
                                    if (c == null || !c.pressed) break
                                    hitPage(c.position, gw, gh)?.let { selection.moveHandle(grabbed, it.first, it.second, it.third) }
                                    if (c.position.y < 90f) listState.dispatchRawDelta(-18f)
                                    else if (c.position.y > gh - 90f) listState.dispatchRawDelta(18f)
                                }
                            } finally {
                                selecting = false
                            }
                            return@awaitEachGesture
                        }

                        val slop = viewConfiguration.touchSlop
                        val aborted: Boolean? = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                            var stop = false
                            while (!stop) {
                                val ev = awaitPointerEvent(PointerEventPass.Initial)
                                val c = ev.changes.firstOrNull { it.id == down.id }
                                stop = c == null || !c.pressed || ev.changes.count { it.pressed } > 1 ||
                                    (c.position - down.position).getDistance() > slop
                            }
                            true
                        }

                        if (aborted == null) {
                            val w = size.width.toFloat()
                            val h = size.height.toFloat()
                            selecting = true
                            registerInteraction()
                            try {
                                selection.clear()
                                hitPage(down.position, w, h)?.let { selection.begin(it.first, it.second, it.third) }
                                while (true) {
                                    val ev = awaitPointerEvent(PointerEventPass.Initial)
                                    val c = ev.changes.firstOrNull { it.id == down.id }
                                    ev.changes.forEach { it.consume() }
                                    if (c == null || !c.pressed) break
                                    hitPage(c.position, w, h)?.let { selection.extend(it.first, it.second, it.third) }
                                    if (c.position.y < 90f) listState.dispatchRawDelta(-18f)
                                    else if (c.position.y > h - 90f) listState.dispatchRawDelta(18f)
                                }
                            } finally {
                                selecting = false
                            }
                        }
                    }
                }
                .pointerInput(state.uri) {
                    detectTapGestures(
                        onDoubleTap = {
                            registerInteraction()
                            if (scale > 1f) {
                                scale = 1f
                                offsetX = 0f
                            } else {
                                scale = DOUBLE_TAP_SCALE
                            }
                        },
                        onTap = { pos ->
                            registerInteraction()
                            if (selection.sel != null) {
                                selection.clear()
                            } else {
                                val hit = hitPage(pos, size.width.toFloat(), size.height.toFloat())
                                val tapped = hit?.let { (pg, nx, ny) ->
                                    annots.lastOrNull { a ->
                                        a.page == pg && (a.rects.any { r ->
                                            nx >= r.l - 0.01f && nx <= r.r + 0.01f && ny >= r.t - 0.01f && ny <= r.b + 0.01f
                                        } || (a.note.isNotBlank() && a.markerPoint()?.let { (mx, my) ->
                                            kotlin.math.abs(nx - mx) < 0.05f && kotlin.math.abs((ny - my) * aspects.getOrElse(pg) { 1.414f }) < 0.05f
                                        } == true))
                                    }
                                }
                                if (tapped != null) activeAnnot = tapped else barsVisible = !barsVisible
                            }
                        },
                    )
                }
                .pointerInput(Unit) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                        do {
                            val event = awaitPointerEvent(PointerEventPass.Initial)
                            val multi = event.changes.count { it.pressed } >= 2
                            if (!selecting && (multi || scale > 1f)) {
                                val zoom = event.calculateZoom()
                                val pan = event.calculatePan()
                                if (zoom != 1f || pan != Offset.Zero) {
                                    val newScale = (scale * zoom).coerceIn(1f, MAX_SCALE)
                                    scale = newScale
                                    val maxX = size.width * (newScale - 1f) / 2f
                                    offsetX = if (newScale <= 1f) 0f else (offsetX + pan.x).coerceIn(-maxX, maxX)
                                    listState.dispatchRawDelta(-pan.y / newScale)
                                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                                }
      