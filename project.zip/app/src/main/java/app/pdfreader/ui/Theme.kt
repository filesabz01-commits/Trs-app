package app.pdfreader.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// A calm indigo + teal identity, the same in light and dark mode.
private val LightColors = lightColorScheme(
    primary = Color(0xFF3949AB),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDDE1FF),
    onPrimaryContainer = Color(0xFF0B1561),
    secondary = Color(0xFF00796B),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFB9ECE2),
    onSecondaryContainer = Color(0xFF00201B),
    tertiary = Color(0xFFB4533C),
    background = Color(0xFFF7F7FB),
    surface = Color(0xFFF7F7FB),
    surfaceVariant = Color(0xFFE3E4EE),
    onSurfaceVariant = Color(0xFF454654),
    outlineVariant = Color(0xFFC6C7D4),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFB8C3FF),
    onPrimary = Color(0xFF14247A),
    primaryContainer = Color(0xFF2B3A92),
    onPrimaryContainer = Color(0xFFDDE1FF),
    secondary = Color(0xFF7FD6C8),
    onSecondary = Color(0xFF003730),
    secondaryContainer = Color(0xFF00504A),
    onSecondaryContainer = Color(0xFFB9ECE2),
    tertiary = Color(0xFFFFB4A1),
    background = Color(0xFF111218),
    surface = Color(0xFF111218),
    surfaceVariant = Color(0xFF2A2B36),
    onSurfaceVariant = Color(0xFFC6C7D4),
    outlineVariant = Color(0xFF454654),
)

private val BaseType = Typography()

// Roomier text: Persian and English paragraphs stay readable on a phone.
private val AppTypography = Typography(
    headlineSmall = BaseType.headlineSmall.copy(fontWeight = FontWeight.Bold),
    titleLarge = BaseType.titleLarge.copy(fontWeight = FontWeight.Bold),
    titleMedium = BaseType.titleMedium.copy(fontWeight = FontWeight.SemiBold, lineHeight = 24.sp),
    bodyLarge = BaseType.bodyLarge.copy(fontSize = 17.sp, lineHeight = 28.sp),
    bodyMedium = BaseType.bodyMedium.copy(fontSize = 15.sp, lineHeight = 23.sp),
    bodySmall = BaseType.bodySmall.copy(lineHeight = 19.sp),
    labelLarge = BaseType.labelLarge.copy(fontWeight = FontWeight.SemiBold),
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

@Composable
fun ReaderTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        typography = AppTypography,
        shapes = AppShapes,
        content = content,
    )
}
