package app.pdfreader.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Soft, modern, eye-friendly Material 3 color palette
private val LightColors = lightColorScheme(
    primary = Color(0xFF4655A8),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDFE2FF),
    onPrimaryContainer = Color(0xFF00115A),
    secondary = Color(0xFF2D6967),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFB1EFEA),
    onSecondaryContainer = Color(0xFF00201F),
    tertiary = Color(0xFF864A66),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFD8E7),
    onTertiaryContainer = Color(0xFF370722),
    background = Color(0xFFFAF9FD),
    onBackground = Color(0xFF1A1B21),
    surface = Color(0xFFFAF9FD),
    onSurface = Color(0xFF1A1B21),
    surfaceVariant = Color(0xFFE2E1EC),
    onSurfaceVariant = Color(0xFF454652),
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color(0xFFF4F3F9),
    surfaceContainer = Color(0xFFEEECEF),
    surfaceContainerHigh = Color(0xFFE8E6EB),
    surfaceContainerHighest = Color(0xFFE2E0E6),
    outline = Color(0xFF757682),
    outlineVariant = Color(0xFFC6C5D2),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFBAC3FF),
    onPrimary = Color(0xFF122378),
    primaryContainer = Color(0xFF2D3C8F),
    onPrimaryContainer = Color(0xFFDFE2FF),
    secondary = Color(0xFF96D2CE),
    onSecondary = Color(0xFF003735),
    secondaryContainer = Color(0xFF0F4F4D),
    onSecondaryContainer = Color(0xFFB1EFEA),
    tertiary = Color(0xFFFBAFCF),
    onTertiary = Color(0xFF501E37),
    tertiaryContainer = Color(0xFF6B334E),
    onTertiaryContainer = Color(0xFFFFD8E7),
    background = Color(0xFF121318),
    onBackground = Color(0xFFE2E1E9),
    surface = Color(0xFF121318),
    onSurface = Color(0xFFE2E1E9),
    surfaceVariant = Color(0xFF454652),
    onSurfaceVariant = Color(0xFFC6C5D2),
    surfaceContainerLowest = Color(0xFF0D0E13),
    surfaceContainerLow = Color(0xFF1A1B21),
    surfaceContainer = Color(0xFF1E1F25),
    surfaceContainerHigh = Color(0xFF292A30),
    surfaceContainerHighest = Color(0xFF34353B),
    outline = Color(0xFF8F909D),
    outlineVariant = Color(0xFF454652),
)

private val BaseType = Typography()

// Generous, breathable typography for long reading sessions
private val AppTypography = Typography(
    displayMedium = BaseType.displayMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp),
    headlineSmall = BaseType.headlineSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 0.sp),
    titleLarge = BaseType.titleLarge.copy(fontWeight = FontWeight.Bold, lineHeight = 28.sp),
    titleMedium = BaseType.titleMedium.copy(fontWeight = FontWeight.SemiBold, lineHeight = 24.sp),
    titleSmall = BaseType.titleSmall.copy(fontWeight = FontWeight.Medium, lineHeight = 20.sp),
    bodyLarge = BaseType.bodyLarge.copy(fontSize = 17.sp, lineHeight = 28.sp),
    bodyMedium = BaseType.bodyMedium.copy(fontSize = 15.sp, lineHeight = 23.sp),
    bodySmall = BaseType.bodySmall.copy(fontSize = 13.sp, lineHeight = 19.sp),
    labelLarge = BaseType.labelLarge.copy(fontWeight = FontWeight.SemiBold, fontSize = 14.sp),
    labelMedium = BaseType.labelMedium.copy(fontWeight = FontWeight.Medium, fontSize = 12.sp),
    labelSmall = BaseType.labelSmall.copy(fontSize = 11.sp, lineHeight = 15.sp),
)

// Friendly modern shapes: 16-24dp for cards, 28dp for bottom sheets, 36dp for dialogs / pills
private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp), // cards: 20dp
    large = RoundedCornerShape(28.dp),  // bottom sheets: 28dp
    extraLarge = RoundedCornerShape(36.dp),
)

@Composable
fun ReaderTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        typography = AppTypography,
        shapes = AppShapes,
        content = content,
    )
}