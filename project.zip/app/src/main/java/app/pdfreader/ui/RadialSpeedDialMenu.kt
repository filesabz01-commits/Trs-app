package app.pdfreader.ui

import android.content.res.Configuration
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Model class for an item inside the Radial Speed Dial Menu.
 */
class RadialSpeedDialItem(
    val icon: AppIcon,
    val label: String,
    val accent: Boolean = false,
    val onClick: () -> Unit,
)

/**
 * Animated Radial Speed Dial Menu (Floating Action Button):
 * - Single main FAB anchored at the bottom center.
 * - Rotating Sparkle/Close icon (180-degree rotation).
 * - Smooth semi-circular / radial pop-out of tool buttons with staggered spring animation.
 * - Semi-transparent backdrop scrim that closes the menu on tap.
 * - Haptic feedback on button clicks.
 */
@Composable
fun RadialSpeedDialMenu(
    expanded: Boolean,
    onToggle: (Boolean) -> Unit,
    items: List<RadialSpeedDialItem>,
    modifier: Modifier = Modifier,
) {
    val haptic = LocalHapticFeedback.current
    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    val density = LocalDensity.current

    // Adaptive radius: slightly more compact in landscape so it stays within screen bounds
    val radiusDp = if (isLandscape) 105.dp else 135.dp
    val radiusPx = with(density) { radiusDp.toPx() }

    // Main FAB rotation from 0 to 180 degrees
    val rotation by animateFloatAsState(
        targetValue = if (expanded) 180f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow,
        ),
        label = "fab_rotation",
    )

    // Semi-circular angular distribution (spanning upwards from 165° on left to 15° on right)
    val count = items.size
    val angles = remember(count) {
        if (count <= 1) listOf(90.0)
        else {
            val startAngle = 165.0
            val endAngle = 15.0
            val step = (startAngle - endAngle) / (count - 1).toDouble()
            List(count) { i -> startAngle - (i * step) }
        }
    }

    Box(modifier = modifier) {
        // Translucent backdrop scrim layer
        AnimatedVisibility(
            visible = expanded,
            enter = fadeIn(tween(200)),
            exit = fadeOut(tween(180)),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.28f))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                    ) {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onToggle(false)
                    }
            )
        }

        // Radial speed dial container anchored at bottom center
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = if (isLandscape) 8.dp else 16.dp),
            contentAlignment = Alignment.Center,
        ) {
            // Render Radial Buttons
            items.forEachIndexed { index, item ->
                val angleDeg = angles.getOrElse(index) { 90.0 }
                val angleRad = Math.toRadians(angleDeg)

                // Staggered expansion animation for each radial item
                val anim = remember { Animatable(0f) }
                LaunchedEffect(expanded) {
                    if (expanded) {
                        delay(index * 28L)
                        anim.animateTo(
                            targetValue = 1f,
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioMediumBouncy,
                                stiffness = Spring.StiffnessMediumLow,
                            ),
                        )
                    } else {
                        val reverseIndex = (count - 1 - index).coerceAtLeast(0)
                        delay(reverseIndex * 15L)
                        anim.animateTo(
                            targetValue = 0f,
                            animationSpec = tween(durationMillis = 140),
                        )
                    }
                }

                if (anim.value > 0.01f) {
                    val currentDist = radiusPx * anim.value
                    val offsetX = (currentDist * cos(angleRad)).roundToInt()
                    val offsetY = (-currentDist * sin(angleRad)).roundToInt()

                    // Icon-only radial button (label kept for a11y via contentDescription)
                    Surface(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onToggle(false)
                            item.onClick()
                        },
                        shape = CircleShape,
                        color = if (item.accent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHigh,
                        contentColor = if (item.accent) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                        shadowElevation = 6.dp,
                        tonalElevation = 4.dp,
                        modifier = Modifier
                            .offset { IntOffset(offsetX, offsetY) }
                            .scale(anim.value.coerceIn(0f, 1.15f))
                            .alpha(anim.value.coerceIn(0f, 1f))
                            .size(52.dp),
                    ) {
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                            AppIconView(
                                icon = item.icon,
                                tint = if (item.accent) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary,
                                size = 24.dp,
                            )
                        }
                    }
                }
            }

            // Main FAB
            FloatingActionButton(
                onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onToggle(!expanded)
                },
                shape = CircleShape,
                containerColor = if (expanded) MaterialTheme.colorScheme.surfaceContainerHigh else MaterialTheme.colorScheme.primary,
                contentColor = if (expanded) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onPrimary,
                elevation = FloatingActionButtonDefaults.elevation(
                    defaultElevation = 8.dp,
                    pressedElevation = 12.dp,
                ),
                modifier = Modifier
                    .size(58.dp)
                    .rotate(rotation),
            ) {
                if (rotation < 90f) {
                    // Closed state: Modern AI / Sparkles Icon
                    AppIconView(
                        icon = AppIcon.Sparkle,
                        tint = MaterialTheme.colorScheme.onPrimary,
                        size = 28.dp,
                    )
                } else {
                    // Opened state: Clean Close (✕) glyph
                    Text(
                        text = "✕",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                }
            }
        }
    }
}
