package app.pdfreader.data

import android.content.Context
import app.pdfreader.ai.sha256
import app.pdfreader.tts.NRect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** A highlight (with an optional note) on one page. Rectangles are normalized page coordinates (0..1). */
data class Annot(
    val id: String,
    val page: Int,
    val color: Int,
    val rects: List<NRect>,
    val text: String,
    val note: String,
    val created: Long,
    /** 0 = highlight, 1 = underline, 2 = strikethrough */
    val kind: Int = 0,
)

/** The colors offered for highlights (ARGB, translucent so the text stays readable). */
val HIGHLIGHT_COLORS: List<Int> = listOf(
    0x66FFD600.toInt(), // yellow
    0x6600C853.toInt(), // green
    0x66FF4081.toInt(), // pink
    0x6640C4FF.toInt(), // blue
)

/**
 * Highlights and notes live in one small JSON file per document (named after the document), so they survive
 * app restarts without touching the database schema.
 */
class AnnotationStore(context: Context) {
    private val dir = File(context.applicationContext.filesDir, "annotations").also { it.mkdirs() }

    private fun fileFor(uri: String) = File(dir, sha256(uri) + ".json")

    suspend fun load(uri: String): List<Annot> = withContext(Dispatchers.IO) {
        try {
            val f = fileFor(uri)
            if (!f.exists()) return@withContext emptyList()
            val arr = JSONArray(f.readText(Charsets.UTF_8))
            val out = ArrayList<Annot>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val rs = o.getJSONArray("rects")
                val rects = ArrayList<NRect>(rs.length())
                for (k in 0 until rs.length()) {
                    val r = rs.getJSONArray(k)
                    rects += NRect(r.getDouble(0).toFloat(), r.getDouble(1).toFloat(), r.getDouble(2).toFloat(), r.getDouble(3).toFloat())
                }
                out += Annot(
                    id = o.getString("id"), page = o.getInt("page"), color = o.getInt("color"), rects = rects,
                    text = o.optString("text"), note = o.optString("note"), created = o.optLong("created"),
                    kind = o.optInt("kind", 0),
                )
            }
            out
        } catch (e: Exception) {
            emptyList() // a damaged file must never stop the document from opening
        }
    }

    suspend fun save(uri: String, list: List<Annot>) = withContext(Dispatchers.IO) {
        try {
            val arr = JSONArray()
            for (a in list) {
                val rs = JSONArray()
                for (r in a.rects) rs.put(JSONArray().put(r.l.toDouble()).put(r.t.toDouble()).put(r.r.toDouble()).put(r.b.toDouble()))
                arr.put(
                    JSONObject().put("id", a.id).put("page", a.page).put("color", a.color).put("rects", rs)
                        .put("text", a.text).put("note", a.note).put("created", a.created).put("kind", a.kind)
                )
            }
            val f = fileFor(uri)
            val tmp = File(dir, f.name + ".tmp")
            tmp.writeText(arr.toString(), Charsets.UTF_8)
            if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
        } catch (e: Exception) {
            // saving is best effort; the in-memory list stays usable
        }
    }
}
