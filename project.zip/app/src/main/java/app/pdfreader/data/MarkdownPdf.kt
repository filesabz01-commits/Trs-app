package app.pdfreader.data

import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import java.io.File
import java.io.FileOutputStream

/** Lightweight Markdown to PDF (local). Headings, bullets, tables, RTL. */
object MarkdownPdf {

    fun render(markdown: String, outFile: File, title: String = "", rtl: Boolean = true): File {
        outFile.parentFile?.mkdirs()
        val doc = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val margin = 44f
        val contentWidth = (pageWidth - margin * 2).toInt()

        fun paint(size: Float, bold: Boolean = false): TextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            typeface = Typeface.create(Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL)
            color = 0xFF1A1A1A.toInt()
            textAlign = if (rtl) Paint.Align.RIGHT else Paint.Align.LEFT
        }

        val titlePaint = paint(17f, true)
        val h1 = paint(15f, true)
        val h2 = paint(13.5f, true)
        val body = paint(11.5f, false)
        val meta = paint(9f, false).apply { color = 0xFF666666.toInt() }
        val cell = paint(10f, false)

        var pageNum = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
        var canvas = page.canvas
        var y = margin

        fun newPage() {
            doc.finishPage(page)
            pageNum++
            page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
            canvas = page.canvas
            y = margin
        }

        fun ensureSpace(needed: Float) {
            if (y + needed > pageHeight - margin) newPage()
        }

        fun drawLayout(text: String, tp: TextPaint, spacingAfter: Float = 10f) {
            val clean = stripMd(text)
            if (clean.isBlank()) return
            val align = if (rtl) Layout.Alignment.ALIGN_OPPOSITE else Layout.Alignment.ALIGN_NORMAL
            val layout = StaticLayout.Builder.obtain(clean, 0, clean.length, tp, contentWidth)
                .setAlignment(align)
                .setLineSpacing(2f, 1.2f)
                .setIncludePad(false)
                .setTextDirection(if (rtl) TextDirectionHeuristics.RTL else TextDirectionHeuristics.LTR)
                .build()
            ensureSpace(layout.height + spacingAfter)
            canvas.save()
            canvas.translate(margin, y)
            layout.draw(canvas)
            canvas.restore()
            y += layout.height + spacingAfter
        }

        fun drawTable(rows: List<List<String>>) {
            if (rows.isEmpty()) return
            val cols = rows.maxOf { it.size }.coerceAtLeast(1)
            val colW = contentWidth.toFloat() / cols
            val pad = 4f
            val linePaint = Paint().apply { color = 0xFFDDDDDD.toInt(); strokeWidth = 1f }
            for (row in rows) {
                var rowH = 16f
                val layouts = mutableListOf<StaticLayout>()
                for (c in 0 until cols) {
                    val txt = stripMd(row.getOrElse(c) { "" })
                    val lay = StaticLayout.Builder.obtain(txt, 0, txt.length, cell, (colW - pad * 2).toInt().coerceAtLeast(20))
                        .setAlignment(if (rtl) Layout.Alignment.ALIGN_OPPOSITE else Layout.Alignment.ALIGN_NORMAL)
                        .setTextDirection(if (rtl) TextDirectionHeuristics.RTL else TextDirectionHeuristics.LTR)
                        .setIncludePad(false)
                        .build()
                    layouts += lay
                    rowH = maxOf(rowH, lay.height + pad * 2)
                }
                ensureSpace(rowH + 2)
                for (c in 0 until cols) {
                    val x = if (rtl) margin + (cols - 1 - c) * colW else margin + c * colW
                    canvas.save()
                    canvas.translate(x + pad, y + pad)
                    layouts[c].draw(canvas)
                    canvas.restore()
                }
                canvas.drawLine(margin, y + rowH, margin + contentWidth, y + rowH, linePaint)
                y += rowH
            }
            y += 12f
        }

        if (title.isNotBlank()) {
            drawLayout(title, titlePaint, 6f)
            drawLayout("جزوه مرور", meta, 14f)
        }

        val lines = markdown.replace("\r\n", "\n").split("\n")
        val para = StringBuilder()
        val tableBuf = mutableListOf<List<String>>()

        fun flushPara() {
            val t = para.toString().trim()
            if (t.isNotEmpty()) drawLayout(t, body, 12f)
            para.clear()
        }

        fun flushTable() {
            if (tableBuf.isNotEmpty()) {
                drawTable(tableBuf.toList())
                tableBuf.clear()
            }
        }

        fun isTableRow(s: String): Boolean {
            val t = s.trim()
            return t.startsWith("|") && t.indexOf('|', startIndex = 1) >= 0
        }

        fun isTableSep(s: String): Boolean =
            s.trim().matches(Regex("^\\|?[\\s:-]+\\|([\\s:-]+\\|)*[\\s:-]*\\|?$"))

        fun parseRow(s: String): List<String> =
            s.trim().trim('|').split("|").map { it.trim() }

        for (raw in lines) {
            val line = raw.trimEnd()
            val t = line.trim()
            when {
                isTableRow(t) && !isTableSep(t) -> {
                    flushPara()
                    tableBuf += parseRow(t)
                }
                isTableSep(t) -> { /* header separator */ }
                tableBuf.isNotEmpty() -> {
                    flushTable()
                    when {
                        t.isEmpty() -> flushPara()
                        t.startsWith("### ") -> { flushPara(); drawLayout(t.removePrefix("### ").trim(), h2, 8f) }
                        t.startsWith("## ") -> { flushPara(); drawLayout(t.removePrefix("## ").trim(), h1, 10f) }
                        t.startsWith("# ") -> { flushPara(); drawLayout(t.removePrefix("# ").trim(), titlePaint, 12f) }
                        t.startsWith("- ") || t.startsWith("* ") -> { flushPara(); drawLayout("• " + t.drop(2).trim(), body, 6f) }
                        t.matches(Regex("^\\d+[.)]\\s+.+")) -> { flushPara(); drawLayout(t, body, 6f) }
                        t.startsWith("---") -> { flushPara(); y += 8f }
                        else -> {
                            if (para.isNotEmpty()) para.append(' ')
                            para.append(t)
                        }
                    }
                }
                t.isEmpty() -> flushPara()
                t.startsWith("### ") -> { flushPara(); drawLayout(t.removePrefix("### ").trim(), h2, 8f) }
                t.startsWith("## ") -> { flushPara(); drawLayout(t.removePrefix("## ").trim(), h1, 10f) }
                t.startsWith("# ") -> { flushPara(); drawLayout(t.removePrefix("# ").trim(), titlePaint, 12f) }
                t.startsWith("- ") || t.startsWith("* ") -> { flushPara(); drawLayout("• " + t.drop(2).trim(), body, 6f) }
                t.matches(Regex("^\\d+[.)]\\s+.+")) -> { flushPara(); drawLayout(t, body, 6f) }
                t.startsWith("---") -> { flushPara(); y += 8f }
                else -> {
                    if (para.isNotEmpty()) para.append(' ')
                    para.append(t)
                }
            }
        }
        flushPara()
        flushTable()

        doc.finishPage(page)
        FileOutputStream(outFile).use { doc.writeTo(it) }
        doc.close()
        return outFile
    }

    private fun stripMd(s: String): String =
        s.replace(Regex("\\*\\*([^*]+)\\*\\*"), "$1")
            .replace(Regex("\\*([^*]+)\\*"), "$1")
            .replace(Regex("`([^`]+)`"), "$1")
            .trim()
}
