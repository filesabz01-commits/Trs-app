package app.pdfreader.data

import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import java.io.File
import java.io.FileOutputStream

/**
 * High-quality, local Markdown-to-PDF generator with clean typography,
 * native BiDi RTL handling (no text overlap), and rich local color accents.
 */
object MarkdownPdf {

    // Palette: Modern Teal & Slate for clean, readable study notes
    private const val COLOR_PRIMARY = 0xFF0F766E.toInt()      // Deep Teal for Headings
    private const val COLOR_PRIMARY_LIGHT = 0xFFF0FDFA.toInt()// Mint/Teal background
    private const val COLOR_PRIMARY_BORDER = 0xFF99F6E4.toInt()
    private const val COLOR_ACCENT = 0xFF0D9488.toInt()       // Vibrant Teal for bullets & bars
    private const val COLOR_H2 = 0xFF0369A1.toInt()           // Ocean Blue for Subheadings
    private const val COLOR_TEXT_MAIN = 0xFF334155.toInt()    // Slate 700 for Body
    private const val COLOR_TEXT_BOLD = 0xFF0F172A.toInt()    // Slate 900 for Bolds & Terms
    private const val COLOR_TEXT_MUTED = 0xFF64748B.toInt()   // Slate 500 for Meta/Footer
    private const val COLOR_BORDER = 0xFFE2E8F0.toInt()       // Light Slate border
    private const val COLOR_TABLE_HEADER = 0xFFF1F5F9.toInt() // Table header background
    private const val COLOR_TABLE_ALT = 0xFFF8FAFC.toInt()

    fun render(markdown: String, outFile: File, title: String = "", rtl: Boolean = true): File {
        outFile.parentFile?.mkdirs()
        val doc = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val margin = 38f
        val contentWidth = (pageWidth - margin * 2).toInt()

        // Critical: Paint.textAlign MUST be LEFT for StaticLayout!
        // StaticLayout controls alignment internally using Layout.Alignment & TextDirectionHeuristics.
        fun paint(size: Float, bold: Boolean = false, colorInt: Int = COLOR_TEXT_MAIN): TextPaint =
            TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = size
                typeface = Typeface.create(Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL)
                color = colorInt
                textAlign = Paint.Align.LEFT
            }

        val bodyPaint = paint(10.5f, false, COLOR_TEXT_MAIN)
        val h1Paint = paint(13.5f, true, COLOR_PRIMARY)
        val h2Paint = paint(12f, true, COLOR_H2)
        val metaPaint = paint(8.5f, false, COLOR_TEXT_MUTED)
        val cellPaint = paint(9.5f, false, COLOR_TEXT_MAIN)
        val cellBoldPaint = paint(9.5f, true, COLOR_TEXT_BOLD)

        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1f
            color = COLOR_BORDER
        }

        var pageNum = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
        var canvas = page.canvas
        var y = margin

        fun drawPageFooter() {
            val footerY = pageHeight - margin + 14f
            canvas.drawLine(margin, footerY - 8f, margin + contentWidth, footerY - 8f, borderPaint)
            val footerText = "صفحه $pageNum"
            val numW = metaPaint.measureText(footerText)
            canvas.drawText(footerText, margin + (contentWidth - numW) / 2f, footerY + 2f, metaPaint)
        }

        fun newPage() {
            drawPageFooter()
            doc.finishPage(page)
            pageNum++
            page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
            canvas = page.canvas
            y = margin
        }

        fun ensureSpace(needed: Float) {
            if (y + needed > pageHeight - margin - 20f) {
                newPage()
            }
        }

        // Formats Markdown bold (**word**) into SpannableStringBuilder locally
        fun parseSpannable(rawText: String): CharSequence {
            val sb = SpannableStringBuilder()
            var i = 0
            val len = rawText.length
            while (i < len) {
                val boldStart = rawText.indexOf("**", i)
                if (boldStart != -1) {
                    val boldEnd = rawText.indexOf("**", boldStart + 2)
                    if (boldEnd != -1) {
                        // Append text before bold
                        sb.append(rawText.substring(i, boldStart))
                        val spanStart = sb.length
                        val boldWord = rawText.substring(boldStart + 2, boldEnd)
                        sb.append(boldWord)
                        sb.setSpan(StyleSpan(Typeface.BOLD), spanStart, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                        sb.setSpan(ForegroundColorSpan(COLOR_TEXT_BOLD), spanStart, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                        i = boldEnd + 2
                        continue
                    }
                }
                sb.append(rawText.substring(i))
                break
            }
            return sb
        }

        fun drawLayout(text: CharSequence, tp: TextPaint, spacingAfter: Float = 8f) {
            if (text.isBlank()) return
            val layout = StaticLayout.Builder.obtain(text, 0, text.length, tp, contentWidth)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(2f, 1.25f)
                .setIncludePad(false)
                .setTextDirection(if (rtl) TextDirectionHeuristics.FIRSTSTRONG_RTL else TextDirectionHeuristics.FIRSTSTRONG_LTR)
                .build()

            ensureSpace(layout.height + spacingAfter)
            canvas.save()
            canvas.translate(margin, y)
            layout.draw(canvas)
            canvas.restore()
            y += layout.height + spacingAfter
        }

        // Draw an elegant, styled Section Header (## Heading)
        fun drawSectionHeader(headingText: String) {
            val clean = headingText.replace("**", "").trim()
            val textLayout = StaticLayout.Builder.obtain(clean, 0, clean.length, h1Paint, contentWidth - 28)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setTextDirection(if (rtl) TextDirectionHeuristics.FIRSTSTRONG_RTL else TextDirectionHeuristics.FIRSTSTRONG_LTR)
                .build()

            val cardH = textLayout.height + 14f
            ensureSpace(cardH + 14f)

            // Background pill
            val cardRect = RectF(margin, y, margin + contentWidth, y + cardH)
            bgPaint.style = Paint.Style.FILL
            bgPaint.color = COLOR_PRIMARY_LIGHT
            canvas.drawRoundRect(cardRect, 8f, 8f, bgPaint)

            borderPaint.color = COLOR_PRIMARY_BORDER
            borderPaint.strokeWidth = 1f
            canvas.drawRoundRect(cardRect, 8f, 8f, borderPaint)

            // Right accent strip
            bgPaint.color = COLOR_ACCENT
            val stripW = 4f
            val stripRect = if (rtl) {
                RectF(margin + contentWidth - stripW, y, margin + contentWidth, y + cardH)
            } else {
                RectF(margin, y, margin + stripW, y + cardH)
            }
            canvas.drawRoundRect(stripRect, 4f, 4f, bgPaint)

            // Text
            canvas.save()
            val textX = if (rtl) margin + 10f else margin + 14f
            canvas.translate(textX, y + 7f)
            textLayout.draw(canvas)
            canvas.restore()

            y += cardH + 10f
        }

        // Draw Subheading (### Subheading)
        fun drawSubHeader(subText: String) {
            val clean = subText.replace("**", "").trim()
            val text = "▪ $clean"
            drawLayout(text, h2Paint, 6f)
        }

        // Draw Bullet point with colored symbol
        fun drawBullet(bulletText: String) {
            val clean = bulletText.trim()
            val charSeq = parseSpannable(clean)
            val fullText = SpannableStringBuilder("• ").apply {
                setSpan(ForegroundColorSpan(COLOR_ACCENT), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                setSpan(StyleSpan(Typeface.BOLD), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                append(charSeq)
            }
            drawLayout(fullText, bodyPaint, 5f)
        }

        // Draw Table with colored header and clean borders
        fun drawTable(rows: List<List<String>>) {
            if (rows.isEmpty()) return
            val cols = rows.maxOf { it.size }.coerceAtLeast(1)
            val colW = contentWidth.toFloat() / cols
            val pad = 5f

            for ((rowIdx, row) in rows.withIndex()) {
                val isHeader = (rowIdx == 0)
                var rowH = 18f
                val layouts = mutableListOf<StaticLayout>()
                val tp = if (isHeader) cellBoldPaint else cellPaint

                for (c in 0 until cols) {
                    val rawCell = row.getOrElse(c) { "" }.trim()
                    val cellContent = parseSpannable(rawCell)
                    val cellW = (colW - pad * 2).toInt().coerceAtLeast(20)
                    val lay = StaticLayout.Builder.obtain(cellContent, 0, cellContent.length, tp, cellW)
                        .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                        .setTextDirection(if (rtl) TextDirectionHeuristics.FIRSTSTRONG_RTL else TextDirectionHeuristics.FIRSTSTRONG_LTR)
                        .setIncludePad(false)
                        .build()
                    layouts += lay
                    rowH = maxOf(rowH, lay.height + pad * 2)
                }

                ensureSpace(rowH + 2f)

                // Background
                bgPaint.style = Paint.Style.FILL
                bgPaint.color = when {
                    isHeader -> COLOR_TABLE_HEADER
                    rowIdx % 2 == 1 -> COLOR_TABLE_ALT
                    else -> Color.WHITE
                }
                canvas.drawRect(margin, y, margin + contentWidth, y + rowH, bgPaint)

                // Cell content
                for (c in 0 until cols) {
                    val x = if (rtl) margin + (cols - 1 - c) * colW else margin + c * colW
                    canvas.save()
                    canvas.translate(x + pad, y + pad)
                    layouts[c].draw(canvas)
                    canvas.restore()

                    // Vertical border line
                    if (c > 0) {
                        canvas.drawLine(x, y, x, y + rowH, borderPaint)
                    }
                }

                // Row borders
                borderPaint.color = COLOR_BORDER
                canvas.drawLine(margin, y, margin + contentWidth, y, borderPaint)
                canvas.drawLine(margin, y + rowH, margin + contentWidth, y + rowH, borderPaint)

                y += rowH
            }
            y += 12f
        }

        // Top Banner / Header Card on Page 1
        if (title.isNotBlank()) {
            val mainTitle = title.substringBefore('\n').trim()
            val subTitle = title.substringAfter('\n', "").trim()

            val bannerH = 56f
            val bannerRect = RectF(margin, y, margin + contentWidth, y + bannerH)

            // Gradient / Solid Teal Banner
            bgPaint.style = Paint.Style.FILL
            bgPaint.color = COLOR_PRIMARY
            canvas.drawRoundRect(bannerRect, 10f, 10f, bgPaint)

            val titleTextPaint = paint(14f, true, Color.WHITE)
            val subTextPaint = paint(9f, false, 0xFFCCFBF1.toInt())

            val titleLayout = StaticLayout.Builder.obtain(mainTitle, 0, mainTitle.length, titleTextPaint, contentWidth - 24)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setTextDirection(if (rtl) TextDirectionHeuristics.FIRSTSTRONG_RTL else TextDirectionHeuristics.FIRSTSTRONG_LTR)
                .build()

            canvas.save()
            canvas.translate(margin + 12f, y + 10f)
            titleLayout.draw(canvas)
            canvas.restore()

            if (subTitle.isNotBlank()) {
                val subLayout = StaticLayout.Builder.obtain(subTitle, 0, subTitle.length, subTextPaint, contentWidth - 24)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setTextDirection(if (rtl) TextDirectionHeuristics.FIRSTSTRONG_RTL else TextDirectionHeuristics.FIRSTSTRONG_LTR)
                    .build()
                canvas.save()
                canvas.translate(margin + 12f, y + 32f)
                subLayout.draw(canvas)
                canvas.restore()
            }

            y += bannerH + 16f
        }

        val lines = markdown.replace("\r\n", "\n").split("\n")
        val para = StringBuilder()
        val tableBuf = mutableListOf<List<String>>()

        fun flushPara() {
            val t = para.toString().trim()
            if (t.isNotEmpty()) {
                drawLayout(parseSpannable(t), bodyPaint, 8f)
            }
            para.clear()
        }

        fun flushTable() {
            if (tableBuf.isNotEmpty()) {
                drawTable(tableBuf.toList())
                tableBuf.clear()
            }
        }

        fun isTableRow(s: String): Boolean {
            val t = s.trim()
            return t.startsWith("|") && t.indexOf('|', startIndex = 1) >= 0
        }

        fun isTableSep(s: String): Boolean =
            s.trim().matches(Regex("^\\|?[\\s:-]+\\|([\\s:-]+\\|)*[\\s:-]*\\|?$"))

        fun parseRow(s: String): List<String> =
            s.trim().trim('|').split("|").map { it.trim() }

        for (raw in lines) {
            val line = raw.trimEnd()
            val t = line.trim()

            if (isTableRow(t)) {
                if (!isTableSep(t)) {
                    flushPara()
                    tableBuf += parseRow(t)
                }
                continue
            }

            // Not a table line, flush pending table
            if (tableBuf.isNotEmpty()) {
                flushTable()
            }

            when {
                t.isEmpty() -> flushPara()
                t.startsWith("### ") -> {
                    flushPara()
                    drawSubHeader(t.removePrefix("### "))
                }
                t.startsWith("## ") -> {
                    flushPara()
                    drawSectionHeader(t.removePrefix("## "))
                }
                t.startsWith("# ") -> {
                    flushPara()
                    drawSectionHeader(t.removePrefix("# "))
                }
                t.startsWith("- ") || t.startsWith("* ") -> {
                    flushPara()
                    drawBullet(t.drop(2))
                }
                t.matches(Regex("^\\d+[.)]\\s+.+")) -> {
                    flushPara()
                    drawBullet(t)
                }
                t.startsWith("---") -> {
                    flushPara()
                    ensureSpace(16f)
                    borderPaint.color = COLOR_BORDER
                    canvas.drawLine(margin, y + 4f, margin + contentWidth, y + 4f, borderPaint)
                    y += 12f
                }
                else -> {
                    if (para.isNotEmpty()) para.append(' ')
                    para.append(t)
                }
            }
        }
        flushPara()
        flushTable()

        drawPageFooter()
        doc.finishPage(page)
        FileOutputStream(outFile).use { doc.writeTo(it) }
        doc.close()
        return outFile
    }
}
