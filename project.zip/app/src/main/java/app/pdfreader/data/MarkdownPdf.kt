package app.pdfreader.data

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.io.File
import java.io.FileOutputStream

/** Lightweight Markdown to PDF (local). Headings, bullets, numbered lists, paragraphs; RTL optional. */
object MarkdownPdf {

    fun render(markdown: String, outFile: File, title: String = "", rtl: Boolean = true): File {
        outFile.parentFile?.mkdirs()
        val doc = PdfDocument()
        val pageWidth = 595 // A4-ish points
        val pageHeight = 842
        val margin = 48f
        val contentWidth = (pageWidth - margin * 2).toInt()

        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            color = 0xFF111111.toInt()
        }
        val h1 = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            color = 0xFF111111.toInt()
        }
        val h2 = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 14f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            color = 0xFF222222.toInt()
        }
        val body = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 11.5f
            color = 0xFF222222.toInt()
        }
        val meta = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 9f
            color = 0xFF666666.toInt()
        }

        var pageNum = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
        var canvas = page.canvas
        var y = margin

        fun newPage() {
            doc.finishPage(page)
            pageNum++
            page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
            canvas = page.canvas
            y = margin
        }

        fun ensureSpace(needed: Float) {
            if (y + needed > pageHeight - margin) newPage()
        }

        fun drawLayout(text: String, paint: TextPaint, spacingAfter: Float = 10f) {
            val clean = stripMd(text)
            if (clean.isBlank()) return
            val align = if (rtl) Layout.Alignment.ALIGN_OPPOSITE else Layout.Alignment.ALIGN_NORMAL
            val layout = StaticLayout.Builder.obtain(clean, 0, clean.length, paint, contentWidth)
                .setAlignment(align)
                .setLineSpacing(0f, 1.25f)
                .setIncludePad(false)
                .build()
            ensureSpace(layout.height + spacingAfter)
            canvas.save()
            canvas.translate(margin, y)
            layout.draw(canvas)
            canvas.restore()
            y += layout.height + spacingAfter
        }

        if (title.isNotBlank()) {
            drawLayout(title, titlePaint, 6f)
            drawLayout("جزوهٔ مرور · ساخته‌شده روی دستگاه", meta, 16f)
        }

        val lines = markdown.replace("\r\n", "\n").split("\n")
        val para = StringBuilder()
        fun flushPara() {
            val t = para.toString().trim()
            if (t.isNotEmpty()) drawLayout(t, body, 12f)
            para.clear()
        }

        for (raw in lines) {
            val line = raw.trimEnd()
            val t = line.trim()
            when {
                t.isEmpty() -> flushPara()
                t.startsWith("### ") -> {
                    flushPara()
                    drawLayout(t.removePrefix("### ").trim(), h2, 8f)
                }
                t.startsWith("## ") -> {
                    flushPara()
                    drawLayout(t.removePrefix("## ").trim(), h1, 10f)
                }
                t.startsWith("# ") -> {
                    flushPara()
                    drawLayout(t.removePrefix("# ").trim(), titlePaint, 12f)
                }
                t.startsWith("- ") || t.startsWith("* ") -> {
                    flushPara()
                    drawLayout("• " + t.drop(2).trim(), body, 6f)
                }
                t.matches(Regex("^\\d+[.)]\\s+.+")) -> {
                    flushPara()
                    drawLayout(t, body, 6f)
                }
                t.startsWith("---") -> {
                    flushPara()
                    y += 8f
                }
                else -> {
                    if (para.isNotEmpty()) para.append(' ')
                    para.append(t)
                }
            }
        }
        flushPara()

        // footer page numbers
        doc.finishPage(page)
        FileOutputStream(outFile).use { doc.writeTo(it) }
        doc.close()
        return outFile
    }

    private fun stripMd(s: String): String =
        s.replace(Regex("\\*\\*([^*]+)\\*\\*"), "$1")
            .replace(Regex("\\*([^*]+)\\*"), "$1")
            .replace(Regex("`([^`]+)`"), "$1")
            .trim()
}
