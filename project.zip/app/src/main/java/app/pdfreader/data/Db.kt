package app.pdfreader.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "documents")
data class DocumentEntity(
    @PrimaryKey val uri: String,
    val name: String,
    val pageCount: Int,
    val lastPage: Int = 0,
    val lastOffset: Int = 0,
    val favorite: Boolean = false,
    val lastOpened: Long,
)

@Dao
interface DocumentDao {
    @Query("SELECT * FROM documents ORDER BY lastOpened DESC")
    fun observeAll(): Flow<List<DocumentEntity>>

    @Query("SELECT * FROM documents WHERE uri = :uri")
    suspend fun get(uri: String): DocumentEntity?

    @Upsert
    suspend fun upsert(doc: DocumentEntity)

    @Query("UPDATE documents SET lastPage = :page, lastOffset = :offset WHERE uri = :uri")
    suspend fun updateProgress(uri: String, page: Int, offset: Int)

    @Query("UPDATE documents SET favorite = :fav WHERE uri = :uri")
    suspend fun setFavorite(uri: String, fav: Boolean)

    @Query("DELETE FROM documents WHERE uri = :uri")
    suspend fun delete(uri: String)
}

@Database(entities = [DocumentEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun documentDao(): DocumentDao
}
