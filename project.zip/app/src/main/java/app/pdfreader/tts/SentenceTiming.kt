package app.pdfreader.tts

import app.pdfreader.ai.Pause

/**
 * Works out when each sentence of a chunk starts inside its audio.
 *
 * A plain "characters so far / total characters" estimate drifts by several sentences in a long chunk
 * (numbers, abbreviations and pauses are not proportional to length). Instead the real pauses of the audio
 * are used: for every sentence boundary the pause that is longest and closest to the estimated position wins.
 * When the audio has no usable pauses the estimate itself is used, so the result is never worse than before.
 */
object SentenceTiming {
    fun align(lens: IntArray, durationMs: Long, pauses: List<Pause>): LongArray {
        val n = lens.size
        val starts = LongArray(n)
        if (n <= 1 || durationMs <= 0) return starts
        val weights = DoubleArray(n) { lens[it] + 12.0 }
        val total = weights.sum()
        val window = maxOf(1_500L, durationMs * 15 / 100)
        var acc = 0.0
        var lastCenter = -1L
        for (k in 1 until n) {
            acc += weights[k - 1]
            val expected = (durationMs * acc / total).toLong()
            var best: Pause? = null
            var bestScore = Double.NEGATIVE_INFINITY
            for (p in pauses) {
                if (p.centerMs <= lastCenter) continue
                val dev = kotlin.math.abs(p.centerMs - expected)
                if (dev > window) continue
                val score = p.lengthMs - 0.12 * dev
                if (score > bestScore) { bestScore = score; best = p }
            }
            val t = if (best != null) { lastCenter = best.centerMs; best.centerMs } else expected
            val minSentenceMs = minOf(3000L, (lens[k - 1] * 45L).coerceAtLeast(800L))
            starts[k] = maxOf(t, starts[k - 1] + minSentenceMs).coerceAtMost(durationMs - 200L)
        }
        return starts
    }
}
