package app.pdfreader.tts

import app.pdfreader.ui.TextPick

import android.content.Context
import android.graphics.RectF
import android.net.Uri
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** A rectangle in page coordinates normalized to 0..1, origin at the top-left corner. */
class NRect(val l: Float, val t: Float, val r: Float, val b: Float)

/** The text layer of one page: the text, and the box of every character (null for characters without a box). */
class PageChars(val text: String, val boxes: Array<NRect?>)

/** Where every spoken sentence sits on the page: its line rectangles and its character range in the page text. */
class SentenceMap(val rects: List<List<NRect>>, val ranges: List<IntRange?>)

/**
 * Finds where spoken sentences sit on the PDF page, using the real text layer through PDFium.
 *
 * The PDFium wrapper is called by reflection on purpose: if a method is named differently in some version,
 * highlighting simply switches off (the reason is kept in [lastError]) and nothing else in the app is affected.
 * Scanned PDFs have no text layer, so there is nothing to highlight there.
 */
class PdfiumTextEngine(private val context: Context) {
    private val lock = Any()
    private var core: Any? = null
    private var coreFailed = false
    private var openUri: String? = null
    private var openDoc: Any? = null
    private var openPfd: ParcelFileDescriptor? = null

    @Volatile var lastError: String? = null
        private set

    /** One list of rectangles per sentence (empty when that sentence was not found), or null if unavailable. */
    suspend fun mapSentences(uri: String, pageIndex: Int, sentences: List<String>): SentenceMap? =
        withContext(Dispatchers.IO) {
            synchronized(lock) {
                try {
                    lastError = null
                    mapLocked(uri, pageIndex, sentences)
                } catch (e: Throwable) {
                    lastError = (e.cause ?: e).let { it.javaClass.simpleName + ": " + (it.message ?: "") }.take(140)
                    null
                }
            }
        }

    /** Only the text of the page's text layer (fast, no positions); null when the layer cannot be read. */
    suspend fun pageText(uri: String, pageIndex: Int): String? =
        withContext(Dispatchers.IO) {
            synchronized(lock) {
                try {
                    textLocked(uri, pageIndex)
                } catch (e: Throwable) {
                    lastError = (e.cause ?: e).let { it.javaClass.simpleName + ": " + (it.message ?: "") }.take(140)
                    null
                }
            }
        }

    private fun textLocked(uri: String, pageIndex: Int): String? {
        val doc = documentFor(uri) ?: return null
        val page = doc.call("openPage", pageIndex) ?: return null
        try {
            val tp = page.call("openTextPage") ?: return null
            try {
                val count = (tp.call("textPageCountChars") as? Number)?.toInt() ?: return null
                if (count < 1) return ""
                return tp.call("textPageGetText", 0, count) as? String
            } finally {
                close(tp)
            }
        } finally {
            close(page)
        }
    }

    private val charCache = LinkedHashMap<String, PageChars>() // used under [lock] only

    /** Every character of the page with its position (cached for a few pages); used for selection and word highlight. */
    suspend fun pageChars(uri: String, pageIndex: Int): PageChars? =
        withContext(Dispatchers.IO) {
            synchronized(lock) {
                try {
                    lastError = null
                    charsCachedLocked(uri, pageIndex)
                } catch (e: Throwable) {
                    lastError = (e.cause ?: e).let { it.javaClass.simpleName + ": " + (it.message ?: "") }.take(140)
                    null
                }
            }
        }

    fun release() = synchronized(lock) { closeDocument() }

    private fun charsCachedLocked(uri: String, pageIndex: Int): PageChars? {
        val key = "$uri#$pageIndex"
        charCache[key]?.let { return it }
        val pc = charsLocked(uri, pageIndex) ?: return null
        charCache[key] = pc
        while (charCache.size > 8) charCache.remove(charCache.keys.first())
        return pc
    }

    private fun charsLocked(uri: String, pageIndex: Int): PageChars? {
        val doc = documentFor(uri) ?: return null
        val page = doc.call("openPage", pageIndex)
        if (page == null) { lastError = "صفحه باز نشد"; return null }
        try {
            val w = (page.call("getPageWidthPoint") as? Number)?.toFloat() ?: return null
            val h = (page.call("getPageHeightPoint") as? Number)?.toFloat() ?: return null
            if (w <= 0f || h <= 0f) return null
            val tp = page.call("openTextPage")
            if (tp == null) { lastError = "لایه‌ی متنی باز نشد"; return null }
            try {
                val count = (tp.call("textPageCountChars") as? Number)?.toInt() ?: return null
                if (count < 1) { lastError = "این PDF لایه‌ی متنی ندارد (اسکن‌شده)؛ انتخاب متن ممکن نیست"; return null }
                // Built character by character: getText() may skip or merge characters, which shifted every later
                // index (highlights and selections landed several characters off, more and more towards the page end).
                val sb = StringBuilder(count)
                var perChar = true
                for (i in 0 until count) {
                    val u = try { tp.call("textPageGetUnicode", i) as? Char } catch (e: NoSuchMethodException) { null }
                    if (u == null) { perChar = false; break }
                    sb.append(u)
                }
                val full = if (perChar) sb.toString() else (tp.call("textPageGetText", 0, count) as? String ?: return null)
                val boxes = arrayOfNulls<NRect>(count)
                for (i in 0 until count) {
                    val n = (tp.call("textPageCountRects", i, 1) as? Number)?.toInt() ?: 0
                    if (n > 0) {
                        val r = tp.call("textPageGetRect", 0) as? RectF
                        if (r != null) boxes[i] = toNRect(r, w, h)
                    }
                }
                return PageChars(full, boxes)
            } finally {
                close(tp)
            }
        } finally {
            close(page)
        }
    }

    private fun toNRect(r: RectF, w: Float, h: Float): NRect {
        val pdfCoords = r.top > r.bottom // PDF space has its origin at the bottom-left
        val topY = if (pdfCoords) 1f - r.top / h else r.top / h
        val bottomY = if (pdfCoords) 1f - r.bottom / h else r.bottom / h
        val left = minOf(r.left, r.right) / w
        val right = maxOf(r.left, r.right) / w
        return NRect(
            left.coerceIn(0f, 1f), minOf(topY, bottomY).coerceIn(0f, 1f),
            right.coerceIn(0f, 1f), maxOf(topY, bottomY).coerceIn(0f, 1f),
        )
    }

    // ------------------------------------------------------------------ mapping

    private fun mapLocked(uri: String, pageIndex: Int, sentences: List<String>): SentenceMap? {
        val pc = charsCachedLocked(uri, pageIndex) ?: return null
        if (pc.text.length < 20) { lastError = "این PDF لایه‌ی متنی ندارد (اسکن‌شده)"; return null }
        val norm = normalize(pc.text)
        var cursor = 0
        val rects = ArrayList<List<NRect>>(sentences.size)
        val ranges = ArrayList<IntRange?>(sentences.size)
        for (sentence in sentences) {
            val needle = normalize(sentence).s
            // normally the sentences follow the page order; when the cleaned text was re-ordered, search the whole page
            val range = locate(norm.s, needle, cursor) ?: locate(norm.s, needle, 0)
            if (range == null || range.second <= range.first) {
                rects += emptyList<NRect>()
                ranges += null
                continue
            }
            if (range.first >= cursor) cursor = range.second
            val start = norm.map[range.first]
            val endIncl = norm.map[range.second - 1]
            rects += TextPick.rects(pc, start, endIncl)
            ranges += start..endIncl
        }
        return SentenceMap(rects, ranges)
    }

    /** Finds [needle] in [hay] at or after [from]; falls back to matching its beginning (and end). */
    private fun locate(hay: String, needle: String, from: Int): Pair<Int, Int>? {
        if (needle.length < 6) return null
        val exact = hay.indexOf(needle, from)
        if (exact >= 0) return exact to exact + needle.length
        if (needle.length < 24) return null
        val k = minOf(20, needle.length / 2)
        val head = hay.indexOf(needle.substring(0, k), from)
        if (head < 0) return null
        val tail = hay.indexOf(needle.substring(needle.length - k), head + k)
        if (tail >= 0 && tail + k - head <= needle.length * 1.6) return head to tail + k
        // the middle differs (re-worded join, dropped caption): the start is still right, the length is estimated
        return head to minOf(hay.length, head + needle.length)
    }

    private fun rectsFor(tp: Any, start: Int, endExclusive: Int, w: Float, h: Float): List<NRect> {
        val n = (tp.call("textPageCountRects", start, endExclusive - start) as? Number)?.toInt() ?: return emptyList()
        val out = ArrayList<NRect>(n)
        for (i in 0 until n) {
            val r = tp.call("textPageGetRect", i) as? RectF ?: continue
            out += toNRect(r, w, h)
        }
        return out
    }

    // ------------------------------------------------------------------ text normalization

    private class Norm(val s: String, val map: IntArray)

    private fun normalize(text: String): Norm {
        val sb = StringBuilder(text.length)
        val idx = ArrayList<Int>(text.length)
        text.forEachIndexed { i, ch ->
            val expanded = when (ch) {
                '\uFB01' -> "fi"
                '\uFB02' -> "fl"
                '\uFB00' -> "ff"
                '\uFB03' -> "ffi"
                '\uFB04' -> "ffl"
                else -> null
            }
            if (expanded != null) {
                for (e in expanded) { sb.append(e); idx.add(i) }
            } else if (ch.isLetterOrDigit()) {
                sb.append(ch.lowercaseChar())
                idx.add(i)
            }
        }
        return Norm(sb.toString(), idx.toIntArray())
    }

    // ------------------------------------------------------------------ PDFium access (reflection)

    private fun documentFor(uri: String): Any? {
        if (openUri == uri && openDoc != null) return openDoc
        closeDocument()
        val c = core() ?: return null
        val pfd = context.contentResolver.openFileDescriptor(Uri.parse(uri), "r")
        if (pfd == null) { lastError = "فایل باز نشد"; return null }
        val doc = try {
            c.call("newDocument", pfd)
        } catch (e: Throwable) {
            try { pfd.close() } catch (ignored: Throwable) { }
            throw e
        }
        openPfd = pfd
        openDoc = doc
        openUri = uri
        return doc
    }

    private fun closeDocument() {
        close(openDoc)
        try { openPfd?.close() } catch (e: Throwable) { /* ignore */ }
        openDoc = null
        openPfd = null
        openUri = null
    }

    private fun core(): Any? {
        core?.let { return it }
        if (coreFailed) return null
        try {
            val cls = Class.forName("io.legere.pdfiumandroid.PdfiumCore")
            val inst: Any = try {
                cls.getConstructor(Context::class.java).newInstance(context)
            } catch (e: Throwable) {
                try {
                    cls.getConstructor().newInstance()
                } catch (e2: Throwable) {
                    // Kotlin "default argument" constructor: (Context, Config, int mask, DefaultConstructorMarker)
                    val ctor = cls.declaredConstructors.first { it.parameterTypes.firstOrNull() == Context::class.java }
                    ctor.isAccessible = true
                    val n = ctor.parameterTypes.size
                    val args = arrayOfNulls<Any>(n)
                    args[0] = context
                    if (n >= 3 && ctor.parameterTypes[n - 2] == Int::class.javaPrimitiveType) {
                        args[n - 2] = ((1 shl (n - 2)) - 1) and 1.inv()
                    }
                    ctor.newInstance(*args)
                }
            }
            core = inst
            return inst
        } catch (e: Throwable) {
            coreFailed = true
            lastError = "PDFium آماده نشد: " + (e.cause ?: e).javaClass.simpleName
            return null
        }
    }

    private fun close(o: Any?) {
        try { (o as? AutoCloseable)?.close() } catch (e: Throwable) { /* ignore */ }
    }

    private val methodCache = HashMap<String, List<java.lang.reflect.Method>>() // used under [lock] only

    /** Calls a public method by name and argument count; Kotlin properties show up here as getX() methods too. */
    private fun Any.call(name: String, vararg args: Any?): Any? {
        val key = javaClass.name + "#" + name + "#" + args.size
        val candidates = methodCache.getOrPut(key) { javaClass.methods.filter { it.name == name && it.parameterTypes.size == args.size } }
        val m = candidates.firstOrNull { argsFit(it.parameterTypes, args) }
            ?: throw NoSuchMethodException("${javaClass.simpleName}.$name/${args.size}")
        return m.invoke(this, *args)
    }

    private fun argsFit(types: Array<Class<*>>, args: Array<out Any?>): Boolean = types.indices.all { i ->
        val a = args[i]
        val t = types[i]
        when {
            a == null -> !t.isPrimitive
            else -> (if (t.isPrimitive) t.kotlin.javaObjectType else t).isInstance(a)
        }
    }
}
