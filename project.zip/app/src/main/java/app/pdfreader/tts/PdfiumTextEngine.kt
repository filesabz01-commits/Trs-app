package app.pdfreader.tts

import android.content.Context
import android.graphics.RectF
import android.net.Uri
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** A rectangle in page coordinates normalized to 0..1, origin at the top-left corner. */
class NRect(val l: Float, val t: Float, val r: Float, val b: Float)

/**
 * Finds where spoken sentences sit on the PDF page, using the real text layer through PDFium.
 *
 * The PDFium wrapper is called by reflection on purpose: if a method is named differently in some version,
 * highlighting simply switches off (the reason is kept in [lastError]) and nothing else in the app is affected.
 * Scanned PDFs have no text layer, so there is nothing to highlight there.
 */
class PdfiumTextEngine(private val context: Context) {
    private val lock = Any()
    private var core: Any? = null
    private var coreFailed = false
    private var openUri: String? = null
    private var openDoc: Any? = null
    private var openPfd: ParcelFileDescriptor? = null

    @Volatile var lastError: String? = null
        private set

    /** One list of rectangles per sentence (empty when that sentence was not found), or null if unavailable. */
    suspend fun mapSentences(uri: String, pageIndex: Int, sentences: List<String>): List<List<NRect>>? =
        withContext(Dispatchers.IO) {
            synchronized(lock) {
                try {
                    lastError = null
                    mapLocked(uri, pageIndex, sentences)
                } catch (e: Throwable) {
                    lastError = (e.cause ?: e).let { it.javaClass.simpleName + ": " + (it.message ?: "") }.take(140)
                    null
                }
            }
        }

    fun release() = synchronized(lock) { closeDocument() }

    // ------------------------------------------------------------------ mapping

    private fun mapLocked(uri: String, pageIndex: Int, sentences: List<String>): List<List<NRect>>? {
        val doc = documentFor(uri) ?: return null
        val page = doc.call("openPage", pageIndex)
        if (page == null) { lastError = "صفحه باز نشد"; return null }
        try {
            val w = (page.call("getPageWidthPoint") as? Number)?.toFloat() ?: return null
            val h = (page.call("getPageHeightPoint") as? Number)?.toFloat() ?: return null
            if (w <= 0f || h <= 0f) return null
            val tp = page.call("openTextPage")
            if (tp == null) { lastError = "لایه‌ی متنی باز نشد"; return null }
            try {
                val count = (tp.call("textPageCountChars") as? Number)?.toInt() ?: return null
                if (count < 20) { lastError = "این PDF لایه‌ی متنی ندارد (اسکن‌شده)"; return null }
                val full = tp.call("textPageGetText", 0, count) as? String ?: return null
                val norm = normalize(full)
                var cursor = 0
                val out = ArrayList<List<NRect>>(sentences.size)
                for (sentence in sentences) {
                    val range = locate(norm.s, normalize(sentence).s, cursor)
                    if (range == null) {
                        out += emptyList<NRect>()
                        continue
                    }
                    cursor = range.second
                    val start = norm.map[range.first]
                    val endExclusive = norm.map[range.second - 1] + 1
                    out += rectsFor(tp, start, endExclusive, w, h)
                }
                return out
            } finally {
                close(tp)
            }
        } finally {
            close(page)
        }
    }

    /** Finds [needle] in [hay] at or after [from]; falls back to matching its beginning and end. */
    private fun locate(hay: String, needle: String, from: Int): Pair<Int, Int>? {
        if (needle.length < 6) return null
        val exact = hay.indexOf(needle, from)
        if (exact >= 0) return exact to exact + needle.length
        if (needle.length < 40) return null
        val k = 20
        val head = hay.indexOf(needle.substring(0, k), from)
        if (head < 0) return null
        val tail = hay.indexOf(needle.substring(needle.length - k), head + k)
        if (tail < 0) return null
        val end = tail + k
        return if (end - head <= needle.length * 1.6) head to end else null
    }

    private fun rectsFor(tp: Any, start: Int, endExclusive: Int, w: Float, h: Float): List<NRect> {
        val n = (tp.call("textPageCountRects", start, endExclusive - start) as? Number)?.toInt() ?: return emptyList()
        val out = ArrayList<NRect>(n)
        for (i in 0 until n) {
            val r = tp.call("textPageGetRect", i) as? RectF ?: continue
            val pdfCoords = r.top > r.bottom // PDF space has its origin at the bottom-left
            val topY = if (pdfCoords) 1f - r.top / h else r.top / h
            val bottomY = if (pdfCoords) 1f - r.bottom / h else r.bottom / h
            val left = minOf(r.left, r.right) / w
            val right = maxOf(r.left, r.right) / w
            out += NRect(
                left.coerceIn(0f, 1f), minOf(topY, bottomY).coerceIn(0f, 1f),
                right.coerceIn(0f, 1f), maxOf(topY, bottomY).coerceIn(0f, 1f),
            )
        }
        return out
    }

    // ------------------------------------------------------------------ text normalization

    private class Norm(val s: String, val map: IntArray)

    private fun normalize(text: String): Norm {
        val sb = StringBuilder(text.length)
        val idx = ArrayList<Int>(text.length)
        text.forEachIndexed { i, ch ->
            val expanded = when (ch) {
                '\uFB01' -> "fi"
                '\uFB02' -> "fl"
                '\uFB00' -> "ff"
                '\uFB03' -> "ffi"
                '\uFB04' -> "ffl"
                else -> null
            }
            if (expanded != null) {
                for (e in expanded) { sb.append(e); idx.add(i) }
            } else if (ch.isLetterOrDigit()) {
                sb.append(ch.lowercaseChar())
                idx.add(i)
            }
        }
        return Norm(sb.toString(), idx.toIntArray())
    }

    // ------------------------------------------------------------------ PDFium access (reflection)

    private fun documentFor(uri: String): Any? {
        if (openUri == uri && openDoc != null) return openDoc
        closeDocument()
        val c = core() ?: return null
        val pfd = context.contentResolver.openFileDescriptor(Uri.parse(uri), "r")
        if (pfd == null) { lastError = "فایل باز نشد"; return null }
        val doc = try {
            c.call("newDocument", pfd)
        } catch (e: Throwable) {
            try { pfd.close() } catch (ignored: Throwable) { }
            throw e
        }
        openPfd = pfd
        openDoc = doc
        openUri = uri
        return doc
    }

    private fun closeDocument() {
        close(openDoc)
        try { openPfd?.close() } catch (e: Throwable) { /* ignore */ }
        openDoc = null
        openPfd = null
        openUri = null
    }

    private fun core(): Any? {
        core?.let { return it }
        if (coreFailed) return null
        try {
            val cls = Class.forName("io.legere.pdfiumandroid.PdfiumCore")
            val inst: Any = try {
                cls.getConstructor(Context::class.java).newInstance(context)
            } catch (e: Throwable) {
                try {
                    cls.getConstructor().newInstance()
                } catch (e2: Throwable) {
                    // Kotlin "default argument" constructor: (Context, Config, int mask, DefaultConstructorMarker)
                    val ctor = cls.declaredConstructors.first { it.parameterTypes.firstOrNull() == Context::class.java }
                    ctor.isAccessible = true
                    val n = ctor.parameterTypes.size
                    val args = arrayOfNulls<Any>(n)
                    args[0] = context
                    if (n >= 3 && ctor.parameterTypes[n - 2] == Int::class.javaPrimitiveType) {
                        args[n - 2] = ((1 shl (n - 2)) - 1) and 1.inv()
                    }
                    ctor.newInstance(*args)
                }
            }
            core = inst
            return inst
        } catch (e: Throwable) {
            coreFailed = true
            lastError = "PDFium آماده نشد: " + (e.cause ?: e).javaClass.simpleName
            return null
        }
    }

    private fun close(o: Any?) {
        try { (o as? AutoCloseable)?.close() } catch (e: Throwable) { /* ignore */ }
    }

    /** Calls a public method by name and argument count; Kotlin properties show up here as getX() methods too. */
    private fun Any.call(name: String, vararg args: Any?): Any? {
        val m = javaClass.methods.firstOrNull { it.name == name && it.parameterTypes.size == args.size && argsFit(it.parameterTypes, args) }
            ?: throw NoSuchMethodException("${javaClass.simpleName}.$name/${args.size}")
        return m.invoke(this, *args)
    }

    private fun argsFit(types: Array<Class<*>>, args: Array<out Any?>): Boolean = types.indices.all { i ->
        val a = args[i]
        val t = types[i]
        when {
            a == null -> !t.isPrimitive
            else -> (if (t.isPrimitive) t.kotlin.javaObjectType else t).isInstance(a)
        }
    }
}
