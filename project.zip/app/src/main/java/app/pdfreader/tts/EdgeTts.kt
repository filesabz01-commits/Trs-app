package app.pdfreader.tts

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Online Microsoft Edge neural TTS (same engine as edge-tts).
 * No API key. Persian voices: fa-IR-DilaraNeural / fa-IR-FaridNeural.
 */
object EdgeTts {
    private const val TOKEN = "6A5AA1D4EAFF4E9FB37E23D68491D6F4"
    private const val EDGE_COPYRIGHT = "Copyright (C) Microsoft Corporation. All rights reserved."
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    /** Voices shown in settings (gender preference for auto language pick). */
    val persianVoices = listOf(
        "fa-IR-DilaraNeural" to "دلارا (زن) — ترجیح صدای زن",
        "fa-IR-FaridNeural" to "فرید (مرد) — ترجیح صدای مرد",
    )

    private data class PairVoice(val female: String, val male: String)

    /** Edge neural voices per ISO language code used in the app. */
    private val byLang = mapOf(
        "fa" to PairVoice("fa-IR-DilaraNeural", "fa-IR-FaridNeural"),
        "en" to PairVoice("en-US-JennyNeural", "en-US-GuyNeural"),
        "ar" to PairVoice("ar-SA-ZariyahNeural", "ar-SA-HamedNeural"),
        "de" to PairVoice("de-DE-KatjaNeural", "de-DE-ConradNeural"),
        "fr" to PairVoice("fr-FR-DeniseNeural", "fr-FR-HenriNeural"),
        "tr" to PairVoice("tr-TR-EmelNeural", "tr-TR-AhmetNeural"),
        "ru" to PairVoice("ru-RU-SvetlanaNeural", "ru-RU-DmitryNeural"),
        "es" to PairVoice("es-ES-ElviraNeural", "es-ES-AlvaroNeural"),
        "it" to PairVoice("it-IT-ElsaNeural", "it-IT-DiegoNeural"),
        "zh" to PairVoice("zh-CN-XiaoxiaoNeural", "zh-CN-YunxiNeural"),
    )

    /** true → prefer male when auto-picking. */
    fun prefersMale(preferredVoiceId: String): Boolean =
        preferredVoiceId.contains("Farid", ignoreCase = true) ||
            preferredVoiceId.contains("Guy", ignoreCase = true) ||
            preferredVoiceId.contains("Male", ignoreCase = true) ||
            preferredVoiceId.contains("Hamed", ignoreCase = true) ||
            preferredVoiceId.contains("Conrad", ignoreCase = true) ||
            preferredVoiceId.contains("Henri", ignoreCase = true) ||
            preferredVoiceId.contains("Ahmet", ignoreCase = true) ||
            preferredVoiceId.contains("Dmitry", ignoreCase = true) ||
            preferredVoiceId.contains("Alvaro", ignoreCase = true) ||
            preferredVoiceId.contains("Diego", ignoreCase = true) ||
            preferredVoiceId.contains("Yunxi", ignoreCase = true)

    /**
     * Pick Edge voice for a language code.
     * [preferredVoiceId] only decides gender preference (Dilara vs Farid style).
     */
    fun voiceFor(langCode: String, preferredVoiceId: String = "fa-IR-DilaraNeural"): String {
        val code = langCode.lowercase().substringBefore('-').ifBlank { "en" }
        val pair = byLang[code] ?: byLang["en"]!!
        return if (prefersMale(preferredVoiceId)) pair.male else pair.female
    }

    /** Heuristic language detect from spoken text (no network). */
    fun detectLang(text: String): String {
        val sample = text.take(800)
        if (sample.isBlank()) return "en"
        var arabic = 0 // Arabic script includes Persian
        var latin = 0
        var cyrillic = 0
        var cjk = 0
        for (ch in sample) {
            when (ch) {
                in '\u0600'..'\u06FF', in '\u0750'..'\u077F', in '\u08A0'..'\u08FF',
                in '\uFB50'..'\uFDFF', in '\uFE70'..'\uFEFF' -> arabic++
                in 'A'..'Z', in 'a'..'z', in '\u00C0'..'\u024F' -> latin++
                in '\u0400'..'\u04FF' -> cyrillic++
                in '\u4E00'..'\u9FFF', in '\u3400'..'\u4DBF' -> cjk++
            }
        }
        val total = (arabic + latin + cyrillic + cjk).coerceAtLeast(1)
        // Persian vs Arabic: simple — if user content is mostly Arabic script, prefer fa
        // (app primary audience). Arabic-only books still get Arabic voice if sourceLanguage=ar.
        return when {
            cjk * 2 > total -> "zh"
            cyrillic * 2 > total -> "ru"
            arabic * 2 >= total -> "fa"
            latin * 2 >= total -> "en"
            arabic > 0 -> "fa"
            else -> "en"
        }
    }

    suspend fun synthesize(text: String, voice: String = "fa-IR-DilaraNeural"): ByteArray =
        withContext(Dispatchers.IO) {
            val clean = text.trim()
            if (clean.isEmpty()) return@withContext ByteArray(0)
            // Edge has practical payload limits; keep chunks moderate
            if (clean.length > 1800) {
                val parts = clean.split(Regex("(?<=[.!?؟۔\n])\\s+"))
                val out = ArrayList<ByteArray>()
                val buf = StringBuilder()
                for (p in parts) {
                    if (buf.length + p.length > 1500 && buf.isNotEmpty()) {
                        out += synthesizeSingle(buf.toString(), voice)
                        buf.clear()
                    }
                    if (buf.isNotEmpty()) buf.append(' ')
                    buf.append(p)
                }
                if (buf.isNotEmpty()) out += synthesizeSingle(buf.toString(), voice)
                return@withContext concat(out)
            }
            synthesizeSingle(clean, voice)
        }

    private fun concat(parts: List<ByteArray>): ByteArray {
        val n = parts.sumOf { it.size }
        val all = ByteArray(n)
        var o = 0
        for (p in parts) {
            System.arraycopy(p, 0, all, o, p.size)
            o += p.size
        }
        return all
    }

    private suspend fun synthesizeSingle(text: String, voice: String): ByteArray {
        return try {
            synthesizeSingleAt(text, voice, useBingHost = false)
        } catch (e: Exception) {
            synthesizeSingleAt(text, voice, useBingHost = true)
        }
    }

    private suspend fun synthesizeSingleAt(text: String, voice: String, useBingHost: Boolean): ByteArray =
        suspendCancellableCoroutine { cont ->
            val connId = UUID.randomUUID().toString().replace("-", "")
            val gec = secMsGec()
            // Oct 2026+: speech.platform.bing.com + TrustedClientToken + Sec-MS-GEC v2
            // (api.msedgeservices.com often returns 200 instead of 101 without browser cookies)
            val host = if (useBingHost)
                "wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1"
            else
                "wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1"
            val url =
                host +
                    "?TrustedClientToken=$TOKEN" +
                    "&ConnectionId=$connId" +
                    "&Sec-MS-GEC=$gec" +
                    "&Sec-MS-GEC-Version=2-143.0.3650.96"

            val req = Request.Builder()
                .url(url)
                .header("Origin", "chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold")
                .header("User-Agent",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
                        "(KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0")
                .build()

            val audio = ArrayList<Byte>()
            var finished = false

            val ws = client.newWebSocket(req, object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    val config = "X-Timestamp:" + ts() + "\r\n" +
                        "Content-Type:application/json; charset=utf-8\r\n" +
                        "Path:speech.config\r\n\r\n" +
                        """{"context":{"synthesis":{"audio":{"metadataoptions":{"sentenceBoundaryEnabled":"false","wordBoundaryEnabled":"false"},"outputFormat":"audio-24khz-48kbitrate-mono-mp3"}}}}"""
                    webSocket.send(config)

                    val ssml = buildSsml(text, voice)
                    val speak = "X-RequestId:" + UUID.randomUUID().toString().replace("-", "") + "\r\n" +
                        "Content-Type:application/ssml+xml\r\n" +
                        "X-Timestamp:" + ts() + "Z\r\n" +
                        "Path:ssml\r\n\r\n" + ssml
                    webSocket.send(speak)
                }

                override fun onMessage(webSocket: WebSocket, text: String) {
                    if (text.contains("Path:turn.end") && !finished) {
                        finished = true
                        webSocket.close(1000, null)
                        if (cont.isActive) cont.resume(audio.toByteArray())
                    }
                }

                override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                    // Binary: 2-byte BE header length, then headers, then MP3 payload (edge-tts)
                    val arr = bytes.toByteArray()
                    if (arr.size < 3) return
                    val headerLen = ((arr[0].toInt() and 0xff) shl 8) or (arr[1].toInt() and 0xff)
                    if (headerLen > 0 && headerLen + 2 <= arr.size) {
                        val headerStr = String(arr, 2, headerLen, Charsets.UTF_8)
                        if (headerStr.contains("Path:audio", ignoreCase = true)) {
                            var dataStart = 2 + headerLen
                            if (dataStart + 1 < arr.size &&
                                arr[dataStart] == 13.toByte() && arr[dataStart + 1] == 10.toByte()
                            ) dataStart += 2
                            for (j in dataStart until arr.size) audio.add(arr[j])
                            return
                        }
                    }
                    // Fallback delimiter search
                    val marker = byteArrayOf(80, 97, 116, 104, 58, 97, 117, 100, 105, 111, 13, 10) // Path:audio\r\n
                    val idx = indexOfBytes(arr, marker)
                    if (idx >= 0) {
                        val start = idx + marker.size
                        for (j in start until arr.size) audio.add(arr[j])
                    }
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    if (!finished && cont.isActive) {
                        finished = true
                        cont.resumeWithException(
                            Exception("Edge-TTS: ${t.message ?: response?.code?.toString() ?: "connection failed"}"),
                        )
                    }
                }

                override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                    webSocket.close(1000, null)
                }

                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    if (!finished && cont.isActive) {
                        finished = true
                        if (audio.isNotEmpty()) cont.resume(audio.toByteArray())
                        else cont.resumeWithException(Exception("Edge-TTS: empty audio"))
                    }
                }
            })

            cont.invokeOnCancellation {
                try { ws.cancel() } catch (_: Exception) {}
            }
        }

    private fun buildSsml(text: String, voice: String): String {
        val escaped = text
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
        val v = voice.ifBlank { "fa-IR-DilaraNeural" }
        val langAttr = when {
            v.startsWith("fa-") -> "fa-IR"
            v.startsWith("en-") -> "en-US"
            v.startsWith("ar-") -> "ar-SA"
            v.startsWith("de-") -> "de-DE"
            v.startsWith("fr-") -> "fr-FR"
            v.startsWith("tr-") -> "tr-TR"
            v.startsWith("ru-") -> "ru-RU"
            v.startsWith("es-") -> "es-ES"
            v.startsWith("it-") -> "it-IT"
            v.startsWith("zh-") -> "zh-CN"
            else -> "en-US"
        }
        return """<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="$langAttr">""" +
            """<voice name="$v">$escaped</voice></speak>"""
    }

    private fun indexOfBytes(data: ByteArray, pattern: ByteArray): Int {
        if (pattern.isEmpty() || data.size < pattern.size) return -1
        outer@ for (i in 0..(data.size - pattern.size)) {
            for (j in pattern.indices) {
                if (data[i + j] != pattern[j]) continue@outer
            }
            return i
        }
        return -1
    }
    private fun ts(): String = java.text.SimpleDateFormat("EEE MMM dd yyyy HH:mm:ss 'GMT'Z", java.util.Locale.US)
        .apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }
        .format(java.util.Date())

    /**
     * Sec-MS-GEC v2 (mandatory since Oct 2026).
     * Format: <16 hex CS64>-<64 hex SHA-256>
     * Port of MsEdgeTTS SecMsGec.ts / edge-tts PR #492.
     */
    private fun secMsGec(): String {
        // Windows filetime-ish ticks, rounded down to 5 minutes (300s)
        var ticks = System.currentTimeMillis() / 1000.0 + 11644473600.0
        ticks -= ticks % 300.0
        ticks *= 10_000_000.0 // 100-ns units
        val ticksAndToken = ticks.toLong().toString() + TOKEN
        val message = (EDGE_COPYRIGHT + ticksAndToken).toByteArray(Charsets.US_ASCII)
        val digest = MessageDigest.getInstance("SHA-256").digest(message)
        val cs = cs64(message, digest)
        return toUpperHex(cs) + "-" + toUpperHex(digest)
    }

    private fun cs64(message: ByteArray, digest: ByteArray): ByteArray {
        fun swapHalves(value: Int): Int = ((value shl 16) or (value ushr 16))
        fun imul(a: Int, b: Int): Int = (a.toLong() * b.toLong()).toInt() // low 32 bits

        fun leU32(off: Int): Int {
            var v = 0
            for (i in 0 until 4) v = v or ((digest[off + i].toInt() and 0xff) shl (8 * i))
            return v
        }
        val firstKey = leU32(0) or 1
        val secondKey = leU32(4) or 1

        // pad to multiple of 8
        val padLen = ((message.size + 7) / 8) * 8
        val padded = ByteArray(padLen)
        System.arraycopy(message, 0, padded, 0, message.size)

        fun wordAt(offset: Int): Int {
            var v = 0
            for (i in 0 until 4) {
                v = v or ((padded[offset + i].toInt() and 0xff) shl (8 * i))
            }
            return v
        }

        fun swapTerm(word: Int, key: Int, swappedWord: Int, swappedSum: Int, swappedProduct: Int): Int {
            val sum = imul(word, key) + imul(swapHalves(word), swappedWord)
            val product = imul(swapHalves(sum), swappedSum)
            return imul(swapHalves(product), swappedProduct) + product
        }

        fun swapAndMultiply(value0: Int, multipliers: IntArray): Int {
            var value = value0
            for (m in multipliers) {
                value = imul(swapHalves(value), m)
            }
            return value
        }

        val SWAP_FIRST = intArrayOf(0xEF0569FB.toInt(), 0x76F50F34, 0xC3EFEA97.toInt())
        val SWAP_SECOND = intArrayOf(0xC31713DB.toInt(), 0x1881CE3C, 0x35BD1EC9)
        val MIX_FIRST = intArrayOf(0xCF98B111.toInt(), 0x87085B9F.toInt(), 0x12CEB96D, 0x257E1D83)
        val MIX_SECOND = intArrayOf(0xA27416F5.toInt(), 0xD38396FF.toInt(), 0x7C932B89, 0xBFA49F69.toInt())

        var swapSum = 0
        var lastSwap = 0
        var mix = 0
        var mixSum = 0
        var offset = 0
        while (offset < padded.size) {
            val firstWord = wordAt(offset)
            val secondWord = wordAt(offset + 4)
            val firstSwap = swapTerm(firstWord, firstKey, SWAP_FIRST[0], SWAP_FIRST[1], SWAP_FIRST[2])
            lastSwap = swapTerm(secondWord, secondKey, SWAP_SECOND[0], SWAP_SECOND[1], SWAP_SECOND[2])
            swapSum = (swapSum + firstSwap + lastSwap)
            mix = swapAndMultiply(imul(mix + firstWord, firstKey), MIX_FIRST)
            mixSum = (mixSum + mix)
            mix = swapAndMultiply(imul(mix + secondWord, secondKey), MIX_SECOND)
            mixSum = (mixSum + mix)
            offset += 8
        }
        val out = ByteArray(8)
        val a = lastSwap xor mix
        val b = swapSum xor mixSum
        for (i in 0 until 4) {
            out[i] = ((a ushr (8 * i)) and 0xff).toByte()
            out[4 + i] = ((b ushr (8 * i)) and 0xff).toByte()
        }
        return out
    }

    private fun toUpperHex(bytes: ByteArray): String =
        bytes.joinToString("") { b -> "%02X".format(b.toInt() and 0xff) }

}

