package app.pdfreader.tts

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.os.Build
import app.pdfreader.ai.AiRouter
import app.pdfreader.ai.AiTask
import app.pdfreader.ai.PT
import app.pdfreader.ai.PageTextService
import app.pdfreader.ai.RTL_LANGS
import app.pdfreader.ai.ReadingSettings
import app.pdfreader.ai.SettingsRepo
import app.pdfreader.ai.Wav
import app.pdfreader.ai.plainForSpeech
import app.pdfreader.ai.sha256
import app.pdfreader.core.pdf.PdfDocument
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.BreakIterator
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

private const val PLAN_TIMEOUT_MS = 180_000L

enum class ReadMode { ORIGINAL, TRANSLATE_AUDIO }

data class ReadState(
    val active: Boolean = false,
    val page: Int = 0,
    val mode: ReadMode = ReadMode.ORIGINAL,
    val sentences: List<String> = emptyList(),
    val sentenceIndex: Int = -1,
    val playing: Boolean = false,
    val status: String? = null,
    val error: String? = null,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val speed: Float = 1f,
    val rtl: Boolean = false,
    val highlight: List<NRect> = emptyList(),
    val highlightPossible: Boolean = false,
    val highlightNote: String? = null,
    val wordHighlight: List<NRect> = emptyList(),
    val aheadMs: Long = 0,
)

/**
 * LRU Disk Cache for TTS Audio.
 * Stores synthesized audio files in `context.cacheDir/tts_cache/`.
 * Evicts oldest accessed files when size exceeds [maxSizeBytes].
 */
class TtsAudioCache(
    context: Context,
    private val maxSizeBytes: Long = 80 * 1024 * 1024L, // 80 MB
    private val targetSizeBytes: Long = 60 * 1024 * 1024L, // 60 MB
) {
    private val cacheDir = File(context.cacheDir, "tts_cache").also { it.mkdirs() }

    fun computeKey(text: String, lang: String, voice: String, speed: Float): String {
        return sha256("tts_v3|${lang.trim()}|${voice.trim()}|${speed}|${text.trim()}")
    }

    fun get(key: String): File? {
        val f = File(cacheDir, "$key.wav")
        return if (f.exists() && f.length() > 44) {
            f.setLastModified(System.currentTimeMillis())
            f
        } else {
            null
        }
    }

    fun put(key: String, wavBytes: ByteArray): File? {
        return try {
            val target = File(cacheDir, "$key.wav")
            val tmp = File(cacheDir, "$key.tmp")
            FileOutputStream(tmp).use { it.write(wavBytes) }
            if (tmp.renameTo(target)) {
                target.setLastModified(System.currentTimeMillis())
                trimToSize()
                target
            } else {
                tmp.delete()
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun trimToSize() {
        try {
            val files = cacheDir.listFiles() ?: return
            var currentBytes = files.sumOf { it.length() }
            if (currentBytes <= maxSizeBytes && files.size <= 500) return

            // Sort by last modified ascending (oldest first)
            val sorted = files.sortedBy { it.lastModified() }
            for (file in sorted) {
                val len = file.length()
                if (file.delete()) {
                    currentBytes -= len
                    if (currentBytes <= targetSizeBytes) break
                }
            }
        } catch (ignored: Exception) {}
    }

    fun clear() {
        cacheDir.listFiles()?.forEach { it.delete() }
    }

    fun sizeBytes(): Long = cacheDir.listFiles()?.sumOf { it.length() } ?: 0L
}

/** Individual sentence item with its audio file, duration and highlight rects. */
class SentenceItem(
    val index: Int,
    val text: String,
    val rects: List<NRect> = emptyList(),
) {
    @Volatile var file: File? = null
    @Volatile var durationMs: Long = 0
}

private class Preloaded(val sentenceIndex: Int, val mp: MediaPlayer, val plan: PagePlan) {
    @Volatile var ready = false
}

private class PagePlan(
    val page: Int,
    val sentences: List<SentenceItem>,
    val rtl: Boolean,
    val note: String? = null,
    val highlightPossible: Boolean = false,
)

/**
 * High-performance Read Aloud Controller:
 * - Sentence-level splitting via BreakIterator
 * - Audio caching in context.cacheDir/tts_cache with LRU eviction
 * - Pipelined prefetching: produces ahead 1-2 sentences + next page boundaries
 * - Gapless playback handover
 * - Prioritized flushing on page navigation
 */
class ReadAloudController(
    context: Context,
    private val router: AiRouter,
    private val texts: PageTextService,
    private val settings: SettingsRepo,
    private val textEngine: PdfiumTextEngine,
) {
    private val ctx = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val audioCache = TtsAudioCache(ctx)

    private val _state = MutableStateFlow(ReadState())
    val state: StateFlow<ReadState> = _state.asStateFlow()

    private val inflight = ConcurrentHashMap<String, Deferred<File?>>()
    private val plans = HashMap<String, Deferred<PagePlan?>>()

    private var preloaded: Preloaded? = null
    private var nextPagePlanReady: PagePlan? = null
    private var prefetchJob: Job? = null
    private var playJob: Job? = null
    private var startJob: Job? = null
    private var ticker: Job? = null

    private var doc: PdfDocument? = null
    private var docUri = ""
    private var mode = ReadMode.ORIGINAL
    private var currentPlan: PagePlan? = null
    private var activeSentenceIndex = 0
    private var player: MediaPlayer? = null
    private var speed = 1f
    private var generation = 0
    @Volatile private var lastSynthError = ""

    // ------------------------------------------------------------------ Public API

    fun start(doc: PdfDocument, docUri: String, page: Int, mode: ReadMode) {
        stop()
        this.doc = doc
        this.docUri = docUri
        this.mode = mode
        _state.value = ReadState(
            active = true,
            page = page,
            mode = mode,
            status = "در حال آماده‌سازی…",
            speed = speed,
        )
        startJob = scope.launch { openPage(page, 0) }
    }

    fun toggle() {
        val st = _state.value
        if (!st.active) return
        val p = player
        if (st.error != null || p == null) {
            _state.update { it.copy(error = null) }
            val pl = currentPlan
            if (pl != null && st.sentenceIndex in pl.sentences.indices) {
                playSentence(st.sentenceIndex)
            } else {
                startJob?.cancel()
                startJob = scope.launch { openPage(st.page, st.sentenceIndex.coerceAtLeast(0)) }
            }
            return
        }
        try {
            if (p.isPlaying) {
                p.pause()
                ticker?.cancel()
                _state.update { it.copy(playing = false) }
            } else {
                p.start()
                _state.update { it.copy(playing = true) }
                startTicker(generation)
            }
        } catch (e: IllegalStateException) {
            // player state mismatch, recreate
            playSentence(activeSentenceIndex)
        }
    }

    fun seekBy(deltaMs: Int) {
        val p = player ?: return
        try {
            val target = p.currentPosition + deltaMs
            val dur = p.duration
            when {
                target < 0 -> jumpSentence(-1)
                target >= dur -> onSentenceComplete()
                else -> p.seekTo(target)
            }
        } catch (ignored: Exception) {}
    }

    fun jumpSentence(delta: Int) {
        val pl = currentPlan ?: return
        val target = (activeSentenceIndex + delta).coerceIn(0, pl.sentences.size)
        if (target >= pl.sentences.size) {
            onPageComplete()
        } else {
            playSentence(target)
        }
    }

    fun seekToFraction(f: Float) {
        val pl = currentPlan ?: return
        if (pl.sentences.isEmpty()) return
        val target = (pl.sentences.size * f).toInt().coerceIn(0, pl.sentences.size - 1)
        playSentence(target)
    }

    fun setSpeed(v: Float) {
        speed = v
        discardPreloaded()
        _state.update { it.copy(speed = v) }
        player?.let { p ->
            try {
                val was = p.isPlaying
                applySpeed(p)
                if (!was) p.pause()
            } catch (ignored: Exception) {}
        }
    }

    fun onPageScrolled(page: Int) {
        // If user manually swipes to another page while not actively speaking that page,
        // prioritize background prefetching for the user's current reading spot.
        if (!_state.value.active) return
        if (page != currentPlan?.page) {
            scope.launch {
                prefetchNextPage(page)
            }
        }
    }

    fun stop() {
        generation++
        startJob?.cancel()
        playJob?.cancel()
        prefetchJob?.cancel()
        ticker?.cancel()

        inflight.values.forEach { it.cancel() }
        inflight.clear()
        plans.values.forEach { it.cancel() }
        plans.clear()

        releasePlayer()
        currentPlan = null
        nextPagePlanReady = null
        _state.value = ReadState(speed = speed)
    }

    fun clearAudio() {
        stop()
        audioCache.clear()
    }

    fun audioBytes(): Long = audioCache.sizeBytes()

    // ------------------------------------------------------------------ Sentence Playback Pipeline

    private suspend fun openPage(startPage: Int, startSentence: Int) {
        val d = doc ?: return
        var page = startPage
        while (page < d.pageCount) {
            _state.update {
                it.copy(
                    page = page,
                    status = "در حال آماده‌سازی صفحه ${page + 1}…",
                    error = null,
                    sentences = emptyList(),
                    sentenceIndex = -1,
                    positionMs = 0,
                    durationMs = 0,
                    playing = false,
                )
            }

            val pl = awaitPlan(page)
            if (!_state.value.active) return
            if (pl == null) {
                if (_state.value.error == null) fail("آماده‌سازی صفحه ${page + 1} ممکن نشد. دوباره تلاش کنید.")
                return
            }

            if (pl.sentences.isEmpty()) {
                page++
                continue
            }

            activatePlan(pl)
            playSentence(startSentence.coerceIn(0, pl.sentences.size - 1))
            return
        }
        stop()
    }

    private fun activatePlan(pl: PagePlan) {
        currentPlan = pl
        _state.update {
            it.copy(
                page = pl.page,
                sentences = pl.sentences.map { s -> s.text },
                rtl = pl.rtl,
                status = null,
                error = null,
                sentenceIndex = -1,
                highlight = emptyList(),
                highlightPossible = pl.highlightPossible,
                highlightNote = pl.note,
                durationMs = pl.sentences.size.toLong(),
            )
        }
    }

    private fun playSentence(index: Int) {
        val pl = currentPlan ?: return
        val sentence = pl.sentences.getOrNull(index) ?: return
        val gen = ++generation
        activeSentenceIndex = index
        ticker?.cancel()
        discardPreloaded()
        playJob?.cancel()

        // Update highlight immediately so UI responds in real time
        _state.update {
            it.copy(
                sentenceIndex = index,
                highlight = sentence.rects,
                status = if (sentence.file == null) "در حال تولید صدای جمله…" else null,
                error = null,
            )
        }

        playJob = scope.launch {
            try {
                val file = ensureSentenceAudio(sentence)
                if (gen != generation || !_state.value.active) return@launch

                if (file == null) {
                    fail(lastSynthError.ifBlank { "تولید صدای جمله ممکن نشد." })
                    return@launch
                }

                // Trigger background prefetching pipeline for upcoming sentences & next page
                pipelinePrefetch(pl, index)

                startPlayer(file, index, gen)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (gen == generation) fail("پخش صدا ممکن نشد: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    private fun startPlayer(f: File, sentenceIdx: Int, gen: Int) {
        releasePlayer()
        val mp = try {
            newPlayer(f)
        } catch (e: Exception) {
            fail("پخش صدا ممکن نشد.")
            return
        }

        var prepared = false
        try {
            mp.setOnPreparedListener { p ->
                prepared = true
                if (gen != generation) {
                    try { p.release() } catch (ignored: Exception) {}
                    return@setOnPreparedListener
                }
                if (needsSpeed(p)) applySpeed(p)
                p.start()
                _state.update { it.copy(playing = true, status = null, error = null) }
                startTicker(gen)
            }

            mp.setOnCompletionListener {
                if (gen == generation) onSentenceComplete()
            }

            mp.setOnErrorListener { _, _, _ ->
                if (gen == generation) fail("پخش صدا با خطا مواجه شد.")
                true
            }

            player = mp
            mp.prepareAsync()

            scope.launch {
                delay(8_000)
                if (gen == generation && !prepared && player === mp) {
                    fail("آماده‌سازی پخش صدا طول کشید. دوباره تلاش کنید.")
                }
            }
        } catch (e: Exception) {
            try { mp.release() } catch (ignored: Exception) {}
            fail("پخش صدا ممکن نشد.")
        }
    }

    private fun onSentenceComplete() {
        val pl = currentPlan ?: return
        val nextIdx = activeSentenceIndex + 1

        if (nextIdx < pl.sentences.size) {
            val pre = preloaded
            if (pre != null && pre.plan === pl && pre.sentenceIndex == nextIdx && pre.ready) {
                handOver(pre)
            } else {
                playSentence(nextIdx)
            }
        } else {
            onPageComplete()
        }
    }

    private fun onPageComplete() {
        val pl = currentPlan ?: return
        val pre = preloaded

        if (pre != null && pre.plan !== pl && pre.plan.page == pl.page + 1 && pre.ready) {
            activatePlan(pre.plan)
            handOver(pre)
            return
        }

        val nextPage = pl.page + 1
        if (nextPage >= (doc?.pageCount ?: 0)) {
            stop()
        } else {
            startJob?.cancel()
            startJob = scope.launch { openPage(nextPage, 0) }
        }
    }

    private fun handOver(pre: Preloaded) {
        val old = player
        val gen = ++generation
        preloaded = null
        activeSentenceIndex = pre.sentenceIndex
        ticker?.cancel()

        val pl = pre.plan
        currentPlan = pl
        val sentence = pl.sentences.getOrNull(pre.sentenceIndex)

        try {
            pre.mp.setOnCompletionListener { if (gen == generation) onSentenceComplete() }
            pre.mp.setOnErrorListener { _, _, _ ->
                if (gen == generation) fail("پخش صدا با خطا مواجه شد.")
                true
            }

            player = pre.mp
            pre.mp.start()
            if (needsSpeed(pre.mp)) applySpeed(pre.mp)

            _state.update {
                it.copy(
                    page = pl.page,
                    sentenceIndex = pre.sentenceIndex,
                    highlight = sentence?.rects.orEmpty(),
                    playing = true,
                    status = null,
                    error = null,
                )
            }
            startTicker(gen)
            pipelinePrefetch(pl, pre.sentenceIndex)
        } catch (e: Exception) {
            try { pre.mp.release() } catch (ignored: Exception) {}
            player = null
            playSentence(pre.sentenceIndex)
        }

        if (old != null) {
            scope.launch { try { old.release() } catch (ignored: Exception) {} }
        }
    }

    // ------------------------------------------------------------------ Seamless Prefetching & Pipelining

    private fun pipelinePrefetch(pl: PagePlan, currentIdx: Int) {
        prefetchJob?.cancel()
        prefetchJob = scope.launch(Dispatchers.IO) {
            val s = settings.state.value
            val lang = if (mode == ReadMode.TRANSLATE_AUDIO) s.targetLanguage else s.sourceLanguage
            val voice = s.voice

            // 1. Prefetch next 1-2 sentences on current page
            for (offset in 1..2) {
                if (!isActive) return@launch
                val idx = currentIdx + offset
                if (idx < pl.sentences.size) {
                    val nextSent = pl.sentences[idx]
                    if (nextSent.file == null) {
                        ensureSentenceAudio(nextSent)
                    }
                    // Preload next player for immediate zero-gap handoff
                    if (offset == 1 && preloaded == null) {
                        preloadPlayer(pl, idx)
                    }
                }
            }

            // 2. Page boundary crossing: if within last 2 sentences of page, prefetch next page
            if (currentIdx >= pl.sentences.size - 2) {
                val nextPage = pl.page + 1
                if (nextPage < (doc?.pageCount ?: 0)) {
                    val np = awaitPlan(nextPage)
                    if (np != null && np.sentences.isNotEmpty()) {
                        nextPagePlanReady = np
                        // Prefetch first 2 sentences of the next page
                        for (i in 0..minOf(1, np.sentences.lastIndex)) {
                            if (!isActive) return@launch
                            ensureSentenceAudio(np.sentences[i])
                        }
                        // If current page is at its very last sentence, preload next page's first sentence!
                        if (currentIdx == pl.sentences.lastIndex && preloaded == null) {
                            preloadPlayer(np, 0)
                        }
                    }
                }
            }
        }
    }

    private suspend fun prefetchNextPage(page: Int) {
        val d = doc ?: return
        if (page in 0 until d.pageCount) {
            planFor(page)
        }
    }

    private fun preloadPlayer(targetPlan: PagePlan, sentenceIdx: Int) {
        val sentence = targetPlan.sentences.getOrNull(sentenceIdx) ?: return
        val f = sentence.file ?: return
        if (preloaded != null) return

        try {
            val mp = newPlayer(f)
            val pre = Preloaded(sentenceIdx, mp, targetPlan)
            mp.setOnPreparedListener { pre.ready = true }
            mp.setOnErrorListener { _, _, _ ->
                if (preloaded === pre) discardPreloaded()
                true
            }
            preloaded = pre
            mp.prepareAsync()
        } catch (e: Exception) {
            preloaded = null
        }
    }

    private fun discardPreloaded() {
        preloaded?.let { try { it.mp.release() } catch (ignored: Exception) {} }
        preloaded = null
    }

    // ------------------------------------------------------------------ Audio Generation & Cache

    private suspend fun ensureSentenceAudio(item: SentenceItem): File? {
        item.file?.let { return it }

        val s = settings.state.value
        val lang = if (mode == ReadMode.TRANSLATE_AUDIO) s.targetLanguage else s.sourceLanguage
        val voice = s.voice
        val key = audioCache.computeKey(item.text, lang, voice, speed)

        // 1. Check disk LRU cache
        val cached = audioCache.get(key)
        if (cached != null) {
            item.file = cached
            item.durationMs = wavDurationMs(cached)
            return cached
        }

        // 2. Synthesize via network on Dispatchers.IO
        return inflight.getOrPut(key) {
            scope.async(Dispatchers.IO) {
                try {
                    val o = router.synthesize(item.text, voice, "")
                    if (o is AiRouter.Outcome.Failed) {
                        lastSynthError = texts.describe(o)
                        null
                    } else {
                        val rawWav = (o as AiRouter.Outcome.Ok).audio
                        if (rawWav != null && rawWav.size > 44) {
                            val polished = Wav.polish(rawWav)
                            val saved = audioCache.put(key, polished)
                            if (saved != null) {
                                item.file = saved
                                item.durationMs = Wav.durationMs(polished)
                                saved
                            } else null
                        } else null
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    lastSynthError = "خطای تولید صدا: ${e.message ?: e.javaClass.simpleName}"
                    null
                } finally {
                    inflight.remove(key)
                }
            }
        }.await()
    }

    // ------------------------------------------------------------------ Plan Creation & Sentence Splitting

    private fun planFor(page: Int): Deferred<PagePlan?> {
        val d = doc
        val uri = docUri
        val m = mode
        return plans.getOrPut("$page|${m.name}") {
            scope.async(Dispatchers.Default) {
                try {
                    withTimeout(PLAN_TIMEOUT_MS) { buildPlan(d, uri, m, page) }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    failFor(page, "خطا در آماده‌سازی صفحه: ${e.message ?: e.javaClass.simpleName}")
                    null
                }
            }
        }
    }

    private suspend fun awaitPlan(page: Int): PagePlan? {
        val key = "$page|${mode.name}"
        val d = planFor(page)
        val r = try {
            d.await()
        } catch (e: CancellationException) {
            currentCoroutineContext().ensureActive()
            null
        }
        if (r == null) plans.remove(key, d)
        return r
    }

    private suspend fun buildPlan(d: PdfDocument?, uri: String, m: ReadMode, page: Int): PagePlan? {
        if (d == null) return null
        val s = settings.state.value

        val ex = texts.extract(d, uri, page, s) { phase ->
            if (page == _state.value.page) _state.update { it.copy(status = phase) }
        }

        var text = when (ex) {
            is PT.Ok -> ex.text
            PT.NoText -> return PagePlan(page, emptyList(), false)
            is PT.Fail -> { failFor(page, ex.message); return null }
        }

        val isRtl = isRtlText(text)

        if (m == ReadMode.TRANSLATE_AUDIO && s.sourceLanguage != s.targetLanguage) {
            if (page == _state.value.page) _state.update { it.copy(status = "در حال ترجمه برای تولید صدا…") }
            when (val tr = texts.process(AiTask.TRANSLATE, uri, page, s, text)) {
                is PT.Ok -> text = tr.text
                is PT.Fail -> { failFor(page, tr.message); return null }
                PT.NoText -> return PagePlan(page, emptyList(), false)
            }
        }

        // Split text cleanly using BreakIterator
        val cleanSpeech = plainForSpeech(text.lines().filterNot { it.trimStart().startsWith("|") }.joinToString("\n"))
        val rawSentences = splitSentencesWithBreakIterator(cleanSpeech, isRtl)
        if (rawSentences.isEmpty()) return PagePlan(page, emptyList(), isRtl)

        // Map sentence rects on the PDF page for highlighting
        var rects: List<List<NRect>>? = null
        var note: String? = null
        if (m == ReadMode.ORIGINAL && s.highlightPdf) {
            val map = textEngine.mapSentences(uri, page, rawSentences)
            if (map != null) rects = map.rects else note = textEngine.lastError
        }

        val items = rawSentences.mapIndexed { idx, sText ->
            SentenceItem(
                index = idx,
                text = sText,
                rects = rects?.getOrNull(idx).orEmpty(),
            )
        }

        val found = items.count { it.rects.isNotEmpty() }
        val possible = rects != null && items.isNotEmpty() && found * 100 >= items.size * 40

        return PagePlan(
            page = page,
            sentences = items,
            rtl = isRtl,
            note = note,
            highlightPossible = possible,
        )
    }

    /**
     * Splits text into individual sentences using BreakIterator for accurate sentence-level granularity.
     */
    private fun splitSentencesWithBreakIterator(text: String, isRtl: Boolean): List<String> {
        if (text.isBlank()) return emptyList()
        val locale = if (isRtl) Locale("fa") else Locale.ENGLISH
        val iterator = BreakIterator.getSentenceInstance(locale)
        iterator.setText(text)
        val sentences = ArrayList<String>()
        var start = iterator.first()
        var end = iterator.next()
        while (end != BreakIterator.DONE) {
            val s = text.substring(start, end).trim()
            if (s.isNotEmpty() && s.any { it.isLetterOrDigit() }) {
                // If a sentence is extraordinarily long (> 300 chars without punctuation), keep it manageable
                if (s.length > 350) {
                    sentences.addAll(s.split("\n").map { it.trim() }.filter { it.isNotEmpty() })
                } else {
                    sentences.add(s)
                }
            }
            start = end
            end = iterator.next()
        }
        return sentences
    }

    private fun isRtlText(s: String): Boolean {
        var rtl = 0
        var ltr = 0
        for (ch in s) {
            when (Character.getDirectionality(ch)) {
                Character.DIRECTIONALITY_RIGHT_TO_LEFT, Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC -> rtl++
                Character.DIRECTIONALITY_LEFT_TO_RIGHT -> ltr++
                else -> {}
            }
        }
        return rtl > 0 && rtl >= ltr
    }

    // ------------------------------------------------------------------ Playback Utilities

    private fun startTicker(gen: Int) {
        ticker?.cancel()
        ticker = scope.launch {
            while (isActive && gen == generation) {
                updateProgress()
                delay(120)
            }
        }
    }

    private fun updateProgress() {
        val p = player ?: return
        val pl = currentPlan ?: return
        val pos = try { p.currentPosition.toLong() } catch (e: Exception) { return }
        val dur = try { p.duration.toLong().coerceAtLeast(1L) } catch (e: Exception) { 1L }

        val sentence = pl.sentences.getOrNull(activeSentenceIndex)
        _state.update {
            it.copy(
                positionMs = pos,
                durationMs = dur,
                sentenceIndex = activeSentenceIndex,
                highlight = sentence?.rects ?: it.highlight,
            )
        }
    }

    private fun newPlayer(f: File): MediaPlayer {
        val mp = MediaPlayer()
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            mp.setDataSource(f.absolutePath)
            if (speed != 1f && Build.VERSION.SDK_INT >= 23) {
                try { mp.playbackParams = PlaybackParams().setSpeed(speed) } catch (ignored: Exception) {}
            }
        } catch (e: Exception) {
            try { mp.release() } catch (ignored: Exception) {}
            throw e
        }
        return mp
    }

    private fun needsSpeed(p: MediaPlayer): Boolean {
        if (Build.VERSION.SDK_INT < 23) return false
        return try { kotlin.math.abs(p.playbackParams.speed - speed) > 0.01f } catch (e: Exception) { speed != 1f }
    }

    private fun applySpeed(p: MediaPlayer) {
        if (Build.VERSION.SDK_INT >= 23) {
            try { p.playbackParams = p.playbackParams.setSpeed(speed) } catch (ignored: Exception) {}
        }
    }

    private fun fail(message: String) {
        ticker?.cancel()
        try { player?.pause() } catch (ignored: Exception) {}
        _state.update { it.copy(error = message, playing = false, status = null) }
    }

    private fun failFor(page: Int, message: String) {
        if (page == _state.value.page) fail(message)
    }

    private fun releasePlayer() {
        discardPreloaded()
        player?.let { try { it.release() } catch (ignored: Exception) {} }
        player = null
    }

    private fun wavDurationMs(f: File): Long = try {
        f.inputStream().use { ins ->
            val h = ByteArray(44)
            if (ins.read(h) < 44) 0L else {
                val byteRate = ByteBuffer.wrap(h, 28, 4).order(ByteOrder.LITTLE_ENDIAN).int
                if (byteRate > 0) (f.length() - 44) * 1000L / byteRate else 0L
            }
        }
    } catch (e: Exception) { 0L }
}
