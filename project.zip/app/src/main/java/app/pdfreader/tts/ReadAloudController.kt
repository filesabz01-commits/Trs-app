package app.pdfreader.tts

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.os.Build
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import app.pdfreader.ai.AiRouter
import app.pdfreader.ai.AiTask
import app.pdfreader.ai.PT
import app.pdfreader.ai.PageTextService
import app.pdfreader.ai.RTL_LANGS
import app.pdfreader.ai.ReadingSettings
import app.pdfreader.ai.ReadingProfile
import app.pdfreader.ai.SettingsRepo
import app.pdfreader.ai.Wav
import app.pdfreader.ai.plainForSpeech
import app.pdfreader.ai.sha256
import app.pdfreader.core.pdf.PdfDocument
import app.pdfreader.ui.TextPick
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

private const val PLAN_TIMEOUT_MS = 60_000L
private const val NO_TEXT_MARK = "[[NO_TEXT]]"

enum class ReadMode { ORIGINAL, TRANSLATE_AUDIO }

data class ReadState(
    val active: Boolean = false,
    val page: Int = 0,
    val mode: ReadMode = ReadMode.ORIGINAL,
    val sentences: List<String> = emptyList(),
    val sentenceIndex: Int = -1,
    val playing: Boolean = false,
    val status: String? = null,
    val error: String? = null,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val speed: Float = 1f,
    val rtl: Boolean = false,
    val highlight: List<NRect> = emptyList(),
    val highlightPossible: Boolean = false,
    val highlightNote: String? = null,
    val wordHighlight: List<NRect> = emptyList(),
    val aheadMs: Long = 0,
)

private class Chunk(val text: String, val first: Int, val last: Int, val lens: IntArray) {
    @Volatile var file: File? = null
    @Volatile var durationMs: Long = 0
    @Volatile var starts: LongArray? = null
}

private class Preloaded(val ci: Int, val mp: MediaPlayer, val plan: Plan) {
    @Volatile var ready = false
}

private class Plan(
    val page: Int,
    val sentences: List<String>,
    val chunks: List<Chunk>,
    val rtl: Boolean,
    val rects: List<List<NRect>>? = null,
    val note: String? = null,
    val ranges: List<IntRange?>? = null,
    val chars: PageChars? = null,
)

/**
 * Read Aloud Controller:
 * - Dual Engine: System TextToSpeech (Free, Offline) vs Gemini AI TTS (Natural voice)
 * - Restored segmentPlan for aligned paragraph-by-paragraph translation with original PDF rect highlighting
 * - Time-based prefetching (maintains 40-60s ahead, halts when paused or user navigates >3 pages)
 * - Content-hash based caching to prevent token waste
 * - Playback-time speed control (no re-synthesis)
 */
class ReadAloudController(
    context: Context,
    private val router: AiRouter,
    private val texts: PageTextService,
    private val settings: SettingsRepo,
    private val textEngine: PdfiumTextEngine,
) {
    private val ctx = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val _state = MutableStateFlow(ReadState())
    val state: StateFlow<ReadState> = _state.asStateFlow()

    private val ttsDir = File(ctx.filesDir, "tts").also { it.mkdirs() }
    private val inflight = ConcurrentHashMap<String, Deferred<File?>>()
    private val plans = HashMap<String, Deferred<Plan?>>()
    private var preloaded: Preloaded? = null
    private var nextPlanReady: Plan? = null
    private var playJob: Job? = null
    private var lastWord: IntRange? = null

    private var doc: PdfDocument? = null
    private var docUri = ""
    private var mode = ReadMode.ORIGINAL
    private var plan: Plan? = null
    private var chunkIndex = 0
    private var player: MediaPlayer? = null
    private var ticker: Job? = null
    private var bgJob: Job? = null
    private var startJob: Job? = null
    private var speed = 1f
    private var generation = 0
    @Volatile private var lastSynthError = ""

    // System TextToSpeech Engine
    private var systemTts: TextToSpeech? = null
    private var systemTtsReady = false

    private fun ensureSystemTts(onReady: () -> Unit) {
        if (systemTtsReady && systemTts != null) {
            onReady()
            return
        }
        systemTts?.shutdown()
        systemTts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                systemTtsReady = true
                systemTts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        val idx = utteranceId?.removePrefix("utt_")?.toIntOrNull() ?: return
                        scope.launch {
                            val pl = plan ?: return@launch
                            val hl = pl.rects?.getOrNull(idx).orEmpty()
                            _state.update { it.copy(sentenceIndex = idx, highlight = hl, playing = true, status = null) }
                        }
                    }
                    override fun onDone(utteranceId: String?) {
                        val idx = utteranceId?.removePrefix("utt_")?.toIntOrNull() ?: return
                        scope.launch {
                            val pl = plan ?: return@launch
                            if (idx + 1 < pl.sentences.size) {
                                playSystemSentence(idx + 1)
                            } else {
                                onPageDone()
                            }
                        }
                    }
                    override fun onError(utteranceId: String?) {
                        scope.launch { fail("خطا در موتور صوتی سیستم") }
                    }
                })
                onReady()
            } else {
                fail("موتور صوتی سیستم در دسترس نیست")
            }
        }
    }

    private fun playSystemSentence(idx: Int) {
        val pl = plan ?: return
        if (idx !in pl.sentences.indices) return
        val tts = systemTts ?: return
        val s = settings.state.value
        val locale = if (pl.rtl || s.targetLanguage in RTL_LANGS) Locale("fa") else Locale.ENGLISH
        try { tts.language = locale } catch (ignored: Exception) {}
        try { tts.setSpeechRate(speed) } catch (ignored: Exception) {}
        val sent = pl.sentences[idx]
        tts.speak(sent, TextToSpeech.QUEUE_FLUSH, null, "utt_$idx")
    }

    // ------------------------------------------------------------------ public API

    fun start(doc: PdfDocument, docUri: String, page: Int, mode: ReadMode) {
        stop()
        this.doc = doc
        this.docUri = docUri
        this.mode = mode
        _state.value = ReadState(active = true, page = page, mode = mode, status = "در حال آماده‌سازی…", speed = speed)
        startJob = scope.launch { openPage(page, 0) }
    }

    fun toggle() {
        val st = _state.value
        if (!st.active) return
        val isSystem = settings.state.value.ttsEngine == "system"
        if (isSystem) {
            if (st.playing) {
                systemTts?.stop()
                _state.update { it.copy(playing = false) }
            } else {
                val nextIdx = st.sentenceIndex.coerceAtLeast(0)
                ensureSystemTts { playSystemSentence(nextIdx) }
            }
            return
        }

        val p = player
        if (st.error != null || p == null) {
            _state.update { it.copy(error = null) }
            val ci = plan?.let { pl -> pl.chunks.indexOfFirst { c -> st.sentenceIndex in c.first..c.last } }
            if (plan != null && ci != null && ci >= 0) playChunkAt(ci, st.sentenceIndex.coerceAtLeast(0))
            else {
                startJob?.cancel()
                startJob = scope.launch { openPage(st.page, st.sentenceIndex.coerceAtLeast(0)) }
            }
            return
        }

        try {
            if (p.isPlaying) {
                p.pause()
                ticker?.cancel()
                bgJob?.cancel()
                _state.update { it.copy(playing = false) }
            } else {
                p.start()
                _state.update { it.copy(playing = true) }
                startTicker(generation)
                plan?.let { startPrefetch(it) }
            }
        } catch (e: IllegalStateException) {
            // player is being replaced; ignore
        }
    }

    fun seekBy(deltaMs: Int) {
        if (settings.state.value.ttsEngine == "system") {
            jumpSentence(if (deltaMs > 0) 1 else -1)
            return
        }
        val p = player ?: return
        val pl = plan ?: return
        val c = pl.chunks.getOrNull(chunkIndex) ?: return
        try {
            val target = p.currentPosition + deltaMs
            val dur = if (c.durationMs > 0) c.durationMs.toInt() else p.duration
            when {
                target < 0 -> if (chunkIndex > 0) {
                    val prev = pl.chunks[chunkIndex - 1]
                    playChunkAt(chunkIndex - 1, startMs = (prev.durationMs + target).toInt().coerceAtLeast(0))
                } else p.seekTo(0)
                target >= dur -> onChunkDone(chunkIndex)
                else -> p.seekTo(target)
            }
        } catch (e: IllegalStateException) {
            // ignore
        }
    }

    fun jumpSentence(delta: Int) {
        val pl = plan ?: return
        val target = _state.value.sentenceIndex.coerceAtLeast(0) + delta
        if (settings.state.value.ttsEngine == "system") {
            val clamped = target.coerceIn(0, pl.sentences.lastIndex)
            playSystemSentence(clamped)
            return
        }
        when {
            target < 0 -> playChunkAt(0, 0)
            target >= pl.sentences.size -> onChunkDone(pl.chunks.size - 1)
            else -> playChunkAt(chunkOfSentence(pl, target), target)
        }
    }

    fun seekToFraction(f: Float) {
        val pl = plan ?: return
        if (settings.state.value.ttsEngine == "system") {
            val idx = (pl.sentences.size * f).toInt().coerceIn(0, pl.sentences.lastIndex)
            playSystemSentence(idx)
            return
        }
        val total = pl.chunks.sumOf { estimateMs(it) }
        var remaining = (total * f).toLong()
        for ((i, c) in pl.chunks.withIndex()) {
            val d = estimateMs(c)
            if (remaining < d || i == pl.chunks.lastIndex) {
                playChunkAt(i, startMs = remaining.coerceAtMost(d).toInt())
                return
            }
            remaining -= d
        }
    }

    fun setSpeed(v: Float) {
        speed = v.coerceIn(0.5f, 2.5f)
        discardPreloaded()
        _state.update { it.copy(speed = speed) }
        player?.let { p ->
            try {
                val was = p.isPlaying
                applySpeed(p)
                if (!was) p.pause()
            } catch (e: IllegalStateException) {}
        }
        try { systemTts?.setSpeechRate(speed) } catch (ignored: Exception) {}
    }

    fun stop() {
        generation++
        startJob?.cancel()
        playJob?.cancel()
        bgJob?.cancel()
        ticker?.cancel()
        inflight.values.forEach { it.cancel() }
        inflight.clear()
        releasePlayer()
        discardPreloaded()
        systemTts?.stop()
        plans.values.forEach { it.cancel() }
        plans.clear()
        plan = null
        nextPlanReady = null
        lastWord = null
        _state.value = ReadState(speed = speed)
    }

    fun clearAudio() {
        stop()
        ttsDir.listFiles()?.forEach { it.delete() }
    }

    fun audioBytes(): Long = ttsDir.listFiles()?.sumOf { it.length() } ?: 0L

    // ------------------------------------------------------------------ pages and plans

    private suspend fun openPage(startPage: Int, startSentence: Int) {
        val d = doc ?: return
        var page = startPage
        var sentence = startSentence
        while (page < d.pageCount) {
            _state.update {
                it.copy(
                    page = page, status = "در حال آماده‌سازی صفحه ${page + 1}…", error = null,
                    sentences = emptyList(), sentenceIndex = -1, positionMs = 0, durationMs = 0, playing = false,
                )
            }
            val pl = awaitPlan(page)
            if (!_state.value.active) return
            if (pl == null) {
                if (_state.value.error == null) fail("آماده‌سازی صفحه ${page + 1} ممکن نشد. دوباره تلاش کنید.")
                return
            }
            if (pl.chunks.isEmpty()) {
                page++
                sentence = 0
                continue
            }
            activatePlan(pl)
            if (settings.state.value.ttsEngine == "system") {
                ensureSystemTts { playSystemSentence(sentence) }
            } else {
                playChunkAt(chunkOfSentence(pl, sentence), sentence)
            }
            return
        }
        stop()
    }

    private fun activatePlan(pl: Plan) {
        plan = pl
        lastWord = null
        val found = pl.rects?.count { it.isNotEmpty() } ?: 0
        val possible = pl.rects != null && pl.sentences.isNotEmpty() && found * 100 >= pl.sentences.size * 40
        _state.update {
            it.copy(
                page = pl.page, sentences = pl.sentences, rtl = pl.rtl, status = null, error = null,
                highlight = emptyList(), wordHighlight = emptyList(), sentenceIndex = -1,
                highlightPossible = possible,
                highlightNote = if (possible) null else (pl.note ?: if (pl.rects != null) "جمله‌ها روی PDF پیدا نشدند" else null),
            )
        }
        startPrefetch(pl)
    }

    private fun planFor(page: Int): Deferred<Plan?> {
        val d = doc
        val uri = docUri
        val m = mode
        return plans.getOrPut("$page|${m.name}") {
            scope.async(Dispatchers.Default) {
                try {
                    withTimeout(PLAN_TIMEOUT_MS) { buildPlan(d, uri, m, page) }
                } catch (e: TimeoutCancellationException) {
                    failFor(page, "آماده‌سازی صفحه ${page + 1} بیش از حد طول کشید.")
                    null
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    failFor(page, "خطای آماده‌سازی صفحه: " + (e.message ?: e.javaClass.simpleName))
                    null
                }
            }
        }
    }

    private suspend fun awaitPlan(page: Int): Plan? {
        val key = "$page|${mode.name}"
        val d = planFor(page)
        val r = try {
            d.await()
        } catch (e: CancellationException) {
            currentCoroutineContext().ensureActive()
            null
        }
        if (r == null) plans.remove(key, d)
        return r
    }

    /**
     * Restored segmentPlan: translates page in aligned segments so original PDF text
     * can be highlighted during translated audio playback.
     */
    private suspend fun segmentPlan(uri: String, page: Int, s: ReadingSettings, text: String): Plan? {
        val spoken = text.lines().filterNot { it.trimStart().startsWith("|") }.joinToString("\n")
        val paragraphs = spoken.split(Regex("\\n\\s*\\n")).map { plainForSpeech(it).trim() }.filter { it.isNotBlank() }
        val flat = ArrayList<String>()
        val paraOf = ArrayList<List<Int>>()
        for (p in paragraphs) {
            val ids = ArrayList<Int>()
            for (sentence in splitSentences(p)) { ids += flat.size; flat += sentence }
            if (ids.isNotEmpty()) paraOf += ids
        }
        if (flat.size < 2) return null
        val map = textEngine.mapSentences(uri, page, flat) ?: return null
        if (map.rects.count { it.isNotEmpty() } * 100 < flat.size * 60) return null
        val units: List<List<Int>> = if (paraOf.size >= 2) paraOf else groupSegments(flat)
        val segments = units.map { g -> g.joinToString(" ") { flat[it] } }
        if (page == _state.value.page) _state.update { it.copy(status = "در حال ترجمه‌ی پاراگراف‌به‌پاراگراف…") }
        val segResult = texts.translateSegments(uri, page, s, segments)
        val items = segResult.items
        if (items == null) {
            // Fallback: whole-page translation without perfect segment alignment (still better than failing the page)
            if (page == _state.value.page) {
                _state.update { it.copy(status = "ترجمه‌ی قطعه‌ای ناموفق؛ در حال ترجمه‌ی یک‌جا…") }
            }
            return null // let the caller fall through to non-segmented path
        }
        val spokenSentences = ArrayList<String>()
        val spokenRects = ArrayList<List<NRect>>()
        for ((k, item) in items.withIndex()) {
            val origIds = units.getOrNull(k).orEmpty()
            val sents = splitSentences(plainForSpeech(item))
            // Paragraph-level alignment: union of all original sentence rects in the segment.
            // Proportional 1:1 mapping is unreliable when translation merges/splits sentences.
            val paraRects: List<NRect> = origIds.flatMap { id -> map.rects.getOrNull(id).orEmpty() }
                .distinct()
            for (sentence in sents) {
                spokenSentences += sentence
                spokenRects += paraRects
            }
        }
        if (spokenSentences.isEmpty()) return null
        // Store joined translation under the normal TRANSLATE cache so a later
        // "ترجمه" button reuses it and does not spend tokens again.
        try {
            val joined = items.joinToString("\n\n")
            if (joined.isNotBlank()) texts.saveTranslation(uri, page, s, joined, text)
        } catch (_: Exception) { }
        return Plan(page, spokenSentences, buildChunks(spokenSentences), s.targetLanguage in RTL_LANGS, spokenRects, null)
    }

    private fun groupSegments(sents: List<String>): List<List<Int>> {
        val out = ArrayList<List<Int>>()
        var cur = ArrayList<Int>()
        var len = 0
        for (i in sents.indices) {
            val l = sents[i].length
            if (cur.isNotEmpty() && (len >= 140 || len + l > 360)) {
                out += cur
                cur = ArrayList()
                len = 0
            }
            cur += i
            len += l + 1
        }
        if (cur.isNotEmpty()) {
            if (len < 60 && out.isNotEmpty()) out[out.size - 1] = out.last() + cur else out += cur
        }
        return out
    }

    private suspend fun buildPlan(d: PdfDocument?, uri: String, m: ReadMode, page: Int): Plan? {
        if (d == null) return null
        val s = settings.state.value

        val ex = texts.extract(d, uri, page, s) { phase ->
            if (page == _state.value.page) _state.update { it.copy(status = phase) }
        }
        var text = when (ex) {
            is PT.Ok -> ex.text
            PT.NoText -> return Plan(page, emptyList(), emptyList(), false)
            is PT.Fail -> { failFor(page, ex.message); return null }
        }

        // 1) Prefer an already-saved full-page translation to avoid extra token spend
        val existingTranslation = if (m == ReadMode.TRANSLATE_AUDIO) texts.cached(AiTask.TRANSLATE, uri, page, s) else null
        val hasExistingTranslation = existingTranslation != null && existingTranslation.text.isNotBlank()

        // 2) Only attempt expensive paragraph-aligned translation when:
        //    - we want PDF highlighting AND
        //    - no full-page translation exists yet (otherwise we would burn tokens again)
        if (m == ReadMode.TRANSLATE_AUDIO && s.highlightPdf && s.sourceLanguage != s.targetLanguage && !hasExistingTranslation) {
            val aligned = try {
                segmentPlan(uri, page, s, text)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            if (aligned != null && aligned.sentences.isNotEmpty()) {
                return aligned
            }
            // fall through to whole-page translation if segment alignment fails
        }

        // Section 2-1: Content-based cache key
        val planKey = sha256("plan_v8|$uri|$page|${m.name}|${s.translationEngine}|${s.sourceLanguage}|${s.targetLanguage}|${s.profile.name}|${if (s.profile == ReadingProfile.CUSTOM) s.customInstruction else ""}|${sha256(text)}")
        val cached = texts.cachedText(planKey)
        var rtl: Boolean
        if (cached != null) {
            if (cached == NO_TEXT_MARK) return Plan(page, emptyList(), emptyList(), false)
            text = cached
            rtl = if (m == ReadMode.TRANSLATE_AUDIO) s.targetLanguage in RTL_LANGS else isRtlText(text)
        } else {
            if (hasExistingTranslation) {
                text = existingTranslation!!.text
                rtl = s.targetLanguage in RTL_LANGS
                if (page == _state.value.page) {
                    _state.update { it.copy(status = "استفاده از ترجمه‌ی قبلی صفحه (بدون مصرف توکن اضافه)…") }
                }
            } else {
                rtl = isRtlText(text)
                if (m == ReadMode.TRANSLATE_AUDIO && s.sourceLanguage != s.targetLanguage) {
                    if (page == _state.value.page) _state.update { it.copy(status = "در حال ترجمه برای تولید صدا…") }
                    when (val tr = texts.process(AiTask.TRANSLATE, uri, page, s, text)) {
                        is PT.Ok -> text = tr.text
                        is PT.Fail -> { failFor(page, tr.message); return null }
                        PT.NoText -> return Plan(page, emptyList(), emptyList(), false)
                    }
                    rtl = s.targetLanguage in RTL_LANGS
                }
            }
            texts.saveText(planKey, text)
        }

        val spoken = text.lines().filterNot { it.trimStart().startsWith("|") }.joinToString("\n")
        val sentences = splitSentences(plainForSpeech(spoken))
        var rects: List<List<NRect>>? = null
        var ranges: List<IntRange?>? = null
        val chars: PageChars? = null
        var note: String? = null
        if (m == ReadMode.ORIGINAL && s.highlightPdf && sentences.isNotEmpty()) {
            val map = textEngine.mapSentences(uri, page, sentences)
            if (map == null) note = textEngine.lastError
            else {
                rects = map.rects
                ranges = map.ranges
            }
        }
        return Plan(page, sentences, buildChunks(sentences), rtl, rects, note, ranges, chars)
    }

    /**
     * Section 2-4: Time-based prefetching
     * Keeps ~40-60s of ready audio ahead of playback position.
     * Stops immediately when paused or when user navigates >3 pages away.
     */
    private fun startPrefetch(pl: Plan) {
        bgJob?.cancel()
        if (settings.state.value.ttsEngine == "system") return  // edge is free — allow short ahead buffer
        bgJob = scope.launch {
            // Only ~1–2 chunks (~15–20s) ahead. The old 90s + next-page prefetch burned tokens.
            val targetAhead = 18_000L
            var ci = chunkIndex + 1
            var prepared = 0
            while (isActive && _state.value.playing && ci < pl.chunks.size && prepared < 2) {
                if (aheadMs() >= targetAhead) break
                val nextChunk = pl.chunks[ci]
                if (nextChunk.file == null) {
                    if (!ensureWithRetry(nextChunk)) break
                    prepared++
                }
                ci++
            }
            // Do NOT pre-synthesize the next page — major token sink.
            withContext(Dispatchers.Main) {
                maybePreload()
            }
        }
    }

    private suspend fun ensureWithRetry(c: Chunk): Boolean {
        var wait = 2_000L
        for (attempt in 0 until 2) {
            if (ensureChunk(c) != null) return true
            if (attempt < 1) {
                delay(wait)
                wait = (wait * 2).coerceAtMost(6_000L)
            }
        }
        return false
    }

    private fun aheadMs(): Long {
        val pl = plan ?: return 0
        var ms = 0L
        for (i in chunkIndex + 1 until pl.chunks.size) {
            val c = pl.chunks[i]
            if (c.file == null) return ms
            ms += c.durationMs
        }
        nextPlanReady?.let { np ->
            for (c in np.chunks) {
                if (c.file == null) break
                ms += c.durationMs
            }
        }
        return ms
    }

    // ------------------------------------------------------------------ audio generation

    private suspend fun ensureChunk(c: Chunk): File? {
        c.file?.let { return it }
        // Stop cancels via active=false + generation bump. Do NOT require playing=true:
        // first chunk is synthesized before the player sets playing (otherwise TTS always fails).
        if (!_state.value.active) return null
        val gen = generation
        val st = settings.state.value
        val voice = if (st.ttsEngine == "edge" || st.ttsEngine == "edge_tts") {
            resolveEdgeVoice(c.text)
        } else st.voice
        val key = sha256("tts|v4|${st.ttsEngine}|$voice|${c.text}")
        val f = File(ttsDir, "$key.p.wav")
        val legacy = File(ttsDir, "$key.wav")
        val ready: File? = when {
            f.exists() && f.length() > 44 -> f
            legacy.exists() && legacy.length() > 44 -> withContext(Dispatchers.IO) { upgradeLegacy(legacy, f) }
            else -> {
                val job = inflight.getOrPut(key) {
                    scope.async(Dispatchers.IO) {
                        try {
                            if (!_state.value.active || gen != generation) null
                            else synthesizeTo(c.text, f, voice)
                        } finally {
                            inflight.remove(key)
                        }
                    }
                }
                val result = job.await()
                if (gen != generation || !_state.value.active) null else result
            }
        }
        if (ready != null) {
            analyse(c, ready)
            trimAudioCacheIfNeeded()
        }
        return ready
    }

    /** Keep on-device TTS cache under ~80 MB by deleting oldest files. */
    private fun trimAudioCacheIfNeeded() {
        val maxBytes = 80L * 1024 * 1024
        val files = ttsDir.listFiles()?.filter { it.isFile }?.sortedBy { it.lastModified() } ?: return
        var total = files.sumOf { it.length() }
        if (total <= maxBytes) return
        for (f in files) {
            if (total <= maxBytes) break
            val len = f.length()
            if (f.delete()) total -= len
        }
    }

    private suspend fun analyse(c: Chunk, f: File) = withContext(Dispatchers.IO) {
        val bytes = try { f.readBytes() } catch (e: Exception) { null }
        if (bytes != null && bytes.size > 44 && isWavHeader(bytes)) {
            val dur = Wav.durationMs(bytes)
            c.durationMs = dur
            c.starts = try { SentenceTiming.align(c.lens, dur, Wav.pauses(bytes)) } catch (e: Exception) { null }
        } else {
            // MP3 (Edge-TTS) or unknown: duration via MediaMetadataRetriever / MediaPlayer, no WAV pause parse
            c.durationMs = audioDurationMs(f).takeIf { it > 0 } ?: estimateDurationFromText(c)
            c.starts = try { SentenceTiming.align(c.lens, c.durationMs, emptyList()) } catch (e: Exception) { null }
        }
        c.file = f
    }

    private fun isWavHeader(b: ByteArray): Boolean =
        b.size >= 12 && b[0] == 'R'.code.toByte() && b[1] == 'I'.code.toByte() &&
            b[2] == 'F'.code.toByte() && b[3] == 'F'.code.toByte()

    private fun audioDurationMs(f: File): Long = try {
        val r = android.media.MediaMetadataRetriever()
        r.setDataSource(f.absolutePath)
        val ms = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        r.release()
        ms
    } catch (e: Exception) {
        try {
            val mp = MediaPlayer()
            mp.setDataSource(f.absolutePath)
            mp.prepare()
            val d = mp.duration.toLong().coerceAtLeast(0)
            mp.release()
            d
        } catch (e2: Exception) { 0L }
    }

    private fun estimateDurationFromText(c: Chunk): Long {
        val chars = c.text.length.coerceAtLeast(1)
        // ~14 chars/sec speech average
        return (chars * 1000L / 14).coerceIn(800L, 120_000L)
    }

    private fun upgradeLegacy(legacy: File, target: File): File = try {
        val polished = Wav.polish(legacy.readBytes())
        val tmp = File(target.parentFile, target.name + ".tmp")
        tmp.writeBytes(polished)
        if (tmp.renameTo(target)) { legacy.delete(); target } else legacy
    } catch (e: Exception) {
        legacy
    }

    private suspend fun synthesizeTo(text: String, f: File, voice: String): File? {
        return try {
            val audio = synth(text, voice) ?: return null
            val tmp = File(f.parentFile, f.name + ".tmp")
            // Edge-TTS returns MP3; Gemini path returns WAV/PCM→WAV. MediaPlayer plays both.
            val isMp3 = audio.size >= 3 && (
                (audio[0] == 0xFF.toByte() && (audio[1].toInt() and 0xE0) == 0xE0) ||
                    (audio[0] == 'I'.code.toByte() && audio[1] == 'D'.code.toByte() && audio[2] == '3'.code.toByte())
            )
            val isWav = audio.size >= 4 &&
                audio[0] == 'R'.code.toByte() && audio[1] == 'I'.code.toByte() &&
                audio[2] == 'F'.code.toByte() && audio[3] == 'F'.code.toByte()
            tmp.writeBytes(if (isMp3) audio else if (isWav) Wav.polish(audio) else Wav.polish(audio))
            if (tmp.renameTo(f)) f else null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            lastSynthError = "ذخیره‌ی صدا ممکن نشد: " + (e.message ?: e.javaClass.simpleName)
            null
        }
    }

    /**
     * Edge voice by language:
     * - خواندن با ترجمه → زبان مقصد (targetLanguage)
     * - خواندن عادی → sourceLanguage اگر auto نباشد، وگرنه تشخیص از خود متن
     * جنسیت از تنظیم edgeVoice (دلارا/فرید) فقط به‌عنوان ترجیح.
     */
    private fun resolveEdgeVoice(spokenText: String): String {
        val s = settings.state.value
        val lang = when (mode) {
            ReadMode.TRANSLATE_AUDIO -> s.targetLanguage.ifBlank { "fa" }
            ReadMode.ORIGINAL -> when {
                s.sourceLanguage.isNotBlank() && s.sourceLanguage != "auto" -> s.sourceLanguage
                else -> EdgeTts.detectLang(spokenText)
            }
        }
        return EdgeTts.voiceFor(lang, s.edgeVoice.ifBlank { "fa-IR-DilaraNeural" })
    }

    private suspend fun synth(text: String, voice: String): ByteArray? {
        val s = settings.state.value
        val engine = s.ttsEngine
        // Online engines only: edge (default) → optional Gemini fallback
        if (engine == "edge" || engine == "edge_tts") {
            try {
                val edgeVoice = resolveEdgeVoice(text)
                val bytes = EdgeTts.synthesize(text, edgeVoice)
                if (bytes.isNotEmpty()) return bytes
                lastSynthError = "Edge-TTS: empty audio"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                lastSynthError = when {
                    (e.message ?: "").contains("403") ->
                        "Edge-TTS موقتاً مسدود شد (403). اگر کلید Gemini دارید fallback را روشن کنید یا Gemini TTS را انتخاب کنید."
                    else -> e.message ?: "Edge-TTS failed"
                }
                if (!s.ttsFallbackGemini) return null
                // fall through to Gemini
            }
            if (s.ttsFallbackGemini) {
                val o = router.synthesize(text, voice, "")
                if (o is AiRouter.Outcome.Ok && o.audio != null && o.audio!!.isNotEmpty()) return o.audio
                if (o is AiRouter.Outcome.Failed) {
                    lastSynthError = (lastSynthError ?: "") + " | Gemini: " + texts.describe(o)
                }
                return null
            }
            return null
        }
        // gemini (or any other): use AI TTS only — no auto-switch to Edge unless user chose edge
        val o = router.synthesize(text, voice, "")
        if (o is AiRouter.Outcome.Failed) {
            lastSynthError = texts.describe(o)
            return null
        }
        return (o as AiRouter.Outcome.Ok).audio
    }

    // ------------------------------------------------------------------ playback

    private fun chunkOfSentence(pl: Plan, sentence: Int): Int =
        pl.chunks.indexOfFirst { sentence in it.first..it.last }.coerceAtLeast(0)

    private fun playChunkAt(ci: Int, startSentence: Int? = null, startMs: Int = 0) {
        val pl = plan ?: return
        val chunk = pl.chunks.getOrNull(ci) ?: return
        val gen = ++generation
        chunkIndex = ci
        ticker?.cancel()
        discardPreloaded()
        lastWord = null
        playJob?.cancel()

        if (settings.state.value.ttsEngine == "system") {
            ensureSystemTts { playSystemSentence(startSentence ?: chunk.first) }
            return
        }

        playJob = scope.launch {
            try {
                if (chunk.file == null) _state.update { it.copy(status = "در حال تولید صدای Gemini…", error = null) }
                val f = ensureChunk(chunk)
                if (gen != generation || !_state.value.active) return@launch
                if (f == null) {
                    val err = lastSynthError.ifBlank { "تولید صدا ممکن نشد. لطفاً اتصال اینترنت یا کلید Gemini را بررسی کنید." }
                    fail(err)
                    return@launch
                }
                var offset = startMs
                if (startSentence != null && startSentence in chunk.first..chunk.last) {
                    val st = chunk.starts
                    val k = startSentence - chunk.first
                    offset = if (st != null && k in st.indices) {
                        st[k].toInt()
                    } else {
                        val total = (chunk.first..chunk.last).sumOf { pl.sentences[it].length + 1 }.coerceAtLeast(1)
                        val before = (chunk.first until startSentence).sumOf { pl.sentences[it].length + 1 }
                        (chunk.durationMs * before / total).toInt()
                    }
                }
                startPrefetch(pl)
                startPlayer(f, ci, offset, gen, startSentence ?: chunk.first)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (gen == generation) fail("پخش صدا ممکن نشد: " + (e.message ?: e.javaClass.simpleName))
            }
        }
    }

    private fun newPlayer(f: File): MediaPlayer {
        val mp = MediaPlayer()
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            mp.setDataSource(f.absolutePath)
            if (speed != 1f && Build.VERSION.SDK_INT >= 23) {
                try { mp.playbackParams = PlaybackParams().setSpeed(speed) } catch (e: Exception) {}
            }
        } catch (e: Exception) {
            try { mp.release() } catch (ignored: Exception) {}
            throw e
        }
        return mp
    }

    private fun startPlayer(f: File, ci: Int, offsetMs: Int, gen: Int, initialSentence: Int = -1) {
        releasePlayer()
        val mp = try {
            newPlayer(f)
        } catch (e: Exception) {
            fail("پخش صدا ممکن نشد.")
            return
        }
        var prepared = false
        try {
            mp.setOnPreparedListener { p ->
                prepared = true
                if (gen != generation) {
                    try { p.release() } catch (ignored: Exception) {}
                    return@setOnPreparedListener
                }
                if (needsSpeed(p)) applySpeed(p)
                if (offsetMs > 0) p.seekTo(offsetMs)
                p.start()
                val pl = plan
                val c = pl?.chunks?.getOrNull(ci)
                val currentSent = if (initialSentence >= 0) initialSentence else (c?.first ?: 0)
                _state.update {
                    it.copy(
                        playing = true,
                        status = null,
                        error = null,
                        sentenceIndex = currentSent,
                        highlight = pl?.rects?.getOrNull(currentSent).orEmpty(),
                    )
                }
                startTicker(gen)
            }
            mp.setOnCompletionListener { onChunkDone(ci) }
            mp.setOnErrorListener { _, _, _ ->
                if (gen == generation) fail("خطا در پخش فایل صوتی.")
                true
            }
            player = mp
            mp.prepareAsync()
        } catch (e: Exception) {
            if (!prepared) try { mp.release() } catch (ignored: Exception) {}
            fail("آماده‌سازی پخش ناموفق بود.")
        }
    }

    private fun maybePreload() {
        if (preloaded != null) return
        val pl = plan ?: return
        val nextCi = chunkIndex + 1
        val targetPlan = if (nextCi < pl.chunks.size) pl else nextPlanReady
        val targetCi = if (nextCi < pl.chunks.size) nextCi else 0
        if (targetPlan == null) return
        val nextChunk = targetPlan.chunks.getOrNull(targetCi) ?: return
        val f = nextChunk.file ?: return
        if (!f.exists() || f.length() <= 44) return

        val mp = try { newPlayer(f) } catch (e: Exception) { return }
        val holder = Preloaded(targetCi, mp, targetPlan)
        preloaded = holder
        mp.setOnPreparedListener { holder.ready = true }
        mp.setOnErrorListener { _, _, _ ->
            discardPreloaded()
            true
        }
        try { mp.prepareAsync() } catch (e: Exception) { discardPreloaded() }
    }

    private fun discardPreloaded() {
        preloaded?.let {
            try { it.mp.release() } catch (ignored: Exception) {}
        }
        preloaded = null
    }

    private fun onChunkDone(ci: Int) {
        try {
            val pl = plan ?: return
            if (ci + 1 < pl.chunks.size) {
                val nextCi = ci + 1
                chunkIndex = nextCi
                val pre = preloaded
                if (pre != null && pre.ci == nextCi && pre.ready && pre.plan === pl) {
                    handoverTo(pre)
                } else {
                    discardPreloaded()
                    playChunkAt(nextCi)
                }
            } else {
                onPageDone()
            }
        } catch (e: Exception) {
            // Avoid leaving the player in a broken state; try to recover to next page or stop
            try {
                discardPreloaded()
                releasePlayer()
            } catch (_: Exception) {}
            fail("خطا در جابجایی به قطعه بعدی. دوباره پخش را شروع کنید.")
        }
    }

    private fun handoverTo(pre: Preloaded) {
        val targetPlayer = pre.mp
        preloaded = null // Critical: detach first so releasing old player doesn't kill preloaded
        try {
            val gen = ++generation
            player?.let { try { it.release() } catch (ignored: Exception) {} }
            player = targetPlayer
            val p = targetPlayer
            val c = pre.plan.chunks.getOrNull(pre.ci) ?: run {
                releasePlayer()
                return
            }
            chunkIndex = pre.ci
            p.setOnCompletionListener { onChunkDone(pre.ci) }
            p.setOnErrorListener { _, _, _ ->
                if (gen == generation) fail("خطا در پخش فایل صوتی.")
                true
            }
            if (needsSpeed(p)) applySpeed(p)
            p.start()
            _state.update {
                it.copy(
                    playing = true,
                    status = null,
                    error = null,
                    sentenceIndex = c.first,
                    highlight = pre.plan.rects?.getOrNull(c.first).orEmpty(),
                )
            }
            startTicker(gen)
            startPrefetch(pre.plan)
        } catch (e: Exception) {
            // Gracefully fall back to regular playback without disrupting the user
            try { targetPlayer.release() } catch (ignored: Exception) {}
            player = null
            playChunkAt(pre.ci)
        }
    }

    private fun onPageDone() {
        val d = doc ?: return
        val nextPage = _state.value.page + 1
        if (nextPage < d.pageCount) {
            scope.launch { openPage(nextPage, 0) }
        } else {
            stop()
        }
    }

    private fun needsSpeed(p: MediaPlayer): Boolean =
        speed != 1f && Build.VERSION.SDK_INT >= 23 && p.playbackParams?.speed != speed

    private fun applySpeed(p: MediaPlayer) {
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                p.playbackParams = PlaybackParams().setSpeed(speed)
            } catch (e: Exception) {}
        }
    }

    private fun startTicker(gen: Int) {
        ticker?.cancel()
        ticker = scope.launch {
            while (isActive && gen == generation) {
                updateProgress()
                maybePreload()
                delay(100)
            }
        }
    }

    private fun updateProgress() {
        try {
            val pl = plan ?: return
            val p = player ?: return
            val c = pl.chunks.getOrNull(chunkIndex) ?: return
            val pos = try { p.currentPosition.toLong() } catch (e: Exception) { return }
            val dur = if (c.durationMs > 0) c.durationMs else try { p.duration.toLong() } catch (e: Exception) { 0L }
            val maxSentIdx = pl.sentences.lastIndex.coerceAtLeast(0)
            var idx = c.first.coerceIn(0, maxSentIdx)
            val st = c.starts
            if (st != null && st.size == c.last - c.first + 1) {
                val t = pos + 120
                for (i in st.indices) {
                    if (st[i] <= t) idx = (c.first + i).coerceIn(0, maxSentIdx) else break
                }
            } else {
                val safeFirst = c.first.coerceIn(0, maxSentIdx)
                val safeLast = c.last.coerceIn(safeFirst, maxSentIdx)
                val total = (safeFirst..safeLast).sumOf { pl.sentences.getOrNull(it)?.length?.plus(1) ?: 1 }.coerceAtLeast(1)
                val frac = if (dur > 0) (pos.toDouble() / dur).let { if (it.isNaN() || it.isInfinite()) 0.0 else it.coerceIn(0.0, 1.0) } else 0.0
                var acc = 0
                for (i in safeFirst..safeLast) {
                    acc += (pl.sentences.getOrNull(i)?.length ?: 0) + 1
                    idx = i
                    if (acc.toDouble() / total >= frac) break
                }
            }
            val before = pl.chunks.take(chunkIndex).sumOf { estimateMs(it) }
            val all = pl.chunks.sumOf { estimateMs(it) }
            val hl = if (idx != _state.value.sentenceIndex) pl.rects?.getOrNull(idx).orEmpty() else null
            val word = currentWord(pl, c, idx, pos)
            val wordRects: List<NRect>? = if (word != lastWord) {
                lastWord = word
                if (word == null) emptyList() else pl.chars?.let { TextPick.rects(it, word.first, word.last) } ?: emptyList()
            } else null
            val ahead = aheadMs()
            _state.update {
                it.copy(
                    sentenceIndex = idx, positionMs = before + pos, durationMs = maxOf(all, before + dur),
                    highlight = hl ?: it.highlight, wordHighlight = wordRects ?: it.wordHighlight, aheadMs = ahead,
                )
            }
        } catch (ignored: Throwable) {}
    }

    private fun currentWord(pl: Plan, c: Chunk, idx: Int, posMs: Long): IntRange? {
        val chars = pl.chars ?: return null
        val range = pl.ranges?.getOrNull(idx) ?: return null
        val st = c.starts ?: return null
        val k = idx - c.first
        if (k !in st.indices) return null
        val from = st[k]
        val to = if (k + 1 < st.size) st[k + 1] else (c.durationMs - 100).coerceAtLeast(from + 200)
        val text = chars.text
        val words = ArrayList<IntRange>()
        var i = range.first.coerceAtLeast(0)
        val end = minOf(range.last, text.length - 1)
        while (i <= end) {
            while (i <= end && text[i].isWhitespace()) i++
            val ws = i
            while (i <= end && !text[i].isWhitespace()) i++
            if (i > ws) words += ws until i
        }
        if (words.isEmpty()) return null
        val total = words.sumOf { it.last - it.first + 2 }
        val denom = (to - from).coerceAtLeast(1)
        val rawFrac = (posMs + 120 - from).toDouble() / denom
        val frac = if (rawFrac.isNaN() || rawFrac.isInfinite()) 0.0 else rawFrac.coerceIn(0.0, 0.999)
        var acc = 0
        for (w in words) {
            acc += w.last - w.first + 2
            if (acc.toDouble() / total > frac) return w
        }
        return words.last()
    }

    private fun estimateMs(c: Chunk): Long = if (c.durationMs > 0) c.durationMs else c.text.length * 70L

    private fun fail(message: String) {
        ticker?.cancel()
        try { player?.pause() } catch (e: Exception) {}
        try { systemTts?.stop() } catch (e: Exception) {}
        _state.update { it.copy(error = message, playing = false, status = null) }
    }

    private fun failFor(page: Int, message: String) {
        if (page == _state.value.page) fail(message)
    }

    private fun releasePlayer() {
        discardPreloaded()
        player?.let { try { it.release() } catch (e: Exception) {} }
        player = null
    }

    // ------------------------------------------------------------------ text helpers

    private val ABBREVS = setOf(
        "fig", "figs", "figure", "figures", "eq", "eqs", "equation", "ref", "refs",
        "al", "et al", "eg", "e.g", "ie", "i.e", "vs", "dr", "mr", "mrs", "ms",
        "prof", "dept", "sec", "secs", "section", "approx", "no", "nos", "vol",
        "pp", "p", "ch", "chap", "app", "inc", "ltd", "corp", "co"
    )

    private fun isAbbreviation(word: String): Boolean {
        val clean = word.lowercase().trim().removeSuffix(".")
        return clean in ABBREVS || (clean.length == 1 && clean[0].isLetter())
    }

    private fun splitSentences(t: String): List<String> {
        val paragraphs = t.split(Regex("\\n+")).map { it.trim() }.filter { it.isNotEmpty() }
        val out = ArrayList<String>()
        for (para in paragraphs) {
            val n = para.length
            var start = 0
            var i = 0
            while (i < n) {
                val ch = para[i]
                if (ch == '.' || ch == '!' || ch == '?' || ch == '؟' || ch == '۔' || ch == '…') {
                    val nextChar = if (i + 1 < n) para[i + 1] else ' '
                    if (ch == '.' && nextChar.isDigit()) {
                        i++
                        continue
                    }
                    if (ch == '.') {
                        val prevSpace = para.lastIndexOf(' ', i - 1).coerceAtLeast(start)
                        val wordBefore = para.substring(prevSpace, i).trim()
                        if (isAbbreviation(wordBefore)) {
                            i++
                            continue
                        }
                    }
                    var j = i + 1
                    while (j < n && (para[j] == ' ' || para[j] == '\t' || para[j] == '"' || para[j] == '»' || para[j] == '”' || para[j] == ')')) {
                        j++
                    }
                    if (j == n) {
                        val s = para.substring(start, n).trim()
                        if (s.isNotEmpty()) out += s
                        start = n
                        break
                    } else if (j > i + 1) {
                        val next = para[j]
                        if (next.isUpperCase() || next in '\u0600'..'\u06FF' || next in "«\"“‘'([•-*" || next.isDigit()) {
                            val s = para.substring(start, j).trim()
                            if (s.isNotEmpty()) out += s
                            start = j
                            i = j - 1
                        }
                    }
                }
                i++
            }
            if (start < n) {
                val s = para.substring(start, n).trim()
                if (s.isNotEmpty()) out += s
            }
        }
        return out
    }

    private fun buildChunks(sentences: List<String>): List<Chunk> {
        val out = mutableListOf<Chunk>()
        var i = 0
        while (i < sentences.size) {
            var text = sentences[i]
            val start = i
            val targetLen = if (out.isEmpty()) 110 else 280
            while (i + 1 < sentences.size) {
                val nextLen = sentences[i + 1].length
                if (text.length >= targetLen && text.any { it.isLetter() }) break
                if (text.length >= 70 && text.length + nextLen > 380) break
                i++
                text = "$text ${sentences[i]}"
            }
            val end = i
            out += Chunk(text, start, end, IntArray(end - start + 1) { sentences[start + it].length })
            i++
        }
        return out
    }

    private fun isRtlText(s: String): Boolean {
        var rtl = 0
        var ltr = 0
        for (ch in s) {
            when (Character.getDirectionality(ch)) {
                Character.DIRECTIONALITY_RIGHT_TO_LEFT, Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC -> rtl++
                Character.DIRECTIONALITY_LEFT_TO_RIGHT -> ltr++
                else -> {}
            }
        }
        return rtl > 0 && rtl >= ltr
    }

    private fun wavDurationMs(f: File): Long = try {
        f.inputStream().use { ins ->
            val h = ByteArray(44)
            if (ins.read(h) < 44) 0L else {
                val byteRate = ByteBuffer.wrap(h, 28, 4).order(ByteOrder.LITTLE_ENDIAN).int
                if (byteRate > 0) (f.length() - 44) * 1000L / byteRate else 0L
            }
        }
    } catch (e: Exception) { 0L }
}
