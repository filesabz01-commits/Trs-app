package app.pdfreader.tts

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import app.pdfreader.ai.AiRouter
import app.pdfreader.ai.AiTask
import app.pdfreader.ai.PT
import app.pdfreader.ai.PageTextService
import app.pdfreader.ai.RTL_LANGS
import app.pdfreader.ai.SettingsRepo
import app.pdfreader.ai.Wav
import app.pdfreader.ai.plainForSpeech
import app.pdfreader.ai.sha256
import app.pdfreader.core.pdf.PdfDocument
import app.pdfreader.ui.TextPick
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap

private const val PLAN_TIMEOUT_MS = 420_000L

enum class ReadMode { ORIGINAL, TRANSLATE_AUDIO }

data class ReadState(
    val active: Boolean = false,
    val page: Int = 0,
    val mode: ReadMode = ReadMode.ORIGINAL,
    val sentences: List<String> = emptyList(),
    val sentenceIndex: Int = -1,
    val playing: Boolean = false,
    val status: String? = null,
    val error: String? = null,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val speed: Float = 1f,
    val rtl: Boolean = false,
    val highlight: List<NRect> = emptyList(),
    val highlightPossible: Boolean = false,
    val highlightNote: String? = null,
    /** The word being spoken (lighter sentence highlight is in [highlight]). */
    val wordHighlight: List<NRect> = emptyList(),
    /** How much audio is already generated and waiting after the current chunk (ms). */
    val aheadMs: Long = 0,
)

private class Chunk(val text: String, val first: Int, val last: Int, val lens: IntArray) {
    @Volatile var file: File? = null
    @Volatile var durationMs: Long = 0
    /** Start of every sentence of this chunk inside its audio (ms), measured from the real pauses of the voice. */
    @Volatile var starts: LongArray? = null
}

/** The next chunk's player, already prepared while the current one is still speaking (gap-free hand-over). */
private class Preloaded(val ci: Int, val mp: MediaPlayer, val plan: Plan) {
    @Volatile var ready = false
}

private class Plan(
    val page: Int,
    val sentences: List<String>,
    val chunks: List<Chunk>,
    val rtl: Boolean,
    val rects: List<List<NRect>>? = null,
    val note: String? = null,
    val ranges: List<IntRange?>? = null,
    val chars: PageChars? = null,
)

/**
 * Read Aloud:
 *  - ORIGINAL: extract/clean the page text and read it as it is (English or Persian book, no translation)
 *  - TRANSLATE_AUDIO: extract, translate (only to produce the voice, shown only in the sentence list), read
 * The next page is prepared in the background while the current page plays. Audio files are kept permanently
 * until the user clears the cache. Playback uses MediaPlayer inside the app (no background service yet).
 */
class ReadAloudController(
    context: Context,
    private val router: AiRouter,
    private val texts: PageTextService,
    private val settings: SettingsRepo,
    private val textEngine: PdfiumTextEngine,
) {
    private val ctx = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val _state = MutableStateFlow(ReadState())
    val state: StateFlow<ReadState> = _state.asStateFlow()

    private val ttsDir = File(ctx.filesDir, "tts").also { it.mkdirs() }
    private val inflight = ConcurrentHashMap<String, Deferred<File?>>()
    private val plans = HashMap<String, Deferred<Plan?>>() // main thread only
    private var preloaded: Preloaded? = null
    private var nextPlanReady: Plan? = null
    private var lastWord: IntRange? = null

    private var doc: PdfDocument? = null
    private var docUri = ""
    private var mode = ReadMode.ORIGINAL
    private var plan: Plan? = null
    private var chunkIndex = 0
    private var player: MediaPlayer? = null
    private var ticker: Job? = null
    private var bgJob: Job? = null
    private var startJob: Job? = null
    private var speed = 1f
    private var generation = 0
    @Volatile private var lastSynthError = ""

    // ------------------------------------------------------------------ public API

    fun start(doc: PdfDocument, docUri: String, page: Int, mode: ReadMode) {
        stop()
        this.doc = doc
        this.docUri = docUri
        this.mode = mode
        _state.value = ReadState(active = true, page = page, mode = mode, status = "در حال آماده‌سازی…", speed = speed)
        startJob = scope.launch { openPage(page, 0) }
    }

    fun toggle() {
        val st = _state.value
        if (!st.active) return
        val p = player
        if (st.error != null || p == null) {
            _state.update { it.copy(error = null) }
            val ci = plan?.let { pl -> pl.chunks.indexOfFirst { c -> st.sentenceIndex in c.first..c.last } }
            if (plan != null && ci != null && ci >= 0) playChunkAt(ci, st.sentenceIndex.coerceAtLeast(0))
            else {
                startJob?.cancel()
                startJob = scope.launch { openPage(st.page, st.sentenceIndex.coerceAtLeast(0)) }
            }
            return
        }
        try {
            if (p.isPlaying) {
                p.pause()
                ticker?.cancel()
                _state.update { it.copy(playing = false) }
            } else {
                p.start()
                _state.update { it.copy(playing = true) }
                startTicker(generation)
            }
        } catch (e: IllegalStateException) {
            // player is being replaced; ignore
        }
    }

    fun seekBy(deltaMs: Int) {
        val p = player ?: return
        val pl = plan ?: return
        val c = pl.chunks.getOrNull(chunkIndex) ?: return
        try {
            val target = p.currentPosition + deltaMs
            val dur = if (c.durationMs > 0) c.durationMs.toInt() else p.duration
            when {
                target < 0 -> if (chunkIndex > 0) {
                    val prev = pl.chunks[chunkIndex - 1]
                    playChunkAt(chunkIndex - 1, startMs = (prev.durationMs + target).toInt().coerceAtLeast(0))
                } else p.seekTo(0)
                target >= dur -> onChunkDone(chunkIndex)
                else -> p.seekTo(target)
            }
        } catch (e: IllegalStateException) {
            // ignore
        }
    }

    fun jumpSentence(delta: Int) {
        val pl = plan ?: return
        val target = _state.value.sentenceIndex.coerceAtLeast(0) + delta
        when {
            target < 0 -> playChunkAt(0, 0)
            target >= pl.sentences.size -> onChunkDone(pl.chunks.size - 1)
            else -> playChunkAt(chunkOfSentence(pl, target), target)
        }
    }

    fun seekToFraction(f: Float) {
        val pl = plan ?: return
        val total = pl.chunks.sumOf { estimateMs(it) }
        var remaining = (total * f).toLong()
        for ((i, c) in pl.chunks.withIndex()) {
            val d = estimateMs(c)
            if (remaining < d || i == pl.chunks.lastIndex) {
                playChunkAt(i, startMs = remaining.coerceAtMost(d).toInt())
                return
            }
            remaining -= d
        }
    }

    fun setSpeed(v: Float) {
        speed = v
        discardPreloaded()
        _state.update { it.copy(speed = v) }
        player?.let { p ->
            try {
                val was = p.isPlaying
                applySpeed(p)
                if (!was) p.pause() // setting the rate on a paused player would resume it
            } catch (e: IllegalStateException) {
                // ignore
            }
        }
    }

    fun stop() {
        generation++
        startJob?.cancel()
        bgJob?.cancel()
        ticker?.cancel()
        releasePlayer()
        plans.values.forEach { it.cancel() }
        plans.clear()
        plan = null
        nextPlanReady = null
        lastWord = null
        _state.value = ReadState(speed = speed)
    }

    fun clearAudio() {
        stop()
        ttsDir.listFiles()?.forEach { it.delete() }
    }

    fun audioBytes(): Long = ttsDir.listFiles()?.sumOf { it.length() } ?: 0L

    // ------------------------------------------------------------------ pages and plans

    private suspend fun openPage(startPage: Int, startSentence: Int) {
        val d = doc ?: return
        var page = startPage
        var sentence = startSentence
        while (page < d.pageCount) {
            _state.update {
                it.copy(
                    page = page, status = "در حال آماده‌سازی صفحه ${page + 1}…", error = null,
                    sentences = emptyList(), sentenceIndex = -1, positionMs = 0, durationMs = 0, playing = false,
                )
            }
            val pl = awaitPlan(page)
            if (!_state.value.active) return
            if (pl == null) {
                // a failed plan is never kept: "retry" (the play button) builds it again from scratch
                if (_state.value.error == null) fail("آماده‌سازی صفحه ${page + 1} ممکن نشد. دوباره تلاش کنید.")
                return
            }
            if (pl.chunks.isEmpty()) { // figure-only page: skipped
                page++
                sentence = 0
                continue
            }
            activatePlan(pl)
            playChunkAt(chunkOfSentence(pl, sentence), sentence)
            return
        }
        stop()
    }

    /** Makes [pl] the page being read: state for the UI, and the background preparation of what comes next. */
    private fun activatePlan(pl: Plan) {
        plan = pl
        lastWord = null
        val found = pl.rects?.count { it.isNotEmpty() } ?: 0
        val possible = pl.rects != null && pl.sentences.isNotEmpty() && found * 100 >= pl.sentences.size * 60
        _state.update {
            it.copy(
                page = pl.page, sentences = pl.sentences, rtl = pl.rtl, status = null, error = null,
                highlight = emptyList(), wordHighlight = emptyList(), sentenceIndex = -1,
                highlightPossible = possible,
                highlightNote = if (possible) null else (pl.note ?: if (pl.rects != null) "جمله‌ها روی PDF پیدا نشدند" else null),
            )
        }
        startPrefetch(pl)
    }

    private fun planFor(page: Int): Deferred<Plan?> {
        val d = doc
        val uri = docUri
        val m = mode
        return plans.getOrPut("$page|${m.name}") {
            scope.async(Dispatchers.Default) {
                try {
                    withTimeout(PLAN_TIMEOUT_MS) { buildPlan(d, uri, m, page) }
                } catch (e: TimeoutCancellationException) {
                    failFor(page, "آماده‌سازی صفحه ${page + 1} بیش از حد طول کشید. دوباره تلاش کنید.")
                    null
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    failFor(page, "خطای غیرمنتظره در آماده‌سازی صفحه: " + (e.message ?: e.javaClass.simpleName))
                    null
                }
            }
        }
    }

    /** Waits for the plan of [page]; a plan that failed is removed so the next request starts a fresh attempt. */
    private suspend fun awaitPlan(page: Int): Plan? {
        val key = "$page|${mode.name}"
        val d = planFor(page)
        val r = try {
            d.await()
        } catch (e: CancellationException) {
            currentCoroutineContext().ensureActive() // we were cancelled: propagate; otherwise the plan was cancelled
            null
        }
        if (r == null) plans.remove(key, d)
        return r
    }

    private suspend fun buildPlan(d: PdfDocument?, uri: String, m: ReadMode, page: Int): Plan? {
        if (d == null) return null
        val s = settings.state.value
        val ex = texts.extract(d, uri, page, s) { phase ->
            if (page == _state.value.page) _state.update { it.copy(status = phase) }
        }
        var text = when (ex) {
            is PT.Ok -> ex.text
            PT.NoText -> return Plan(page, emptyList(), emptyList(), false)
            is PT.Fail -> { failFor(page, ex.message); return null }
        }
        var rtl = isRtlText(text)
        if (m == ReadMode.TRANSLATE_AUDIO && s.sourceLanguage != s.targetLanguage) {
            if (page == _state.value.page) _state.update { it.copy(status = "در حال ترجمه برای تولید صدا…") }
            when (val tr = texts.process(AiTask.TRANSLATE, uri, page, s, text)) {
                is PT.Ok -> text = tr.text
                is PT.Fail -> { failFor(page, tr.message); return null }
                PT.NoText -> return Plan(page, emptyList(), emptyList(), false)
            }
            rtl = s.targetLanguage in RTL_LANGS
        }
        // tables are for the eyes: skip every table row when reading aloud
        val spoken = text.lines().filterNot { it.trimStart().startsWith("|") }.joinToString("\n")
        val sentences = splitSentences(plainForSpeech(spoken))
        // highlight on the PDF itself: only when the voice reads the page's own text (no translation)
        var rects: List<List<NRect>>? = null
        var ranges: List<IntRange?>? = null
        var chars: PageChars? = null
        var note: String? = null
        if (m == ReadMode.ORIGINAL && s.highlightPdf && sentences.isNotEmpty()) {
            val map = textEngine.mapSentences(uri, page, sentences)
            if (map == null) note = textEngine.lastError
            else {
                rects = map.rects
                ranges = map.ranges
                chars = textEngine.pageChars(uri, page) // for word-level highlight; may be null (sentence level then)
            }
        } else if (m == ReadMode.TRANSLATE_AUDIO) {
            note = "در حالت ترجمه، هایلایت روی PDF ممکن نیست"
        }
        return Plan(page, sentences, buildChunks(sentences), rtl, rects, note, ranges, chars)
    }

    /**
     * Keeps everything ahead of the listener ready, without ever blocking playback:
     *  1. the NEXT page's text work (OCR/clean + translation) starts immediately, in parallel with this page's audio,
     *  2. this page's audio is generated starting at the chunk being played (so a jump/seek is served first),
     *  3. then the whole audio of the next page, so even the page change has nothing left to wait for.
     * Every step is retried with growing pauses; a failure never stops the preparation silently.
     */
    private fun startPrefetch(pl: Plan) {
        bgJob?.cancel()
        nextPlanReady = null
        bgJob = scope.launch {
            val d = doc ?: return@launch
            val next = pl.page + 1
            if (next < d.pageCount) planFor(next)
            if (!fillChunks(pl, true)) return@launch
            if (next >= d.pageCount) return@launch
            var npl: Plan? = null
            var tries = 0
            while (npl == null && tries < 3) {
                npl = awaitPlan(next)
                if (npl == null) {
                    tries++
                    delay(4_000L * tries)
                }
            }
            if (npl == null) return@launch
            nextPlanReady = npl
            fillChunks(npl, false)
        }
    }

    /** Generates every missing chunk of [pl], the one being played (and the ones after it) first. */
    private suspend fun fillChunks(pl: Plan, current: Boolean): Boolean {
        while (true) {
            val from = if (current && plan === pl) chunkIndex else 0
            val c = pl.chunks.drop(from).firstOrNull { it.file == null }
                ?: pl.chunks.take(from).firstOrNull { it.file == null }
                ?: return true
            if (!ensureWithRetry(c)) return false
        }
    }

    private suspend fun ensureWithRetry(c: Chunk): Boolean {
        var wait = 3_000L
        for (attempt in 0 until 6) {
            if (ensureChunk(c) != null) return true
            if (attempt < 5) {
                delay(wait)
                wait = (wait * 2).coerceAtMost(30_000L)
            }
        }
        return false
    }

    /** Audio that is ready after the current chunk, including the next page when its audio is prepared. */
    private fun aheadMs(): Long {
        val pl = plan ?: return 0
        var ms = 0L
        for (i in chunkIndex + 1 until pl.chunks.size) {
            val c = pl.chunks[i]
            if (c.file == null) return ms
            ms += c.durationMs
        }
        nextPlanReady?.let { np ->
            for (c in np.chunks) {
                if (c.file == null) break
                ms += c.durationMs
            }
        }
        return ms
    }

    // ------------------------------------------------------------------ audio generation

    private suspend fun ensureChunk(c: Chunk): File? {
        c.file?.let { return it }
        val voice = settings.state.value.voice
        val key = sha256("tts|v1|$voice|${c.text}")
        val f = File(ttsDir, "$key.p.wav")      // polished audio (fades, no DC offset, no edge noise)
        val legacy = File(ttsDir, "$key.wav")   // audio saved by an older version: polished once, then reused
        val ready: File? = when {
            f.exists() && f.length() > 44 -> f
            legacy.exists() && legacy.length() > 44 -> withContext(Dispatchers.IO) { upgradeLegacy(legacy, f) }
            else -> inflight.getOrPut(key) {
                scope.async(Dispatchers.IO) {
                    try { synthesizeTo(c.text, f, voice) } finally { inflight.remove(key) }
                }
            }.await()
        }
        if (ready != null) analyse(c, ready)
        return ready
    }

    /** Reads the finished audio once: exact duration and the real start of every sentence. */
    private suspend fun analyse(c: Chunk, f: File) = withContext(Dispatchers.IO) {
        val bytes = try { f.readBytes() } catch (e: Exception) { null }
        if (bytes != null && bytes.size > 44) {
            val dur = Wav.durationMs(bytes)
            c.durationMs = dur
            c.starts = try { SentenceTiming.align(c.lens, dur, Wav.pauses(bytes)) } catch (e: Exception) { null }
        } else {
            c.durationMs = wavDurationMs(f)
        }
        c.file = f // set last: whoever sees the file also sees its duration and timing
    }

    private fun upgradeLegacy(legacy: File, target: File): File = try {
        val polished = Wav.polish(legacy.readBytes())
        val tmp = File(target.parentFile, target.name + ".tmp")
        tmp.writeBytes(polished)
        if (tmp.renameTo(target)) { legacy.delete(); target } else legacy
    } catch (e: Exception) {
        legacy
    }

    private suspend fun synthesizeTo(text: String, f: File, voice: String): File? {
        return try {
            val wav = synth(text, voice, 0) ?: return null
            val tmp = File(f.parentFile, f.name + ".tmp")
            tmp.writeBytes(Wav.polish(wav))
            if (tmp.renameTo(f)) f else null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            lastSynthError = "ذخیره‌ی صدا ممکن نشد: " + (e.message ?: e.javaClass.simpleName)
            null
        }
    }

    /** Like the HTML tool: if the audio is suspiciously short for its text, ask again in two halves. */
    private suspend fun synth(text: String, voice: String, depth: Int): ByteArray? {
        val o = router.synthesize(text, voice, "")
        if (o is AiRouter.Outcome.Failed) {
            lastSynthError = texts.describe(o)
            return null
        }
        val wav = (o as AiRouter.Outcome.Ok).audio ?: return null
        if (text.length < 140 || depth >= 2 || wavDurationSec(wav) >= text.length / 28.0) return wav
        val ss = splitSentences(text)
        if (ss.size < 2) return wav
        val mid = (ss.size + 1) / 2
        val a = synth(ss.subList(0, mid).joinToString(" "), voice, depth + 1) ?: return wav
        val b = synth(ss.subList(mid, ss.size).joinToString(" "), voice, depth + 1) ?: return wav
        return Wav.join(a, b)
    }

    // ------------------------------------------------------------------ playback

    private fun chunkOfSentence(pl: Plan, sentence: Int): Int =
        pl.chunks.indexOfFirst { sentence in it.first..it.last }.coerceAtLeast(0)

    /** Plays chunk [ci], starting at [startMs] or at the beginning of sentence [startSentence]. */
    private fun playChunkAt(ci: Int, startSentence: Int? = null, startMs: Int = 0) {
        val pl = plan ?: return
        val chunk = pl.chunks.getOrNull(ci) ?: return
        val gen = ++generation
        chunkIndex = ci
        ticker?.cancel()
        discardPreloaded()
        lastWord = null
        scope.launch {
            try {
                if (chunk.file == null) _state.update { it.copy(status = "در حال تولید صدا…", error = null) }
                val f = ensureChunk(chunk)
                if (gen != generation || !_state.value.active) return@launch
                if (f == null) {
                    fail(lastSynthError.ifBlank { "تولید صدا ممکن نشد." })
                    return@launch
                }
                var offset = startMs
                if (startSentence != null && startSentence in chunk.first..chunk.last) {
                    val st = chunk.starts
                    val k = startSentence - chunk.first
                    offset = if (st != null && k in st.indices) {
                        st[k].toInt()
                    } else {
                        val total = (chunk.first..chunk.last).sumOf { pl.sentences[it].length + 1 }.coerceAtLeast(1)
                        val before = (chunk.first until startSentence).sumOf { pl.sentences[it].length + 1 }
                        (chunk.durationMs * before / total).toInt()
                    }
                }
                if (bgJob?.isActive != true) startPrefetch(pl)
                startPlayer(f, ci, offset, gen)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (gen == generation) fail("پخش صدا ممکن نشد: " + (e.message ?: e.javaClass.simpleName))
            }
        }
    }

    private fun newPlayer(f: File): MediaPlayer {
        val mp = MediaPlayer()
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            mp.setDataSource(f.absolutePath)
        } catch (e: Exception) {
            try { mp.release() } catch (ignored: Exception) { }
            throw e
        }
        return mp
    }

    private fun startPlayer(f: File, ci: Int, offsetMs: Int, gen: Int) {
        releasePlayer()
        val mp = try {
            newPlayer(f)
        } catch (e: Exception) {
            fail("پخش صدا ممکن نشد.")
            return
        }
        var prepared = false
        try {
            mp.setOnPreparedListener { p ->
                prepared = true
                if (gen != generation) {
                    try { p.release() } catch (ignored: Exception) { }
                    return@setOnPreparedListener
                }
                applySpeed(p)
                if (offsetMs > 0) p.seekTo(offsetMs)
                p.start()
                _state.update { it.copy(playing = true, status = null, error = null) }
                startTicker(gen)
            }
            attachCallbacks(mp, ci, gen)
            player = mp
            mp.prepareAsync()
            // a player that never becomes ready must not leave the screen waiting forever
            scope.launch {
                delay(10_000)
                if (gen == generation && !prepared && player === mp) fail("آماده‌سازی پخش صدا طول کشید. دوباره تلاش کنید.")
            }
        } catch (e: Exception) {
            try { mp.release() } catch (ignored: Exception) { }
            fail("پخش صدا ممکن نشد.")
        }
    }

    private fun attachCallbacks(mp: MediaPlayer, ci: Int, gen: Int) {
        mp.setOnCompletionListener { if (gen == generation) onChunkDone(ci) }
        mp.setOnErrorListener { _, _, _ ->
            if (gen == generation) fail("پخش صدا با خطا مواجه شد.")
            true
        }
    }

    /**
     * Prepares the player of the next chunk while the current one is speaking, so the hand-over at the end of a
     * chunk is immediate: no re-opening of the audio output between sentences (that was the audible click).
     */
    private fun maybePreload() {
        val pl = plan ?: return
        if (preloaded != null) return
        val ni = chunkIndex + 1
        val target: Plan
        val idx: Int
        if (ni < pl.chunks.size) {
            target = pl
            idx = ni
        } else {
            val np = nextPlanReady ?: return // the page after this one: its first chunk is prepared too
            if (np.chunks.isEmpty()) return
            target = np
            idx = 0
        }
        val f = target.chunks[idx].file ?: return
        try {
            val mp = newPlayer(f)
            val pre = Preloaded(idx, mp, target)
            mp.setOnPreparedListener { pre.ready = true }
            mp.setOnErrorListener { _, _, _ ->
                if (preloaded === pre) discardPreloaded()
                true
            }
            preloaded = pre
            mp.prepareAsync()
        } catch (e: Exception) {
            preloaded = null
        }
    }

    private fun discardPreloaded() {
        preloaded?.let { try { it.mp.release() } catch (e: Exception) { /* ignore */ } }
        preloaded = null
    }

    private fun applySpeed(p: MediaPlayer) {
        if (Build.VERSION.SDK_INT >= 23) {
            try { p.playbackParams = p.playbackParams.setSpeed(speed) } catch (e: Exception) { /* some devices refuse */ }
        }
    }

    private fun onChunkDone(ci: Int) {
        val pl = plan ?: return
        val pre = preloaded
        if (ci + 1 < pl.chunks.size) {
            if (pre != null && pre.plan === pl && pre.ci == ci + 1 && pre.ready) handOver(pre)
            else playChunkAt(ci + 1, startSentence = pl.chunks[ci + 1].first)
        } else {
            if (pre != null && pre.plan !== pl && pre.plan.page == pl.page + 1 && pre.ready) {
                // page change without any pause: the next page's first chunk is already prepared
                activatePlan(pre.plan)
                handOver(pre)
                return
            }
            val next = pl.page + 1
            if (next >= (doc?.pageCount ?: 0)) stop()
            else {
                startJob?.cancel()
                startJob = scope.launch { openPage(next, 0) }
            }
        }
    }

    /** Starts the already prepared player of the next chunk the instant the previous one ends. */
    private fun handOver(pre: Preloaded) {
        val old = player
        val gen = ++generation
        preloaded = null
        chunkIndex = pre.ci
        lastWord = null
        ticker?.cancel()
        try {
            attachCallbacks(pre.mp, pre.ci, gen)
            player = pre.mp
            pre.mp.start()
            applySpeed(pre.mp)
            _state.update { it.copy(playing = true, status = null, error = null) }
            startTicker(gen)
        } catch (e: Exception) {
            try { pre.mp.release() } catch (ignored: Exception) { }
            player = null
            playChunkAt(pre.ci, startSentence = plan?.chunks?.getOrNull(pre.ci)?.first)
        }
        // the finished player is released after the callback has returned
        if (old != null) scope.launch { try { old.release() } catch (e: Exception) { /* ignore */ } }
    }

    private fun startTicker(gen: Int) {
        ticker?.cancel()
        ticker = scope.launch {
            while (isActive && gen == generation) {
                updateProgress()
                maybePreload()
                delay(100)
            }
        }
    }

    private fun updateProgress() {
        val pl = plan ?: return
        val p = player ?: return
        val c = pl.chunks.getOrNull(chunkIndex) ?: return
        val pos = try { p.currentPosition.toLong() } catch (e: Exception) { return }
        val dur = if (c.durationMs > 0) c.durationMs else try { p.duration.toLong() } catch (e: Exception) { 0L }
        var idx = c.first
        val st = c.starts
        if (st != null && st.size == c.last - c.first + 1) {
            // real sentence starts from the audio; a small look-ahead compensates for the output latency
            val t = pos + 120
            for (i in st.indices) if (st[i] <= t) idx = c.first + i else break
        } else {
            val total = (c.first..c.last).sumOf { pl.sentences[it].length + 1 }.coerceAtLeast(1)
            val frac = if (dur > 0) pos.toDouble() / dur else 0.0
            var acc = 0
            for (i in c.first..c.last) {
                acc += pl.sentences[i].length + 1
                idx = i
                if (acc.toDouble() / total >= frac) break
            }
        }
        val before = pl.chunks.take(chunkIndex).sumOf { estimateMs(it) }
        val all = pl.chunks.sumOf { estimateMs(it) }
        val hl = if (idx != _state.value.sentenceIndex) pl.rects?.getOrNull(idx).orEmpty() else null
        val word = currentWord(pl, c, idx, pos)
        val wordRects: List<NRect>? = if (word != lastWord) {
            lastWord = word
            if (word == null) emptyList() else TextPick.rects(pl.chars!!, word.first, word.last)
        } else null
        val ahead = aheadMs()
        _state.update {
            it.copy(
                sentenceIndex = idx, positionMs = before + pos, durationMs = maxOf(all, before + dur),
                highlight = hl ?: it.highlight, wordHighlight = wordRects ?: it.wordHighlight, aheadMs = ahead,
            )
        }
    }

    /**
     * The word being spoken: the time span of the sentence (from the measured sentence starts) is shared among its
     * words in proportion to their length. Only available when the page has a text layer and the audio was analysed.
     */
    private fun currentWord(pl: Plan, c: Chunk, idx: Int, posMs: Long): IntRange? {
        val chars = pl.chars ?: return null
        val range = pl.ranges?.getOrNull(idx) ?: return null
        val st = c.starts ?: return null
        val k = idx - c.first
        if (k !in st.indices) return null
        val from = st[k]
        val to = if (k + 1 < st.size) st[k + 1] else (c.durationMs - 100).coerceAtLeast(from + 200)
        val text = chars.text
        val words = ArrayList<IntRange>()
        var i = range.first.coerceAtLeast(0)
        val end = minOf(range.last, text.length - 1)
        while (i <= end) {
            while (i <= end && text[i].isWhitespace()) i++
            val ws = i
            while (i <= end && !text[i].isWhitespace()) i++
            if (i > ws) words += ws until i
        }
        if (words.isEmpty()) return null
        val total = words.sumOf { it.last - it.first + 2 }
        val frac = ((posMs + 120 - from).toDouble() / (to - from).coerceAtLeast(1)).coerceIn(0.0, 0.999)
        var acc = 0
        for (w in words) {
            acc += w.last - w.first + 2
            if (acc.toDouble() / total > frac) return w
        }
        return words.last()
    }

    private fun estimateMs(c: Chunk): Long = if (c.durationMs > 0) c.durationMs else c.text.length * 70L

    private fun fail(message: String) {
        ticker?.cancel()
        try { player?.pause() } catch (e: Exception) { /* ignore */ }
        _state.update { it.copy(error = message, playing = false, status = null) }
    }

    private fun failFor(page: Int, message: String) {
        if (page == _state.value.page) fail(message) // background preparation errors stay silent until needed
    }

    private fun releasePlayer() {
        discardPreloaded()
        player?.let { try { it.release() } catch (e: Exception) { /* ignore */ } }
        player = null
    }

    // ------------------------------------------------------------------ text helpers

    private val sentenceSplit = Regex("(?<=[.!?؟۔…])\\s+(?=[\"“(\\[A-Z\\u0600-\\u06FF])|\\n+")

    private fun splitSentences(t: String): List<String> =
        t.split(sentenceSplit).map { it.trim() }.filter { it.isNotEmpty() }

    private fun buildChunks(sentences: List<String>): List<Chunk> {
        val out = mutableListOf<Chunk>()
        val sb = StringBuilder()
        var start = 0
        for (i in sentences.indices) {
            val limit = if (out.isEmpty()) 350 else 1500
            if (sb.isNotEmpty() && sb.length + sentences[i].length + 1 > limit) {
                out += Chunk(sb.toString(), start, i - 1, IntArray(i - start) { sentences[start + it].length })
                sb.clear()
                start = i
            }
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(sentences[i])
        }
        if (sb.isNotEmpty()) out += Chunk(sb.toString(), start, sentences.size - 1, IntArray(sentences.size - start) { sentences[start + it].length })
        return out
    }

    private fun isRtlText(s: String): Boolean {
        var rtl = 0
        var ltr = 0
        for (ch in s) {
            when (Character.getDirectionality(ch)) {
                Character.DIRECTIONALITY_RIGHT_TO_LEFT, Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC -> rtl++
                Character.DIRECTIONALITY_LEFT_TO_RIGHT -> ltr++
                else -> {}
            }
        }
        return rtl > 0 && rtl >= ltr
    }

    private fun wavDurationMs(f: File): Long = try {
        f.inputStream().use { ins ->
            val h = ByteArray(44)
            if (ins.read(h) < 44) 0L else {
                val byteRate = ByteBuffer.wrap(h, 28, 4).order(ByteOrder.LITTLE_ENDIAN).int
                if (byteRate > 0) (f.length() - 44) * 1000L / byteRate else 0L
            }
        }
    } catch (e: Exception) { 0L }

    private fun wavDurationSec(b: ByteArray): Double {
        if (b.size < 44) return 0.0
        val byteRate = ByteBuffer.wrap(b, 28, 4).order(ByteOrder.LITTLE_ENDIAN).int
        return if (byteRate > 0) (b.size - 44).toDouble() / byteRate else 0.0
    }
}
