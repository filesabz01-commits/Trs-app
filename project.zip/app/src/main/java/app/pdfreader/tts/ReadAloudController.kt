package app.pdfreader.tts

import android.content.Context
import android.media.MediaPlayer
import android.os.Build
import app.pdfreader.ai.AiRouter
import app.pdfreader.ai.AiTask
import app.pdfreader.ai.PT
import app.pdfreader.ai.PageTextService
import app.pdfreader.ai.RTL_LANGS
import app.pdfreader.ai.SettingsRepo
import app.pdfreader.ai.Wav
import app.pdfreader.ai.plainForSpeech
import app.pdfreader.ai.sha256
import app.pdfreader.core.pdf.PdfDocument
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap

enum class ReadMode { ORIGINAL, TRANSLATE_AUDIO }

data class ReadState(
    val active: Boolean = false,
    val page: Int = 0,
    val mode: ReadMode = ReadMode.ORIGINAL,
    val sentences: List<String> = emptyList(),
    val sentenceIndex: Int = -1,
    val playing: Boolean = false,
    val status: String? = null,
    val error: String? = null,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val speed: Float = 1f,
    val rtl: Boolean = false,
)

private class Chunk(val text: String, val first: Int, val last: Int) {
    @Volatile var file: File? = null
    @Volatile var durationMs: Long = 0
}

private class Plan(val page: Int, val sentences: List<String>, val chunks: List<Chunk>, val rtl: Boolean)

/**
 * Read Aloud:
 *  - ORIGINAL: extract/clean the page text and read it as it is (English or Persian book, no translation)
 *  - TRANSLATE_AUDIO: extract, translate (only to produce the voice, shown only in the sentence list), read
 * The next page is prepared in the background while the current page plays. Audio files are kept permanently
 * until the user clears the cache. Playback uses MediaPlayer inside the app (no background service yet).
 */
class ReadAloudController(
    context: Context,
    private val router: AiRouter,
    private val texts: PageTextService,
    private val settings: SettingsRepo,
) {
    private val ctx = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val _state = MutableStateFlow(ReadState())
    val state: StateFlow<ReadState> = _state.asStateFlow()

    private val ttsDir = File(ctx.filesDir, "tts").also { it.mkdirs() }
    private val inflight = ConcurrentHashMap<String, Deferred<File?>>()
    private val plans = HashMap<String, Deferred<Plan?>>()

    private var doc: PdfDocument? = null
    private var docUri = ""
    private var mode = ReadMode.ORIGINAL
    private var plan: Plan? = null
    private var chunkIndex = 0
    private var player: MediaPlayer? = null
    private var ticker: Job? = null
    private var bgJob: Job? = null
    private var startJob: Job? = null
    private var speed = 1f
    private var generation = 0
    @Volatile private var lastSynthError = ""

    // ------------------------------------------------------------------ public API

    fun start(doc: PdfDocument, docUri: String, page: Int, mode: ReadMode) {
        stop()
        this.doc = doc
        this.docUri = docUri
        this.mode = mode
        _state.value = ReadState(active = true, page = page, mode = mode, status = "در حال آماده‌سازی…", speed = speed)
        startJob = scope.launch { openPage(page, 0) }
    }

    fun toggle() {
        val st = _state.value
        if (!st.active) return
        val p = player
        if (st.error != null || p == null) {
            _state.update { it.copy(error = null) }
            val ci = plan?.let { pl -> pl.chunks.indexOfFirst { c -> st.sentenceIndex in c.first..c.last } }
            if (plan != null && ci != null && ci >= 0) playChunkAt(ci, st.sentenceIndex.coerceAtLeast(0))
            else startJob = scope.launch { openPage(st.page, st.sentenceIndex.coerceAtLeast(0)) }
            return
        }
        try {
            if (p.isPlaying) {
                p.pause()
                ticker?.cancel()
                _state.update { it.copy(playing = false) }
            } else {
                p.start()
                _state.update { it.copy(playing = true) }
                startTicker(generation)
            }
        } catch (e: IllegalStateException) {
            // player is being replaced; ignore
        }
    }

    fun seekBy(deltaMs: Int) {
        val p = player ?: return
        val pl = plan ?: return
        val c = pl.chunks.getOrNull(chunkIndex) ?: return
        try {
            val target = p.currentPosition + deltaMs
            val dur = if (c.durationMs > 0) c.durationMs.toInt() else p.duration
            when {
                target < 0 -> if (chunkIndex > 0) {
                    val prev = pl.chunks[chunkIndex - 1]
                    playChunkAt(chunkIndex - 1, startMs = (prev.durationMs + target).toInt().coerceAtLeast(0))
                } else p.seekTo(0)
                target >= dur -> onChunkDone(chunkIndex)
                else -> p.seekTo(target)
            }
        } catch (e: IllegalStateException) {
            // ignore
        }
    }

    fun jumpSentence(delta: Int) {
        val pl = plan ?: return
        val target = _state.value.sentenceIndex.coerceAtLeast(0) + delta
        when {
            target < 0 -> playChunkAt(0, 0)
            target >= pl.sentences.size -> onChunkDone(pl.chunks.size - 1)
            else -> playChunkAt(chunkOfSentence(pl, target), target)
        }
    }

    fun seekToFraction(f: Float) {
        val pl = plan ?: return
        val total = pl.chunks.sumOf { estimateMs(it) }
        var remaining = (total * f).toLong()
        for ((i, c) in pl.chunks.withIndex()) {
            val d = estimateMs(c)
            if (remaining < d || i == pl.chunks.lastIndex) {
                playChunkAt(i, startMs = remaining.coerceAtMost(d).toInt())
                return
            }
            remaining -= d
        }
    }

    fun setSpeed(v: Float) {
        speed = v
        _state.update { it.copy(speed = v) }
        player?.let { p ->
            try {
                val was = p.isPlaying
                applySpeed(p)
                if (!was) p.pause() // setting the rate on a paused player would resume it
            } catch (e: IllegalStateException) {
                // ignore
            }
        }
    }

    fun stop() {
        generation++
        startJob?.cancel()
        bgJob?.cancel()
        ticker?.cancel()
        releasePlayer()
        plans.clear()
        plan = null
        _state.value = ReadState(speed = speed)
    }

    fun clearAudio() {
        stop()
        ttsDir.listFiles()?.forEach { it.delete() }
    }

    fun audioBytes(): Long = ttsDir.listFiles()?.sumOf { it.length() } ?: 0L

    // ------------------------------------------------------------------ pages and plans

    private suspend fun openPage(startPage: Int, startSentence: Int) {
        val d = doc ?: return
        var page = startPage
        var sentence = startSentence
        while (page < d.pageCount) {
            _state.update {
                it.copy(
                    page = page, status = "در حال آماده‌سازی صفحه ${page + 1}…", error = null,
                    sentences = emptyList(), sentenceIndex = -1, positionMs = 0, durationMs = 0, playing = false,
                )
            }
            val key = "$page|${mode.name}"
            val pl = planFor(page).await()
            if (!_state.value.active) return
            if (pl == null) {
                plans.remove(key)
                if (_state.value.error == null) fail("آماده‌سازی صفحه ${page + 1} ممکن نشد.")
                return
            }
            if (pl.chunks.isEmpty()) { // figure-only page: skipped
                page++
                sentence = 0
                continue
            }
            plan = pl
            _state.update { it.copy(sentences = pl.sentences, rtl = pl.rtl, status = null) }
            startPrefetch(pl)
            playChunkAt(chunkOfSentence(pl, sentence), sentence)
            return
        }
        stop()
    }

    private fun planFor(page: Int): Deferred<Plan?> =
        plans.getOrPut("$page|${mode.name}") { scope.async(Dispatchers.Default) { buildPlan(page) } }

    private suspend fun buildPlan(page: Int): Plan? {
        val d = doc ?: return null
        val s = settings.state.value
        val ex = texts.extract(d, docUri, page, s) { phase ->
            if (page == _state.value.page) _state.update { it.copy(status = phase) }
        }
        var text = when (ex) {
            is PT.Ok -> ex.text
            PT.NoText -> return Plan(page, emptyList(), emptyList(), false)
            is PT.Fail -> { failFor(page, ex.message); return null }
        }
        var rtl = isRtlText(text)
        if (mode == ReadMode.TRANSLATE_AUDIO && s.sourceLanguage != s.targetLanguage) {
            if (page == _state.value.page) _state.update { it.copy(status = "در حال ترجمه برای تولید صدا…") }
            when (val tr = texts.process(AiTask.TRANSLATE, docUri, page, s, text)) {
                is PT.Ok -> text = tr.text
                is PT.Fail -> { failFor(page, tr.message); return null }
                PT.NoText -> return Plan(page, emptyList(), emptyList(), false)
            }
            rtl = s.targetLanguage in RTL_LANGS
        }
        val sentences = splitSentences(plainForSpeech(text))
        return Plan(page, sentences, buildChunks(sentences), rtl)
    }

    /** Keeps generating the audio of this page, then prepares the next page so playback never waits. */
    private fun startPrefetch(pl: Plan) {
        bgJob?.cancel()
        bgJob = scope.launch {
            for (c in pl.chunks) if (ensureChunk(c) == null) return@launch
            val d = doc ?: return@launch
            val next = pl.page + 1
            if (next < d.pageCount) {
                val npl = planFor(next).await() ?: return@launch
                for (c in npl.chunks.take(2)) if (ensureChunk(c) == null) return@launch
            }
        }
    }

    // ------------------------------------------------------------------ audio generation

    private suspend fun ensureChunk(c: Chunk): File? {
        c.file?.let { return it }
        val voice = settings.state.value.voice
        val key = sha256("tts|v1|$voice|${c.text}")
        val f = File(ttsDir, "$key.wav")
        val ready: File? = if (f.exists() && f.length() > 44) f else {
            inflight.getOrPut(key) {
                scope.async(Dispatchers.IO) {
                    try { synthesizeTo(c.text, f, voice) } finally { inflight.remove(key) }
                }
            }.await()
        }
        if (ready != null) {
            c.file = ready
            c.durationMs = wavDurationMs(ready)
        }
        return ready
    }

    private suspend fun synthesizeTo(text: String, f: File, voice: String): File? {
        val wav = synth(text, voice, 0) ?: return null
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeBytes(wav)
        if (!tmp.renameTo(f)) return null
        return f
    }

    /** Like the HTML tool: if the audio is suspiciously short for its text, ask again in two halves. */
    private suspend fun synth(text: String, voice: String, depth: Int): ByteArray? {
        val o = router.synthesize(text, voice, "")
        if (o is AiRouter.Outcome.Failed) {
            lastSynthError = texts.describe(o)
            return null
        }
        val wav = (o as AiRouter.Outcome.Ok).audio ?: return null
        if (text.length < 140 || depth >= 2 || wavDurationSec(wav) >= text.length / 28.0) return wav
        val ss = splitSentences(text)
        if (ss.size < 2) return wav
        val mid = (ss.size + 1) / 2
        val a = synth(ss.subList(0, mid).joinToString(" "), voice, depth + 1) ?: return wav
        val b = synth(ss.subList(mid, ss.size).joinToString(" "), voice, depth + 1) ?: return wav
        return concatWav(a, b)
    }

    // ------------------------------------------------------------------ playback

    private fun chunkOfSentence(pl: Plan, sentence: Int): Int =
        pl.chunks.indexOfFirst { sentence in it.first..it.last }.coerceAtLeast(0)

    /** Plays chunk [ci], starting at [startMs] or at the beginning of sentence [startSentence]. */
    private fun playChunkAt(ci: Int, startSentence: Int? = null, startMs: Int = 0) {
        val pl = plan ?: return
        val chunk = pl.chunks.getOrNull(ci) ?: return
        val gen = ++generation
        chunkIndex = ci
        ticker?.cancel()
        scope.launch {
            if (chunk.file == null) _state.update { it.copy(status = "در حال تولید صدا…", error = null) }
            val f = ensureChunk(chunk)
            if (gen != generation || !_state.value.active) return@launch
            if (f == null) {
                fail(lastSynthError.ifBlank { "تولید صدا ممکن نشد." })
                return@launch
            }
            var offset = startMs
            if (startSentence != null && startSentence in chunk.first..chunk.last) {
                val total = (chunk.first..chunk.last).sumOf { pl.sentences[it].length + 1 }.coerceAtLeast(1)
                val before = (chunk.first until startSentence).sumOf { pl.sentences[it].length + 1 }
                offset = (chunk.durationMs * before / total).toInt()
            }
            startPlayer(f, ci, offset, gen)
        }
    }

    private fun startPlayer(f: File, ci: Int, offsetMs: Int, gen: Int) {
        releasePlayer()
        val mp = MediaPlayer()
        try {
            mp.setDataSource(f.absolutePath)
            mp.setOnPreparedListener { p ->
                if (gen != generation) {
                    p.release()
                    return@setOnPreparedListener
                }
                applySpeed(p)
                if (offsetMs > 0) p.seekTo(offsetMs)
                p.start()
                _state.update { it.copy(playing = true, status = null, error = null) }
                startTicker(gen)
            }
            mp.setOnCompletionListener { if (gen == generation) onChunkDone(ci) }
            mp.setOnErrorListener { _, _, _ ->
                if (gen == generation) fail("پخش صدا با خطا مواجه شد.")
                true
            }
            player = mp
            mp.prepareAsync()
        } catch (e: Exception) {
            try { mp.release() } catch (ignored: Exception) { }
            fail("پخش صدا ممکن نشد.")
        }
    }

    private fun applySpeed(p: MediaPlayer) {
        if (Build.VERSION.SDK_INT >= 23) {
            try { p.playbackParams = p.playbackParams.setSpeed(speed) } catch (e: Exception) { /* some devices refuse */ }
        }
    }

    private fun onChunkDone(ci: Int) {
        val pl = plan ?: return
        if (ci + 1 < pl.chunks.size) {
            playChunkAt(ci + 1, startSentence = pl.chunks[ci + 1].first)
        } else {
            val next = pl.page + 1
            if (next >= (doc?.pageCount ?: 0)) stop()
            else startJob = scope.launch { openPage(next, 0) }
        }
    }

    private fun startTicker(gen: Int) {
        ticker?.cancel()
        ticker = scope.launch {
            while (isActive && gen == generation) {
                updateProgress()
                delay(150)
            }
        }
    }

    private fun updateProgress() {
        val pl = plan ?: return
        val p = player ?: return
        val c = pl.chunks.getOrNull(chunkIndex) ?: return
        val pos = try { p.currentPosition.toLong() } catch (e: Exception) { return }
        val dur = if (c.durationMs > 0) c.durationMs else try { p.duration.toLong() } catch (e: Exception) { 0L }
        val total = (c.first..c.last).sumOf { pl.sentences[it].length + 1 }.coerceAtLeast(1)
        val frac = if (dur > 0) pos.toDouble() / dur else 0.0
        var acc = 0
        var idx = c.first
        for (i in c.first..c.last) {
            acc += pl.sentences[i].length + 1
            idx = i
            if (acc.toDouble() / total >= frac) break
        }
        val before = pl.chunks.take(chunkIndex).sumOf { estimateMs(it) }
        val all = pl.chunks.sumOf { estimateMs(it) }
        _state.update { it.copy(sentenceIndex = idx, positionMs = before + pos, durationMs = maxOf(all, before + dur)) }
    }

    private fun estimateMs(c: Chunk): Long = if (c.durationMs > 0) c.durationMs else c.text.length * 70L

    private fun fail(message: String) {
        ticker?.cancel()
        try { player?.pause() } catch (e: Exception) { /* ignore */ }
        _state.update { it.copy(error = message, playing = false, status = null) }
    }

    private fun failFor(page: Int, message: String) {
        if (page == _state.value.page) fail(message) // background preparation errors stay silent until needed
    }

    private fun releasePlayer() {
        player?.let { try { it.release() } catch (e: Exception) { /* ignore */ } }
        player = null
    }

    // ------------------------------------------------------------------ text helpers

    private val sentenceSplit = Regex("(?<=[.!?؟۔…])\\s+(?=[\"“(\\[A-Z\\u0600-\\u06FF])|\\n+")

    private fun splitSentences(t: String): List<String> =
        t.split(sentenceSplit).map { it.trim() }.filter { it.isNotEmpty() }

    private fun buildChunks(sentences: List<String>): List<Chunk> {
        val out = mutableListOf<Chunk>()
        val sb = StringBuilder()
        var start = 0
        for (i in sentences.indices) {
            val limit = if (out.isEmpty()) 350 else 1500
            if (sb.isNotEmpty() && sb.length + sentences[i].length + 1 > limit) {
                out += Chunk(sb.toString(), start, i - 1)
                sb.clear()
                start = i
            }
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(sentences[i])
        }
        if (sb.isNotEmpty()) out += Chunk(sb.toString(), start, sentences.size - 1)
        return out
    }

    private fun isRtlText(s: String): Boolean {
        var rtl = 0
        var ltr = 0
        for (ch in s) {
            when (Character.getDirectionality(ch)) {
                Character.DIRECTIONALITY_RIGHT_TO_LEFT, Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC -> rtl++
                Character.DIRECTIONALITY_LEFT_TO_RIGHT -> ltr++
                else -> {}
            }
        }
        return rtl > 0 && rtl >= ltr
    }

    private fun wavDurationMs(f: File): Long = try {
        f.inputStream().use { ins ->
            val h = ByteArray(44)
            if (ins.read(h) < 44) 0L else {
                val byteRate = ByteBuffer.wrap(h, 28, 4).order(ByteOrder.LITTLE_ENDIAN).int
                if (byteRate > 0) (f.length() - 44) * 1000L / byteRate else 0L
            }
        }
    } catch (e: Exception) { 0L }

    private fun wavDurationSec(b: ByteArray): Double {
        if (b.size < 44) return 0.0
        val byteRate = ByteBuffer.wrap(b, 28, 4).order(ByteOrder.LITTLE_ENDIAN).int
        return if (byteRate > 0) (b.size - 44).toDouble() / byteRate else 0.0
    }

    private fun concatWav(a: ByteArray, b: ByteArray): ByteArray {
        val rate = ByteBuffer.wrap(a, 24, 4).order(ByteOrder.LITTLE_ENDIAN).int
        return Wav.fromPcm16(a.copyOfRange(44, a.size) + b.copyOfRange(44, b.size), rate)
    }
}
