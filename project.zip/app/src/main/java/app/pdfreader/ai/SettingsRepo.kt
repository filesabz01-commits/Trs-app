package app.pdfreader.ai

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Small persisted settings store (SharedPreferences). */
class SettingsRepo(context: Context) {
    private val prefs = context.getSharedPreferences("reader_settings", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(
        ReadingSettings(
            targetLanguage = prefs.getString("lang", "فارسی") ?: "فارسی",
            profile = runCatching {
                ReadingProfile.valueOf(prefs.getString("profile", ReadingProfile.TECHNICAL.name)!!)
            }.getOrDefault(ReadingProfile.TECHNICAL),
            customInstruction = prefs.getString("custom", "") ?: "",
        )
    )
    val state: StateFlow<ReadingSettings> = _state.asStateFlow()

    fun update(transform: (ReadingSettings) -> ReadingSettings) {
        val s = transform(_state.value)
        _state.value = s
        prefs.edit()
            .putString("lang", s.targetLanguage)
            .putString("profile", s.profile.name)
            .putString("custom", s.customInstruction)
            .apply()
    }
}
