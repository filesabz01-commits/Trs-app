package app.pdfreader.ai

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Small persisted settings store (SharedPreferences). */
class SettingsRepo(context: Context) {
    private val prefs = context.getSharedPreferences("reader_settings", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(
        ReadingSettings(
            sourceLanguage = prefs.getString("source", "auto") ?: "auto",
            targetLanguage = prefs.getString("target", "fa") ?: "fa",
            profile = runCatching {
                ReadingProfile.valueOf(prefs.getString("profile", ReadingProfile.TECHNICAL.name)!!)
            }.getOrDefault(ReadingProfile.TECHNICAL),
            customInstruction = prefs.getString("custom", "") ?: "",
            preferredModel = prefs.getString("model", "") ?: "",
            persistOcr = prefs.getBoolean("persist_ocr", false),
            bilingual = prefs.getBoolean("bilingual", false),
            voice = prefs.getString("voice", "Kore") ?: "Kore",
            readText = prefs.getBoolean("read_text_v2", false),
            highlightPdf = prefs.getBoolean("highlight_pdf", true),
            hideFallbackText = prefs.getBoolean("hide_fallback_text", false),
        )
    )
    val state: StateFlow<ReadingSettings> = _state.asStateFlow()

    fun update(transform: (ReadingSettings) -> ReadingSettings) {
        val s = transform(_state.value)
        _state.value = s
        prefs.edit()
            .putString("source", s.sourceLanguage)
            .putString("target", s.targetLanguage)
            .putString("profile", s.profile.name)
            .putString("custom", s.customInstruction)
            .putString("model", s.preferredModel)
            .putBoolean("persist_ocr", s.persistOcr)
            .putBoolean("bilingual", s.bilingual)
            .putString("voice", s.voice)
            .putBoolean("read_text_v2", s.readText)
            .putBoolean("highlight_pdf", s.highlightPdf)
            .putBoolean("hide_fallback_text", s.hideFallbackText)
            .apply()
    }

    fun seedVersion(): Int = prefs.getInt("seed_version", 0)
    fun setSeedVersion(v: Int) { prefs.edit().putInt("seed_version", v).apply() }
}
