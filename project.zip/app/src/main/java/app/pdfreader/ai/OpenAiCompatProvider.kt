package app.pdfreader.ai

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject

/** Works with any OpenAI-compatible /chat/completions endpoint (user-defined base URL). */
class OpenAiCompatProvider : AiProvider {
    override suspend fun generate(baseUrl: String, model: String, apiKey: String, req: AiRequest): AiResult =
        guarded {
            val url = "${baseUrl.trimEnd('/')}/chat/completions"
            val messages = JSONArray()
            req.system?.let { messages.put(JSONObject().put("role", "system").put("content", it)) }
            val content: Any = if (req.imageJpeg != null) {
                val b64 = Base64.encodeToString(req.imageJpeg, Base64.NO_WRAP)
                JSONArray()
                    .put(JSONObject().put("type", "text").put("text", req.prompt))
                    .put(
                        JSONObject().put("type", "image_url").put(
                            "image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64"),
                        )
                    )
            } else req.prompt
            messages.put(JSONObject().put("role", "user").put("content", content))
            val body = JSONObject().put("model", model).put("messages", messages).put("temperature", 0.2)
            val res = postJson(url, mapOf("Authorization" to "Bearer $apiKey"), body.toString())
            if (res.code in 200..299) parse(res.body) else classifyError(res.code, res.body)
        }

    private fun parse(json: String): AiResult {
        val choices = JSONObject(json).optJSONArray("choices")
        if (choices == null || choices.length() == 0) return AiResult.Fail(FailKind.EMPTY, "no choices")
        val text = choices.getJSONObject(0).optJSONObject("message")?.optString("content").orEmpty().trim()
        return if (text.isEmpty()) AiResult.Fail(FailKind.EMPTY, "empty") else AiResult.Ok(text)
    }
}
