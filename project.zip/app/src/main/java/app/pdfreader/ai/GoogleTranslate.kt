package app.pdfreader.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Fast, lightweight translation service using Google Translate.
 * Translates paragraphs in batch with zero AI token consumption.
 */
object GoogleTranslateService {

    suspend fun translate(text: String, sourceLang: String = "auto", targetLang: String = "fa"): String = withContext(Dispatchers.IO) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return@withContext ""

        val paragraphs = trimmed.split("\n\n")
        val translatedParagraphs = mutableListOf<String>()

        for (para in paragraphs) {
            val pTrimmed = para.trim()
            if (pTrimmed.isEmpty()) {
                translatedParagraphs.add("")
                continue
            }
            if (pTrimmed.length > 2500) {
                // Split large paragraphs into sentence chunks
                val sentences = pTrimmed.split(Regex("(?<=[.!?\\n])\\s+"))
                val chunkBuilder = StringBuilder()
                val chunkResults = mutableListOf<String>()
                for (s in sentences) {
                    if (chunkBuilder.length + s.length > 2000) {
                        chunkResults.add(translateChunk(chunkBuilder.toString(), sourceLang, targetLang))
                        chunkBuilder.clear()
                    }
                    if (chunkBuilder.isNotEmpty()) chunkBuilder.append(" ")
                    chunkBuilder.append(s)
                }
                if (chunkBuilder.isNotEmpty()) {
                    chunkResults.add(translateChunk(chunkBuilder.toString(), sourceLang, targetLang))
                }
                translatedParagraphs.add(chunkResults.joinToString(" "))
            } else {
                translatedParagraphs.add(translateChunk(pTrimmed, sourceLang, targetLang))
            }
        }
        translatedParagraphs.joinToString("\n\n")
    }

    private fun translateChunk(chunk: String, sl: String, tl: String): String {
        val textToTranslate = chunk.trim()
        if (textToTranslate.isEmpty()) return ""

        val sLang = if (sl.isBlank() || sl == "auto") "auto" else sl
        val tLang = if (tl.isBlank()) "fa" else tl
        val encoded = URLEncoder.encode(textToTranslate, "UTF-8")
        val urlStr = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=$sLang&tl=$tLang&dt=t&q=$encoded"

        val conn = URL(urlStr).openConnection() as HttpURLConnection
        return try {
            conn.requestMethod = "GET"
            conn.connectTimeout = 12_000
            conn.readTimeout = 18_000
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Android; Mobile; rv:109.0) Gecko/109.0 Firefox/119.0")
            val code = conn.responseCode
            if (code !in 200..299) {
                throw IOException("Google Translate HTTP $code")
            }
            val resp = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val root = JSONArray(resp)
            val sentences = root.optJSONArray(0) ?: return textToTranslate
            val sb = StringBuilder()
            for (i in 0 until sentences.length()) {
                val part = sentences.optJSONArray(i) ?: continue
                val str = part.optString(0, "")
                if (str.isNotEmpty()) sb.append(str)
            }
            sb.toString().ifEmpty { textToTranslate }
        } finally {
            try { conn.disconnect() } catch (ignored: Exception) {}
        }
    }
}
