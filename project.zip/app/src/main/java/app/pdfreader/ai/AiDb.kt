package app.pdfreader.ai

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "providers")
data class ProviderEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: String,
    val baseUrl: String,
    val enabled: Boolean = true,
    val position: Int,
)

@Entity(tableName = "models")
data class ModelEntity(
    @PrimaryKey val id: String,
    val providerId: String,
    val modelName: String,
    val supportsText: Boolean,
    val supportsVision: Boolean,
    val enabled: Boolean = true,
    val position: Int,
) {
    fun supports(c: Capability) = when (c) {
        Capability.TEXT -> supportsText
        Capability.VISION -> supportsVision
    }
}

@Entity(tableName = "api_keys")
data class ApiKeyEntity(
    @PrimaryKey val id: String,
    val providerId: String,
    val label: String,
    /** AES-GCM ciphertext (Base64). Never the plain key. */
    val secret: String,
    val status: String = KeyStatus.ACTIVE.name,
    val cooldownUntil: Long = 0,
    val usageDay: String = "",
    val requestsToday: Int = 0,
    val errorsToday: Int = 0,
    val lastUsedAt: Long = 0,
    val lastError: String? = null,
    val position: Int,
)

@Entity(tableName = "ai_cache")
data class CacheEntity(
    @PrimaryKey val cacheKey: String,
    val text: String,
    val model: String,
    val createdAt: Long,
)

@Dao
interface AiDao {
    @Query("SELECT * FROM providers ORDER BY position") fun observeProviders(): Flow<List<ProviderEntity>>
    @Query("SELECT * FROM providers ORDER BY position") suspend fun providers(): List<ProviderEntity>
    @Query("SELECT * FROM providers WHERE id = :id") suspend fun provider(id: String): ProviderEntity?
    @Query("SELECT COUNT(*) FROM providers") suspend fun providerCount(): Int

    @Query("SELECT * FROM models ORDER BY position") fun observeModels(): Flow<List<ModelEntity>>
    @Query("SELECT * FROM models ORDER BY position") suspend fun models(): List<ModelEntity>

    @Query("SELECT * FROM api_keys ORDER BY position") fun observeKeys(): Flow<List<ApiKeyEntity>>
    @Query("SELECT * FROM api_keys WHERE providerId = :pid ORDER BY position") suspend fun keysFor(pid: String): List<ApiKeyEntity>
    @Query("SELECT * FROM api_keys WHERE id = :id") suspend fun key(id: String): ApiKeyEntity?

    @Upsert suspend fun upsertProvider(p: ProviderEntity)
    @Upsert suspend fun upsertModel(m: ModelEntity)
    @Upsert suspend fun upsertKey(k: ApiKeyEntity)

    @Query("DELETE FROM providers WHERE id = :id") suspend fun deleteProvider(id: String)
    @Query("DELETE FROM models WHERE providerId = :id") suspend fun deleteModelsOf(id: String)
    @Query("DELETE FROM api_keys WHERE providerId = :id") suspend fun deleteKeysOf(id: String)
    @Query("DELETE FROM models WHERE id = :id") suspend fun deleteModel(id: String)
    @Query("DELETE FROM api_keys WHERE id = :id") suspend fun deleteKey(id: String)

    @Query("SELECT * FROM ai_cache WHERE cacheKey = :k") suspend fun cached(k: String): CacheEntity?
    @Upsert suspend fun upsertCache(c: CacheEntity)
    @Query("SELECT COALESCE(SUM(LENGTH(text)), 0) FROM ai_cache") fun observeCacheBytes(): Flow<Long>
    @Query("DELETE FROM ai_cache") suspend fun clearCache()
}

@Database(
    entities = [ProviderEntity::class, ModelEntity::class, ApiKeyEntity::class, CacheEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class AiDatabase : RoomDatabase() {
    abstract fun aiDao(): AiDao
}
