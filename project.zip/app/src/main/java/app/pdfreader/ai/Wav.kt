package app.pdfreader.ai

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest

object Wav {
    /** Wraps raw 16-bit PCM in a WAV container so any player can open it. */
    fun fromPcm16(pcm: ByteArray, sampleRate: Int, channels: Int = 1): ByteArray {
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray()).putInt(36 + pcm.size).put("WAVE".toByteArray())
        header.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(channels.toShort())
        header.putInt(sampleRate).putInt(sampleRate * channels * 2).putShort((channels * 2).toShort()).putShort(16)
        header.put("data".toByteArray()).putInt(pcm.size)
        return header.array() + pcm
    }
}

fun sha256(s: String): String =
    MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

/** Text prepared for speech: no Markdown marks, no table borders. */
fun plainForSpeech(s: String): String = s.lines()
    .filterNot { Regex("^[\\s|:\\-]+$").matches(it) }
    .joinToString("\n") { l ->
        l.replace("**", "").replace("__", "")
            .replace(Regex("^\\s*#{1,6}\\s*"), "")
            .replace(Regex("^\\s*[*\\-•]\\s+"), "")
            .replace("|", " ")
    }.trim()

/** Splits text into speakable chunks. The first one is short so playback starts quickly. */
fun splitForSpeech(text: String, firstMax: Int = 350, max: Int = 1100): List<String> {
    val sentences = text.split(Regex("(?<=[.!?؟۔…])\\s+|\\n+")).map { it.trim() }.filter { it.isNotEmpty() }
    val out = mutableListOf<String>()
    val sb = StringBuilder()
    for (s in sentences) {
        val limit = if (out.isEmpty()) firstMax else max
        if (sb.isNotEmpty() && sb.length + s.length + 1 > limit) {
            out.add(sb.toString())
            sb.clear()
        }
        if (s.length > max) {
            if (sb.isNotEmpty()) { out.add(sb.toString()); sb.clear() }
            s.chunked(max).forEach { out.add(it) }
        } else {
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(s)
        }
    }
    if (sb.isNotEmpty()) out.add(sb.toString())
    return out
}
