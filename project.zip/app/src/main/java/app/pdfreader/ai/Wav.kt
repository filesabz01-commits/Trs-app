package app.pdfreader.ai

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest

/** A silent stretch inside a clip, in milliseconds from the clip start. */
class Pause(val startMs: Long, val endMs: Long) {
    val centerMs: Long get() = (startMs + endMs) / 2
    val lengthMs: Long get() = endMs - startMs
}

object Wav {
    /** Wraps raw 16-bit PCM in a WAV container so any player can open it. */
    fun fromPcm16(pcm: ByteArray, sampleRate: Int, channels: Int = 1): ByteArray {
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray()).putInt(36 + pcm.size).put("WAVE".toByteArray())
        header.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(channels.toShort())
        header.putInt(sampleRate).putInt(sampleRate * channels * 2).putShort((channels * 2).toShort()).putShort(16)
        header.put("data".toByteArray()).putInt(pcm.size)
        return header.array() + pcm
    }

    fun sampleRate(wav: ByteArray): Int =
        if (wav.size < 44) 24000 else ByteBuffer.wrap(wav, 24, 4).order(ByteOrder.LITTLE_ENDIAN).int.takeIf { it in 8000..96000 } ?: 24000

    fun durationMs(wav: ByteArray): Long =
        if (wav.size <= 44) 0L else (wav.size - 44) / 2L * 1000L / sampleRate(wav)

    private fun samples(wav: ByteArray): ShortArray {
        val n = (wav.size - 44) / 2
        val out = ShortArray(n)
        ByteBuffer.wrap(wav, 44, n * 2).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(out)
        return out
    }

    private fun toWav(s: ShortArray, rate: Int): ByteArray {
        val bb = ByteBuffer.allocate(s.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (v in s) bb.putShort(v)
        return fromPcm16(bb.array(), rate)
    }

    /**
     * Cleans one speech clip so that clips can be played back to back without clicks or "static":
     *  - removes the DC offset (a constant shift makes every clip start/stop with a step = audible pop),
     *  - trims digital silence/noise at both ends and keeps a short natural margin,
     *  - fades in (10 ms) and out (25 ms) so the waveform always starts and ends at zero,
     *  - appends a short silence, which is the pause between two clips.
     */
    fun polish(wav: ByteArray): ByteArray {
        if (wav.size < 44 + 800) return wav
        val rate = sampleRate(wav)
        val raw = samples(wav)
        val n = raw.size
        var sum = 0L
        for (v in raw) sum += v
        val dc = (sum / n).toInt()
        val x = IntArray(n) { raw[it] - dc }
        var peak = 0
        for (v in x) { val a = kotlin.math.abs(v); if (a > peak) peak = a }
        val thr = maxOf(300, peak / 20) // hiss/noise tails well below the speech level count as silence
        var first = 0
        while (first < n && kotlin.math.abs(x[first]) < thr) first++
        var last = n - 1
        while (last > first && kotlin.math.abs(x[last]) < thr) last--
        if (first >= last) return wav
        // A click or blip (burst < 25 ms followed by >= 30 ms of silence) at either end is not speech: skip it.
        val quietLen = rate * 30 / 1000
        val burstMax = rate * 25 / 1000
        val window = rate * 200 / 1000
        run {
            var i = first
            var q = 0
            while (i < minOf(n, first + window)) {
                if (kotlin.math.abs(x[i]) < thr) q++ else q = 0
                if (q >= quietLen) {
                    val burstEnd = i - q + 1
                    if (burstEnd - first < burstMax) {
                        var j = i
                        while (j < n && kotlin.math.abs(x[j]) < thr) j++
                        if (j < last) first = j
                    }
                    break
                }
                i++
            }
        }
        run {
            var i = last
            var q = 0
            while (i > maxOf(first, last - window)) {
                if (kotlin.math.abs(x[i]) < thr) q++ else q = 0
                if (q >= quietLen) {
                    val burstStart = i + q - 1
                    if (last - burstStart < burstMax) {
                        var j = i
                        while (j > first && kotlin.math.abs(x[j]) < thr) j--
                        if (j > first) last = j
                    }
                    break
                }
                i--
            }
        }
        val margin = rate * 30 / 1000
        val from = maxOf(0, first - margin)
        val to = minOf(n, last + 1 + margin)
        val len = to - from
        val fadeIn = minOf(len / 2, rate * 15 / 1000).coerceAtLeast(1)
        val fadeOut = minOf(len / 2, rate * 40 / 1000).coerceAtLeast(1)
        val tail = rate * 100 / 1000
        val out = ShortArray(len + tail)
        for (i in 0 until len) {
            var v = x[from + i].toDouble()
            if (i < fadeIn) v *= i.toDouble() / fadeIn
            val r = len - 1 - i
            if (r < fadeOut) v *= r.toDouble() / fadeOut
            out[i] = v.toInt().coerceIn(-32768, 32767).toShort()
        }
        return toWav(out, rate)
    }

    /** Joins two clips (each one is polished first, so the joint is silent and click-free). */
    fun join(a: ByteArray, b: ByteArray): ByteArray {
        val pa = polish(a)
        val pb = polish(b)
        return fromPcm16(pa.copyOfRange(44, pa.size) + pb.copyOfRange(44, pb.size), sampleRate(a))
    }

    /**
     * Finds the quiet gaps of a clip (10 ms energy windows). Used to learn where each sentence really starts,
     * so the highlighted sentence follows the voice instead of an estimate based on character counts.
     */
    fun pauses(wav: ByteArray, minGapMs: Int = 170): List<Pause> {
        if (wav.size < 44 + 4000) return emptyList()
        val rate = sampleRate(wav)
        val s = samples(wav)
        val win = rate / 100
        val count = s.size / win
        if (count < 10) return emptyList()
        val rms = DoubleArray(count)
        for (w in 0 until count) {
            var acc = 0.0
            val base = w * win
            for (i in 0 until win) {
                val v = s[base + i].toDouble()
                acc += v * v
            }
            rms[w] = kotlin.math.sqrt(acc / win)
        }
        val sorted = rms.sortedArray()
        val loud = sorted[(count * 0.9).toInt().coerceAtMost(count - 1)]
        val thr = maxOf(120.0, loud * 0.06)
        val out = ArrayList<Pause>()
        var runStart = -1
        for (w in 0..count) {
            val quiet = w < count && rms[w] < thr
            if (quiet && runStart < 0) runStart = w
            if (!quiet && runStart >= 0) {
                val lenMs = (w - runStart) * 10
                // ignore the lead-in and the tail: only gaps inside the speech tell where sentences change
                if (lenMs >= minGapMs && runStart > 3 && w < count - 3) out += Pause(runStart * 10L, w * 10L)
                runStart = -1
            }
        }
        return out
    }
}

fun sha256(s: String): String =
    MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

/** Text prepared for speech: no Markdown marks, no table borders. */
fun plainForSpeech(s: String): String = s.lines()
    .filterNot { Regex("^[\\s|:\\-]+$").matches(it) }
    .joinToString("\n") { l ->
        l.replace("**", "").replace("__", "")
            .replace(Regex("^\\s*#{1,6}\\s*"), "")
            .replace(Regex("^\\s*[*\\-•]\\s+"), "")
            .replace("|", " ")
    }.trim()

/** Splits text into speakable chunks. The first one is short so playback starts quickly. */
fun splitForSpeech(text: String, firstMax: Int = 350, max: Int = 1100): List<String> {
    val sentences = text.split(Regex("(?<=[.!?؟۔…])\\s+|\\n+")).map { it.trim() }.filter { it.isNotEmpty() }
    val out = mutableListOf<String>()
    val sb = StringBuilder()
    for (s in sentences) {
        val limit = if (out.isEmpty()) firstMax else max
        if (sb.isNotEmpty() && sb.length + s.length + 1 > limit) {
            out.add(sb.toString())
            sb.clear()
        }
        if (s.length > max) {
            if (sb.isNotEmpty()) { out.add(sb.toString()); sb.clear() }
            s.chunked(max).forEach { out.add(it) }
        } else {
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(s)
        }
    }
    if (sb.isNotEmpty()) out.add(sb.toString())
    return out
}
