package app.pdfreader.ai

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest

/** A silent stretch inside a clip, in milliseconds from the clip start. */
class Pause(val startMs: Long, val endMs: Long) {
    val centerMs: Long get() = (startMs + endMs) / 2
    val lengthMs: Long get() = endMs - startMs
}

object Wav {
    /** Wraps raw 16-bit PCM in a WAV container so any player can open it. */
    fun fromPcm16(pcm: ByteArray, sampleRate: Int, channels: Int = 1): ByteArray {
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray()).putInt(36 + pcm.size).put("WAVE".toByteArray())
        header.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(channels.toShort())
        header.putInt(sampleRate).putInt(sampleRate * channels * 2).putShort((channels * 2).toShort()).putShort(16)
        header.put("data".toByteArray()).putInt(pcm.size)
        return header.array() + pcm
    }

    fun sampleRate(wav: ByteArray): Int =
        if (wav.size < 44) 24000 else ByteBuffer.wrap(wav, 24, 4).order(ByteOrder.LITTLE_ENDIAN).int.takeIf { it in 8000..96000 } ?: 24000

    fun durationMs(wav: ByteArray): Long =
        if (wav.size <= 44) 0L else (wav.size - 44) / 2L * 1000L / sampleRate(wav)

    private fun samples(wav: ByteArray): ShortArray {
        val n = (wav.size - 44) / 2
        val out = ShortArray(n)
        ByteBuffer.wrap(wav, 44, n * 2).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(out)
        return out
    }

    private fun toWav(s: ShortArray, rate: Int): ByteArray {
        val bb = ByteBuffer.allocate(s.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (v in s) bb.putShort(v)
        return fromPcm16(bb.array(), rate)
    }

    /**
     * Cleans one speech clip so that clips can be played back to back without clicks or "static":
     *  - removes the DC offset (constant shift),
     *  - trims digital silence/noise at both ends and aligns to exact zero-crossing,
     *  - smooth S-curve Hann fade-in (15 ms) and fade-out (25 ms) so waveform derivative is zero at boundaries,
     *  - appends a short clean silence (pause between two clips).
     */
    fun polish(wav: ByteArray): ByteArray {
        if (wav.size < 44 + 800) return wav
        val rate = sampleRate(wav)
        val raw = samples(wav)
        val n = raw.size
        if (n < 80) return wav

        var sum = 0L
        for (v in raw) sum += v
        val dc = (sum / n).toInt()
        val x = IntArray(n) { raw[it] - dc }

        var peak = 0
        for (v in x) {
            val a = kotlin.math.abs(v)
            if (a > peak) peak = a
        }
        if (peak == 0) return wav

        val thr = maxOf(160, peak / 40)

        var first = 0
        while (first < n && kotlin.math.abs(x[first]) < thr) first++
        var last = n - 1
        while (last > first && kotlin.math.abs(x[last]) < thr) last--

        if (first >= last) return wav

        // Align to zero-crossings to eliminate abrupt DC edge step
        var zFirst = maxOf(0, first - rate * 15 / 1000)
        while (zFirst < first && zFirst + 1 < n) {
            if ((x[zFirst] >= 0 && x[zFirst + 1] <= 0) || (x[zFirst] <= 0 && x[zFirst + 1] >= 0)) break
            zFirst++
        }
        val from = zFirst

        var zLast = minOf(n - 1, last + rate * 15 / 1000)
        while (zLast > last && zLast > 0) {
            if ((x[zLast] >= 0 && x[zLast - 1] <= 0) || (x[zLast] <= 0 && x[zLast - 1] >= 0)) break
            zLast--
        }
        val to = maxOf(from + 1, zLast + 1)
        val len = to - from
        if (len <= 0) return wav

        val fadeIn = minOf(len / 4, rate * 15 / 1000).coerceAtLeast(1)
        val fadeOut = minOf(len / 4, rate * 25 / 1000).coerceAtLeast(1)
        val tail = rate * 50 / 1000
        val out = ShortArray(len + tail)

        val pi = Math.PI
        for (i in 0 until len) {
            var v = x[from + i].toDouble()
            if (i < fadeIn) {
                val factor = 0.5 * (1.0 - Math.cos(pi * i / fadeIn))
                v *= factor
            }
            val r = len - 1 - i
            if (r < fadeOut) {
                val factor = 0.5 * (1.0 - Math.cos(pi * r / fadeOut))
                v *= factor
            }
            out[i] = v.toInt().coerceIn(-32768, 32767).toShort()
        }
        return toWav(out, rate)
    }

    /** Joins two clips (each one is polished first, so the joint is silent and click-free). */
    fun join(a: ByteArray, b: ByteArray): ByteArray {
        val pa = polish(a)
        val pb = polish(b)
        return fromPcm16(pa.copyOfRange(44, pa.size) + pb.copyOfRange(44, pb.size), sampleRate(a))
    }

    /**
     * Finds the quiet gaps of a clip (10 ms energy windows). Used to learn where each sentence really starts,
     * so the highlighted sentence follows the voice instead of an estimate based on character counts.
     */
    fun pauses(wav: ByteArray, minGapMs: Int = 170): List<Pause> {
        if (wav.size < 44 + 4000) return emptyList()
        val rate = sampleRate(wav)
        val s = samples(wav)
        val win = rate / 100
        val count = s.size / win
        if (count < 10) return emptyList()
        val rms = DoubleArray(count)
        for (w in 0 until count) {
            var acc = 0.0
            val base = w * win
            for (i in 0 until win) {
                val v = s[base + i].toDouble()
                acc += v * v
            }
            rms[w] = kotlin.math.sqrt(acc / win)
        }
        val sorted = rms.sortedArray()
        val loud = sorted[(count * 0.9).toInt().coerceAtMost(count - 1)]
        val thr = maxOf(120.0, loud * 0.06)
        val out = ArrayList<Pause>()
        var runStart = -1
        for (w in 0..count) {
            val quiet = w < count && rms[w] < thr
            if (quiet && runStart < 0) runStart = w
            if (!quiet && runStart >= 0) {
                val lenMs = (w - runStart) * 10
                // ignore the lead-in and the tail: only gaps inside the speech tell where sentences change
                if (lenMs >= minGapMs && runStart > 3 && w < count - 3) out += Pause(runStart * 10L, w * 10L)
                runStart = -1
            }
        }
        return out
    }
}

fun sha256(s: String): String =
    MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

/** Text prepared for speech: no Markdown marks, no table borders. */
fun plainForSpeech(s: String): String = s.lines()
    .filterNot { Regex("^[\\s|:\\-]+$").matches(it) }
    .joinToString("\n") { l ->
        l.replace("**", "").replace("__", "")
            .replace(Regex("^\\s*#{1,6}\\s*"), "")
            .replace(Regex("^\\s*[*\\-•]\\s+"), "")
            .replace("|", " ")
    }.trim()

/** Splits text into speakable chunks. The first one is short so playback starts quickly. */
fun splitForSpeech(text: String, firstMax: Int = 350, max: Int = 1100): List<String> {
    val sentences = text.split(Regex("(?<=[.!?؟۔…])\\s+|\\n+")).map { it.trim() }.filter { it.isNotEmpty() }
    val out = mutableListOf<String>()
    val sb = StringBuilder()
    for (s in sentences) {
        val limit = if (out.isEmpty()) firstMax else max
        if (sb.isNotEmpty() && sb.length + s.length + 1 > limit) {
            out.add(sb.toString())
            sb.clear()
        }
        if (s.length > max) {
            if (sb.isNotEmpty()) { out.add(sb.toString()); sb.clear() }
            s.chunked(max).forEach { out.add(it) }
        } else {
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(s)
        }
    }
    if (sb.isNotEmpty()) out.add(sb.toString())
    return out
}
