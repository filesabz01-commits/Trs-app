package app.pdfreader.ai

/** What the text layer of a PDF page is like. Decides between "use it directly" and "run OCR". */
enum class PageTextKind {
    /** Typed text with a clean, readable text layer: no OCR needed. */
    CLEAN,
    /** No (or almost no) text layer: a scanned page or only a figure: OCR. */
    NONE,
    /** A text layer exists but the characters are broken (bad font encoding, reversed/shaped letters): ignore it, OCR. */
    GARBLED,
}

class TextVerdict(val kind: PageTextKind, val reason: String)

/**
 * Local (free, instant) quality check of a page's text layer, plus the structural clean-up that is applied to
 * clean text. The thresholds are deliberately conservative: when in doubt the page is OCR'd, which is always correct.
 */
object TextQuality {
    private val VOWELS = "aeiouyAEIOUYàáâãäåæèéêëìíîïòóôõöøùúûüýÿœ"

    private fun isArabicScript(c: Char) =
        c in '\u0600'..'\u06FF' || c in '\u0750'..'\u077F' || c in '\uFB50'..'\uFDFF' || c in '\uFE70'..'\uFEFF'

    private fun isPresentationForm(c: Char) = c in '\uFB50'..'\uFDFF' || c in '\uFE70'..'\uFEFF'

    private fun isLatin(c: Char) = c in 'A'..'Z' || c in 'a'..'z' || c in '\u00C0'..'\u024F'

    fun assess(raw: String): TextVerdict {
        var visible = 0
        var broken = 0
        var letters = 0
        var latin = 0
        var arabic = 0
        var shaped = 0
        var otherLetters = 0
        var symbols = 0
        for (c in raw) {
            if (c.isWhitespace()) continue
            visible++
            when {
                c == '\uFFFD' || c in '\uE000'..'\uF8FF' || c in '\u0080'..'\u009F' || (c.code < 32) -> broken++
                isArabicScript(c) -> { letters++; arabic++; if (isPresentationForm(c)) shaped++ }
                isLatin(c) -> { letters++; latin++ }
                c.isLetter() -> { letters++; otherLetters++ }
                c.isDigit() -> {}
                Character.getType(c).let {
                    it == Character.OTHER_SYMBOL.toInt() || it == Character.MODIFIER_SYMBOL.toInt() || it == Character.SURROGATE.toInt()
                } -> symbols++
            }
        }
        broken += Regex("\\(cid:\\d+\\)").findAll(raw).count() * 6
        if (visible < 40) return TextVerdict(PageTextKind.NONE, "لایه‌ی متنی ندارد")
        if (broken * 100 > visible * 3) return TextVerdict(PageTextKind.GARBLED, "کاراکترهای نامعتبر")
        if (symbols * 100 > visible * 20) return TextVerdict(PageTextKind.GARBLED, "نمادهای بی‌معنی")

        val tokens = raw.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (tokens.size >= 12) {
            val single = tokens.count { it.length == 1 && it[0].isLetter() }
            if (single * 100 > tokens.size * 45) return TextVerdict(PageTextKind.GARBLED, "حرف‌های جدا از هم")
            val avg = tokens.sumOf { it.length } / tokens.size
            if (avg > 25) return TextVerdict(PageTextKind.GARBLED, "کلمات چسبیده")
        }
        if (letters > 0 && otherLetters * 100 > letters * 30) return TextVerdict(PageTextKind.GARBLED, "ترکیب نامعمول نوشتارها")
        if (arabic > latin) {
            if (arabic > 0 && shaped * 100 > arabic * 35) return TextVerdict(PageTextKind.GARBLED, "حروف شکل‌یافته/وارونه")
        } else if (latin > 0) {
            val words = tokens.map { w -> w.filter { it.isLetter() } }.filter { it.length >= 3 && !it.all { ch -> ch.isUpperCase() } }
            if (words.size >= 15) {
                val noVowel = words.count { w -> w.none { it in VOWELS } }
                if (noVowel * 100 > words.size * 50) return TextVerdict(PageTextKind.GARBLED, "کلمات بدون واکه (رمزگذاری خراب)")
            }
        }
        return TextVerdict(PageTextKind.CLEAN, "")
    }

    private val pageNumber = Regex("^(page\\s*)?([0-9\u06F0-\u06F9\u0660-\u0669]{1,4}|[ivxlcdm]+)$", RegexOption.IGNORE_CASE)

    private val inddStamp = Regex(".*\\.(indd|idml|ai|psd|qxd)\\s+\\d+.*", RegexOption.IGNORE_CASE)

    private val publisherFooter = Regex(
        "^(downloaded from|wiley online library|see the terms and conditions|terms and conditions|" +
            "all rights reserved|creative commons license|published by|doi:\\s*10\\.|oa articles are governed).*",
        RegexOption.IGNORE_CASE
    )

    // Long copyright / imprint lines that often appear at the bottom of pages (Wiley, Springer, etc.)
    private val copyrightLine = Regex(
        ".*(all rights reserved|john wiley\\s*&\\s*sons|companion website|www\\.wiley\\.com|" +
            "text and data mining and training of artificial intelligence|published \\d{4} by|" +
            "©\\s*\\d{4}|copyright\\s*©|rights for text and data mining).*",
        RegexOption.IGNORE_CASE
    )

    private val publisherUrl = Regex(".*(onlinelibrary\\.wiley\\.com|sciencedirect\\.com|springerlink\\.com|tandfonline\\.com|wiley\\.com/go/).*", RegexOption.IGNORE_CASE)

    // Short table/figure CAPTIONS only — not narrative sentences that mention "Table 4.1 outlines..."
    // Real captions are typically short: "Table 4.1 Items by different groups on P&ID."
    private val tableCaption = Regex(
        "^table\\s+\\d+(\\.\\d+)?\\.?(\\s+[^.]{1,80})?\\.\\s*$",
        RegexOption.IGNORE_CASE
    )
    private val shortTableCell = Regex(
        "^(intention|color used|addition|deletion|comment|dark gray|gray|black|white|red|blue|green|" +
            "yes|no|n/?a|optional|required|must|preferred)\\s*$",
        RegexOption.IGNORE_CASE
    )

    private val runningHeader = Regex(
        // ONLY pipe/bullet/dash separators — NOT period (period is list marker: "1. Text")
        // e.g. "10 | 2 Management of ..." or "Title | 27"
        "^([ivxlcdm]+|[0-9]{1,4})\\s*[|•\\-–—]\\s*.+$|" +
            "^.+[|•\\-–—]\\s*([ivxlcdm]+|[0-9]{1,4})$|" +
            "^\\d{1,3}\\s*\\|\\s*.+$|^.+\\|\\s*\\d{1,3}$",
        RegexOption.IGNORE_CASE
    )

    // Running header that glues section title + page number: "4.2 How to Show Them: Visual Rules 23"
    private val sectionTitleWithPage = Regex(
        "^\\d+(\\.\\d+)+\\s+.{8,70}\\s+\\d{1,3}$"
    )

    // Caption-only lines (short). Long sentences starting with Figure/Table are body text — keep them.
    private val figureCaption = Regex(
        "^(figure|fig\\.?|جدول|شکل)\\s*\\d+(\\.\\d+)*\\.?(\\s+[^.]{1,90})?\\.\\s*$",
        RegexOption.IGNORE_CASE
    )

    // Legal / stamp boilerplate often OCR'd from figure boxes
    private val legalStamp = Regex(
        ".*(this document was prepared exclusively|permit to practice|permit number|engineer and permit stamps|" +
            "subjects to the terms and conditions|legal terms|signature:\\s*-+|date:\\s*-+).*",
        RegexOption.IGNORE_CASE
    )

    private val romanHeader = Regex(
        "^(xxiv|xxiii|xxii|xxi|xx|xix|xviii|xvii|xvi|xv|xiv|xiii|xii|xi|x|ix|viii|vii|vi|v|iv|iii|ii|i)\\s*[|•\\-–—:.]?\\s*(preface|contents|introduction|acknowledgment|acknowledgements|index|foreword|chapter|section).*$",
        RegexOption.IGNORE_CASE
    )

    // Also catch pure short section titles that often appear alone on preface/front-matter pages
    private val shortSectionTitle = Regex(
        "^(preface|contents|introduction|acknowledgment|acknowledgements|foreword|index|abstract|summary)$",
        RegexOption.IGNORE_CASE
    )

    private val diagramFormula = Regex(".*\\b(sizing|specification|development|p&id)\\b.*[+=].*", RegexOption.IGNORE_CASE)

    private val DIAGRAM_LABELS = setOf(
        "process", "control", "operation", "equipment & instruments", "equipment and instruments",
        "location", "regulations: hse", "regulations", "hse", "maintenance",
        "supporting plants", "calculation", "technical", "not technical",
        "p&id development", "sizing or specification", "p&id", "sizing",
        "p&id development guidelines", "p&id demonstration rules", "p&id drafting rules",
        "development guidelines", "demonstration rules", "drafting rules",
        "where should i put this valve?", "what is its symbol?", "what should be the thickness of this symbol?",
        "calculations", "loop diagram", "alarm table", "piping ds", "piping model", "isometrics",
        "mechanical ds", "plant modeling", "as a reference in plant during operation", "loop diagrams",
    )

    /** True only for short figure/table captions, not body sentences like "Table 4.1 outlines..." */
    private fun isCaptionOnly(line: String): Boolean {
        val t = line.trim()
        if (t.length > 110) return false
        if (!Regex("^(figure|fig\\.?|table|جدول|شکل)\\s*\\d+", RegexOption.IGNORE_CASE).containsMatchIn(t)) return false
        // Narrative references keep verbs like outlines/shows/describes
        if (Regex(
                "\\b(outlines?|shows?|showed|showing|describes?|summarizes?|lists?|presents?|provides?|indicates?|explains?)\\b",
                RegexOption.IGNORE_CASE
            ).containsMatchIn(t)
        ) return false
        return figureCaption.matches(t) || tableCaption.matches(t) ||
            Regex("^(figure|fig\\.?|table|جدول|شکل)\\s*\\d+(\\.\\d+)*\\.?\\s*.{0,90}$", RegexOption.IGNORE_CASE).matches(t)
    }

    fun isJunkOrDiagram(line: String): Boolean {
        val trimmed = line.trim()
        if (trimmed.isEmpty()) return true
        // Never drop numbered LIST items: "1. The P&ID sheet..." / "10. Do not try..."
        if (Regex("^\\d{1,2}\\.\\s+\\S.+").matches(trimmed)) return false
        // Never drop real numbered section headings like "3.2 Ownership Block" / "4.2.1 Lines..."
        if (Regex("^\\d+(\\.\\d+)+\\s+\\S.+").matches(trimmed)) {
            // Except pure running-header form: "4.2 Title Words 23" (section + page number only)
            if (sectionTitleWithPage.matches(trimmed)) return true
            return false
        }
        if (pageNumber.matches(trimmed)) return true
        if (inddStamp.matches(trimmed)) return true
        if (publisherFooter.matches(trimmed)) return true
        if (copyrightLine.matches(trimmed)) return true
        if (publisherUrl.matches(trimmed)) return true
        if (runningHeader.matches(trimmed)) return true
        if (sectionTitleWithPage.matches(trimmed)) return true
        if (romanHeader.matches(trimmed)) return true
        if (shortSectionTitle.matches(trimmed)) return true
        if (legalStamp.matches(trimmed)) return true
        if (diagramFormula.matches(trimmed)) return true
        // Captions only when short and not a narrative sentence referring to a table/figure
        if (isCaptionOnly(trimmed)) return true
        if (shortTableCell.matches(trimmed)) return true
        val lower = trimmed.lowercase().removeSuffix(".").trim()
        if (lower in DIAGRAM_LABELS) return true
        if (trimmed in listOf("+", "=", "==", "->", "-->", "|", "—", "–")) return true
        // Very short lines that look like leftover headers (Roman + title fragments)
        if (trimmed.length < 40 && Regex("^[ivxlcdm]+\\s*[|•\\-–—:. ]*(preface|contents|intro|chapter|section)?$", RegexOption.IGNORE_CASE).matches(trimmed)) return true
        // Short lines that are pure color/label cells from tables (often appear without the caption)
        if (trimmed.length <= 24 && lower in setOf(
                "dark gray", "light gray", "gray", "black", "white", "red", "blue", "green",
                "addition", "deletion", "comment", "intention", "color used", "mark up", "markup"
            )) return true
        // Short diagram callout questions / oval labels (≤ 8 words, ends with ? or all Title Case fragments)
        val words = trimmed.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (words.size in 2..8 && (trimmed.endsWith("?") || lower.contains("p&id"))) {
            if (lower.contains("guideline") || lower.contains("rule") || lower.contains("valve") ||
                lower.contains("symbol") || lower.contains("thickness") || lower.contains("where should") ||
                lower.contains("what is") || lower.contains("what should")) return true
        }
        return false
    }

    /** Line that is likely a table row (markdown or multi-column with gaps). */
    fun looksLikeTableRow(line: String): Boolean {
        val t = line.trim()
        if (t.startsWith("|") && t.contains('|', startIndex = 1.coerceAtMost(t.lastIndex))) return true
        if (t.contains('\t')) {
            if (t.split('\t').map { it.trim() }.filter { it.isNotEmpty() }.size >= 2) return true
        }
        val cells = t.split(Regex("\\s{2,}")).map { it.trim() }.filter { it.isNotEmpty() }
        if (cells.size >= 2 && cells.count { it.length <= 48 } >= 2) return true
        return false
    }

    /** Joins lines of the same paragraph, repairs hyphenated line ends, drops metadata & diagram clutter. Free and instant. */
    fun localClean(raw: String): String {
        val lines = raw.replace("\r\n", "\n").replace('\r', '\n').split('\n').map { it.trim() }
        val paragraphs = ArrayList<String>()
        val cur = StringBuilder()
        var prev = ""
        fun flush() { if (cur.isNotBlank()) paragraphs += cur.toString().trim(); cur.clear() }
        for (l in lines) {
            if (l.isEmpty()) { flush(); prev = ""; continue }
            if (isJunkOrDiagram(l)) continue
            // Keep table rows as their own paragraphs so Google/AI can rebuild Markdown tables
            if (looksLikeTableRow(l) || (l.startsWith("|") && l.contains('|'))) {
                flush()
                paragraphs += l
                prev = ""
                continue
            }
            if (cur.isEmpty()) { cur.append(l); prev = l; continue }
            val endsHyphen = prev.endsWith("-") || prev.endsWith("\u00AD")
            val endsSentence = prev.last() in ".!?\u061F:\u2026"
            when {
                endsHyphen && l.first().isLowerCase() -> { cur.setLength(cur.length - 1); cur.append(l) }
                endsSentence && (l.first().isUpperCase() || l.first() in '\u0600'..'\u06FF' || l.first() in "«\"“‘'[") -> {
                    // Check if it's a new paragraph or continuation of body
                    if (prev.length < 50) {
                        flush()
                        cur.append(l)
                    } else {
                        cur.append(' ').append(l)
                    }
                }
                else -> cur.append(' ').append(l)
            }
            prev = l
        }
        flush()
        // Final pass: strip residual front-matter headers and drop pure copyright/publisher paragraphs
        if (paragraphs.isNotEmpty()) {
            val first = paragraphs[0]
            val cleanedFirst = first
                .replace(Regex("^(xxiv|xxiii|xxii|xxi|xx|xix|xviii|xvii|xvi|xv|xiv|xiii|xii|xi|x|ix|viii|vii|vi|v|iv|iii|ii|i)\\s*[|•\\-–—:.]?\\s*(preface|contents|introduction|acknowledgment|acknowledgements|foreword)?\\s*", RegexOption.IGNORE_CASE), "")
                .trim()
            if (cleanedFirst != first) {
                if (cleanedFirst.isBlank()) paragraphs.removeAt(0)
                else paragraphs[0] = cleanedFirst
            }
        }
        paragraphs.removeAll { p ->
            copyrightLine.matches(p) || publisherFooter.matches(p) || publisherUrl.matches(p) ||
                (p.length > 80 && p.contains("All rights reserved", ignoreCase = true) && p.contains("Wiley", ignoreCase = true))
        }
        return paragraphs.joinToString("\n\n")
    }
}
