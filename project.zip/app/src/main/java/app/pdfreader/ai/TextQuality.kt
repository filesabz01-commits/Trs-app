package app.pdfreader.ai

/** What the text layer of a PDF page is like. Decides between "use it directly" and "run OCR". */
enum class PageTextKind {
    /** Typed text with a clean, readable text layer: no OCR needed. */
    CLEAN,
    /** No (or almost no) text layer: a scanned page or only a figure: OCR. */
    NONE,
    /** A text layer exists but the characters are broken (bad font encoding, reversed/shaped letters): ignore it, OCR. */
    GARBLED,
}

class TextVerdict(val kind: PageTextKind, val reason: String)

/**
 * Local (free, instant) quality check of a page's text layer, plus the structural clean-up that is applied to
 * clean text. The thresholds are deliberately conservative: when in doubt the page is OCR'd, which is always correct.
 */
object TextQuality {
    private val VOWELS = "aeiouyAEIOUYàáâãäåæèéêëìíîïòóôõöøùúûüýÿœ"

    private fun isArabicScript(c: Char) =
        c in '\u0600'..'\u06FF' || c in '\u0750'..'\u077F' || c in '\uFB50'..'\uFDFF' || c in '\uFE70'..'\uFEFF'

    private fun isPresentationForm(c: Char) = c in '\uFB50'..'\uFDFF' || c in '\uFE70'..'\uFEFF'

    private fun isLatin(c: Char) = c in 'A'..'Z' || c in 'a'..'z' || c in '\u00C0'..'\u024F'

    fun assess(raw: String): TextVerdict {
        var visible = 0
        var broken = 0
        var letters = 0
        var latin = 0
        var arabic = 0
        var shaped = 0
        var otherLetters = 0
        var symbols = 0
        for (c in raw) {
            if (c.isWhitespace()) continue
            visible++
            when {
                c == '\uFFFD' || c in '\uE000'..'\uF8FF' || c in '\u0080'..'\u009F' || (c.code < 32) -> broken++
                isArabicScript(c) -> { letters++; arabic++; if (isPresentationForm(c)) shaped++ }
                isLatin(c) -> { letters++; latin++ }
                c.isLetter() -> { letters++; otherLetters++ }
                c.isDigit() -> {}
                Character.getType(c).let {
                    it == Character.OTHER_SYMBOL.toInt() || it == Character.MODIFIER_SYMBOL.toInt() || it == Character.SURROGATE.toInt()
                } -> symbols++
            }
        }
        broken += Regex("\\(cid:\\d+\\)").findAll(raw).count() * 6
        if (visible < 40) return TextVerdict(PageTextKind.NONE, "لایه‌ی متنی ندارد")
        if (broken * 100 > visible * 3) return TextVerdict(PageTextKind.GARBLED, "کاراکترهای نامعتبر")
        if (symbols * 100 > visible * 20) return TextVerdict(PageTextKind.GARBLED, "نمادهای بی‌معنی")

        val tokens = raw.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (tokens.size >= 12) {
            val single = tokens.count { it.length == 1 && it[0].isLetter() }
            if (single * 100 > tokens.size * 30) return TextVerdict(PageTextKind.GARBLED, "حرف‌های جدا از هم")
            val avg = tokens.sumOf { it.length } / tokens.size
            if (avg > 25) return TextVerdict(PageTextKind.GARBLED, "کلمات چسبیده")
        }
        if (letters > 0 && otherLetters * 100 > letters * 30) return TextVerdict(PageTextKind.GARBLED, "ترکیب نامعمول نوشتارها")
        if (arabic > latin) {
            if (arabic > 0 && shaped * 100 > arabic * 35) return TextVerdict(PageTextKind.GARBLED, "حروف شکل‌یافته/وارونه")
        } else if (latin > 0) {
            val words = tokens.map { w -> w.filter { it.isLetter() } }.filter { it.length >= 3 && !it.all { ch -> ch.isUpperCase() } }
            if (words.size >= 15) {
                val noVowel = words.count { w -> w.none { it in VOWELS } }
                if (noVowel * 100 > words.size * 35) return TextVerdict(PageTextKind.GARBLED, "کلمات بدون واکه (رمزگذاری خراب)")
            }
        }
        return TextVerdict(PageTextKind.CLEAN, "")
    }

    private val pageNumber = Regex("^(page\\s*)?([0-9\u06F0-\u06F9\u0660-\u0669]{1,4}|[ivxlcdm]+)$", RegexOption.IGNORE_CASE)

    private val inddStamp = Regex(".*\\.(indd|idml|ai|psd|qxd)\\s+\\d+.*", RegexOption.IGNORE_CASE)

    private val publisherFooter = Regex(
        "^(downloaded from|wiley online library|see the terms and conditions|terms and conditions|" +
            "all rights reserved|creative commons license|published by|doi:\\s*10\\.|oa articles are governed).*",
        RegexOption.IGNORE_CASE
    )

    private val publisherUrl = Regex(".*(onlinelibrary\\.wiley\\.com|sciencedirect\\.com|springerlink\\.com|tandfonline\\.com).*", RegexOption.IGNORE_CASE)

    private val runningHeader = Regex(
        "^([ivxlcdm]+|[0-9]{1,4})\\s*[|•\\-–—]\\s*.*$|^.*[|•\\-–—]\\s*([ivxlcdm]+|[0-9]{1,4})$",
        RegexOption.IGNORE_CASE
    )

    private val romanHeader = Regex(
        "^(xxiv|xxiii|xxii|xxi|xx|xix|xviii|xvii|xvi|xv|xiv|xiii|xii|xi|x|ix|viii|vii|vi|v|iv|iii|ii|i)\\s+(preface|contents|introduction|acknowledgment|index|foreword).*$",
        RegexOption.IGNORE_CASE
    )

    private val diagramFormula = Regex(".*\\b(sizing|specification|development|p&id)\\b.*[+=].*", RegexOption.IGNORE_CASE)

    private val DIAGRAM_LABELS = setOf(
        "process", "control", "operation", "equipment & instruments", "equipment and instruments",
        "location", "regulations: hse", "regulations", "hse", "maintenance",
        "supporting plants", "calculation", "technical", "not technical",
        "p&id development", "sizing or specification", "p&id", "sizing"
    )

    fun isJunkOrDiagram(line: String): Boolean {
        val trimmed = line.trim()
        if (trimmed.isEmpty()) return true
        if (pageNumber.matches(trimmed)) return true
        if (inddStamp.matches(trimmed)) return true
        if (publisherFooter.matches(trimmed)) return true
        if (publisherUrl.matches(trimmed)) return true
        if (runningHeader.matches(trimmed)) return true
        if (romanHeader.matches(trimmed)) return true
        if (diagramFormula.matches(trimmed)) return true
        val lower = trimmed.lowercase().removeSuffix(".").trim()
        if (lower in DIAGRAM_LABELS) return true
        if (trimmed in listOf("+", "=", "==", "->", "-->", "|", "—", "–")) return true
        return false
    }

    /** Joins lines of the same paragraph, repairs hyphenated line ends, drops metadata & diagram clutter. Free and instant. */
    fun localClean(raw: String): String {
        val lines = raw.replace("\r\n", "\n").replace('\r', '\n').split('\n').map { it.trim() }
        val paragraphs = ArrayList<String>()
        val cur = StringBuilder()
        var prev = ""
        fun flush() { if (cur.isNotBlank()) paragraphs += cur.toString().trim(); cur.clear() }
        for (l in lines) {
            if (l.isEmpty()) { flush(); prev = ""; continue }
            if (isJunkOrDiagram(l)) continue
            if (l.startsWith("|") && l.endsWith("|")) { flush(); paragraphs += l; prev = ""; continue }
            if (cur.isEmpty()) { cur.append(l); prev = l; continue }
            val endsHyphen = prev.endsWith("-") || prev.endsWith("\u00AD")
            val endsSentence = prev.last() in ".!?\u061F:\u2026"
            when {
                endsHyphen && l.first().isLowerCase() -> { cur.setLength(cur.length - 1); cur.append(l) }
                endsSentence && (l.first().isUpperCase() || l.first() in '\u0600'..'\u06FF' || l.first() in "«\"“‘'[") -> {
                    // Check if it's a new paragraph or continuation of body
                    if (prev.length < 50) {
                        flush()
                        cur.append(l)
                    } else {
                        cur.append(' ').append(l)
                    }
                }
                else -> cur.append(' ').append(l)
            }
            prev = l
        }
        flush()
        return paragraphs.joinToString("\n\n")
    }
}
