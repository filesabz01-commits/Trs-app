package app.pdfreader.ai

import android.util.Base64
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

class GeminiProvider : AiProvider {
    override suspend fun generate(
        baseUrl: String,
        model: String,
        apiKey: String,
        req: AiRequest,
        onPartial: ((String) -> Unit)?,
    ): AiResult = guarded {
        // First try with "thinking" switched off (much faster for translation/OCR).
        // If this model rejects that setting, retry once without it.
        val first = attempt(baseUrl, model, apiKey, req, onPartial, thinkingOff = true)
        if (first is AiResult.Fail && first.kind == FailKind.BAD_REQUEST &&
            first.detail.lowercase().contains("think")
        ) attempt(baseUrl, model, apiKey, req, onPartial, thinkingOff = false) else first
    }

    private suspend fun attempt(
        baseUrl: String,
        model: String,
        apiKey: String,
        req: AiRequest,
        onPartial: ((String) -> Unit)?,
        thinkingOff: Boolean,
    ): AiResult {
        val base = "${baseUrl.trimEnd('/')}/v1beta/models/$model"
        val url = if (onPartial != null) "$base:streamGenerateContent?alt=sse" else "$base:generateContent"

        val parts = JSONArray()
        req.imageJpeg?.let {
            parts.put(
                JSONObject().put(
                    "inline_data",
                    JSONObject().put("mime_type", "image/jpeg")
                        .put("data", Base64.encodeToString(it, Base64.NO_WRAP)),
                )
            )
        }
        parts.put(JSONObject().put("text", req.prompt))
        val gen = JSONObject().put("temperature", 0.2).put("maxOutputTokens", 8192)
        if (thinkingOff) gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", gen)
        req.system?.let {
            body.put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", it))))
        }
        val headers = mapOf("x-goog-api-key" to apiKey)

        if (onPartial == null) {
            val res = postJson(url, headers, body.toString())
            return if (res.code in 200..299) parse(res.body) else classifyError(res.code, res.body)
        }

        val acc = StringBuilder()
        var finish = ""
        var block = ""
        var streamError: AiResult.Fail? = null
        val res = postStream(url, headers, body.toString()) { line ->
            if (!line.startsWith("data:")) return@postStream
            val payload = line.removePrefix("data:").trim()
            if (payload.isEmpty()) return@postStream
            val j = try { JSONObject(payload) } catch (e: JSONException) { return@postStream }
            j.optJSONObject("error")?.let { err ->
                streamError = classifyError(err.optInt("code", 500), payload)
                return@postStream
            }
            j.optJSONObject("promptFeedback")?.optString("blockReason")?.let { if (it.isNotEmpty()) block = it }
            val cand = j.optJSONArray("candidates")?.optJSONObject(0) ?: return@postStream
            cand.optString("finishReason").takeIf { it.isNotEmpty() }?.let { finish = it }
            val ps = cand.optJSONObject("content")?.optJSONArray("parts")
            if (ps != null) {
                var added = false
                for (i in 0 until ps.length()) {
                    val t = ps.getJSONObject(i).optString("text", "")
                    if (t.isNotEmpty()) { acc.append(t); added = true }
                }
                if (added) onPartial(acc.toString())
            }
        }
        if (res.code !in 200..299) return classifyError(res.code, res.body)
        val err = streamError
        if (err != null) return err // an error in the middle of the stream means the text is incomplete
        val text = acc.toString().trim()
        if (text.isEmpty()) {
            val blocked = block.isNotEmpty() || finish == "SAFETY" || finish == "RECITATION" || finish == "PROHIBITED_CONTENT"
            return if (blocked) AiResult.Fail(FailKind.BLOCKED, block.ifEmpty { finish })
            else AiResult.Fail(FailKind.EMPTY, finish.ifEmpty { "empty stream" })
        }
        if (finish.isEmpty()) return AiResult.Fail(FailKind.SERVER, "stream ended early")
        if (finish == "MAX_TOKENS") return AiResult.Fail(FailKind.EMPTY, "MAX_TOKENS: output too long")
        return AiResult.Ok(text)
    }

    override suspend fun synthesize(
        baseUrl: String,
        model: String,
        apiKey: String,
        text: String,
        voice: String,
    ): AiResult = guarded {
        val url = "${baseUrl.trimEnd('/')}/v1beta/models/$model:generateContent"
        val speech = JSONObject().put(
            "voiceConfig",
            JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice.ifBlank { "Kore" })),
        )
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text)))))
            .put(
                "generationConfig",
                JSONObject().put("responseModalities", JSONArray().put("AUDIO")).put("speechConfig", speech),
            )
        val res = postJson(url, mapOf("x-goog-api-key" to apiKey), body.toString())
        if (res.code !in 200..299) return@guarded classifyError(res.code, res.body)
        val parts = JSONObject(res.body).optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")
        var pcm: ByteArray? = null
        var rate = 24000
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val part = parts.getJSONObject(i)
                val d = part.optJSONObject("inlineData") ?: part.optJSONObject("inline_data") ?: continue
                pcm = Base64.decode(d.optString("data"), Base64.DEFAULT)
                val mime = d.optString("mimeType", d.optString("mime_type", ""))
                Regex("rate=(\\d+)").find(mime)?.groupValues?.get(1)?.toIntOrNull()?.let { rate = it }
                break
            }
        }
        val bytes = pcm
        if (bytes == null || bytes.isEmpty()) AiResult.Fail(FailKind.EMPTY, "no audio returned")
        else AiResult.Ok("", Wav.fromPcm16(bytes, rate))
    }

    private fun parse(json: String): AiResult {
        val root = JSONObject(json)
        val cands = root.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            val block = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            return if (block.isNotEmpty()) AiResult.Fail(FailKind.BLOCKED, block)
            else AiResult.Fail(FailKind.EMPTY, "no candidates")
        }
        val c = cands.getJSONObject(0)
        val ps = c.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (ps != null) for (i in 0 until ps.length()) sb.append(ps.getJSONObject(i).optString("text", ""))
        val text = sb.toString().trim()
        if (text.isEmpty()) {
            val fr = c.optString("finishReason")
            val kind = if (fr == "SAFETY" || fr == "RECITATION" || fr == "PROHIBITED_CONTENT") FailKind.BLOCKED else FailKind.EMPTY
            return AiResult.Fail(kind, fr)
        }
        if (c.optString("finishReason") == "MAX_TOKENS") return AiResult.Fail(FailKind.EMPTY, "MAX_TOKENS: output too long")
        return AiResult.Ok(text)
    }
}
