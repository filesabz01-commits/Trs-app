package app.pdfreader.ai

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject

class GeminiProvider : AiProvider {
    override suspend fun generate(baseUrl: String, model: String, apiKey: String, req: AiRequest): AiResult =
        guarded {
            val url = "${baseUrl.trimEnd('/')}/v1beta/models/$model:generateContent"
            val parts = JSONArray()
            req.imageJpeg?.let {
                parts.put(
                    JSONObject().put(
                        "inline_data",
                        JSONObject().put("mime_type", "image/jpeg")
                            .put("data", Base64.encodeToString(it, Base64.NO_WRAP)),
                    )
                )
            }
            parts.put(JSONObject().put("text", req.prompt))
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
                .put("generationConfig", JSONObject().put("temperature", 0.2))
            req.system?.let {
                body.put(
                    "system_instruction",
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", it))),
                )
            }
            val res = postJson(url, mapOf("x-goog-api-key" to apiKey), body.toString())
            if (res.code in 200..299) parse(res.body) else classifyError(res.code, res.body)
        }

    private fun parse(json: String): AiResult {
        val root = JSONObject(json)
        val cands = root.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            val block = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            return if (block.isNotEmpty()) AiResult.Fail(FailKind.BLOCKED, block)
            else AiResult.Fail(FailKind.EMPTY, "no candidates")
        }
        val c = cands.getJSONObject(0)
        val parts = c.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
        val text = sb.toString().trim()
        if (text.isEmpty()) {
            val fr = c.optString("finishReason")
            val kind = if (fr == "SAFETY" || fr == "RECITATION" || fr == "PROHIBITED_CONTENT") FailKind.BLOCKED else FailKind.EMPTY
            return AiResult.Fail(kind, fr)
        }
        return AiResult.Ok(text)
    }
}
