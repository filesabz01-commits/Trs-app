package app.pdfreader.ai

enum class Capability { TEXT, VISION }

enum class KeyStatus { ACTIVE, RATE_LIMITED, DAILY_QUOTA_EXCEEDED, INVALID, TEMPORARILY_UNAVAILABLE, DISABLED }

enum class FailKind { RATE_LIMIT, DAILY_QUOTA, INVALID_KEY, NETWORK, TIMEOUT, SERVER, BAD_REQUEST, BLOCKED, EMPTY }

enum class AiTask { EXTRACT, TRANSLATE, EXPLAIN, SUMMARIZE }

class AiRequest(
    val prompt: String,
    val system: String? = null,
    val imageJpeg: ByteArray? = null,
)

sealed interface AiResult {
    class Ok(val text: String) : AiResult
    class Fail(val kind: FailKind, val detail: String, val retryAfterMs: Long? = null) : AiResult
}

/** Generic provider contract. Router and UI never know which concrete provider is used. */
interface AiProvider {
    suspend fun generate(baseUrl: String, model: String, apiKey: String, req: AiRequest): AiResult
}

object ProviderTypes {
    const val GEMINI = "GEMINI"
    const val OPENAI = "OPENAI"
    fun defaultBaseUrl(type: String) =
        if (type == GEMINI) "https://generativelanguage.googleapis.com" else "https://api.openai.com/v1"
    fun label(type: String) = if (type == GEMINI) "Gemini" else "سازگار با OpenAI"
}
