package app.pdfreader.ai

enum class Capability { TEXT, VISION, TTS }

enum class KeyStatus { ACTIVE, RATE_LIMITED, DAILY_QUOTA_EXCEEDED, INVALID, TEMPORARILY_UNAVAILABLE, DISABLED }

enum class FailKind { RATE_LIMIT, DAILY_QUOTA, INVALID_KEY, NETWORK, TIMEOUT, SERVER, BAD_REQUEST, MODEL_UNAVAILABLE, BLOCKED, EMPTY }

enum class AiTask { EXTRACT, TRANSLATE, EXPLAIN, SUMMARIZE, TTS }

class AiRequest(
    val prompt: String,
    val system: String? = null,
    val imageJpeg: ByteArray? = null,
    val task: AiTask = AiTask.EXTRACT,
    val maxOutputTokens: Int? = null,
)

sealed interface AiResult {
    class Ok(
        val text: String,
        val audio: ByteArray? = null,
        val promptTokens: Int = 0,
        val candidatesTokens: Int = 0,
        val thoughtsTokens: Int = 0,
    ) : AiResult
    class Fail(val kind: FailKind, val detail: String, val retryAfterMs: Long? = null) : AiResult
}

/** Generic provider contract. Router and UI never know which concrete provider is used. */
interface AiProvider {
    suspend fun generate(
        baseUrl: String,
        model: String,
        apiKey: String,
        req: AiRequest,
        onPartial: ((String) -> Unit)? = null,
    ): AiResult

    /** Text-to-speech. Providers without TTS simply inherit this "not supported" answer. */
    suspend fun synthesize(
        baseUrl: String,
        model: String,
        apiKey: String,
        text: String,
        voice: String,
    ): AiResult = AiResult.Fail(FailKind.BAD_REQUEST, "این provider تبدیل متن به صدا را پشتیبانی نمی‌کند")
}

data class Lang(val code: String, val label: String, val english: String)

object Languages {
    val all = listOf(
        Lang("auto", "تشخیص خودکار", "auto-detected language"),
        Lang("en", "English", "English"),
        Lang("fa", "فارسی", "Persian"),
        Lang("ar", "العربية", "Arabic"),
        Lang("de", "Deutsch", "German"),
        Lang("fr", "Français", "French"),
        Lang("tr", "Türkçe", "Turkish"),
        Lang("ru", "Русский", "Russian"),
        Lang("es", "Español", "Spanish"),
        Lang("it", "Italiano", "Italian"),
        Lang("zh", "中文", "Chinese"),
    )
    val targets = all.filter { it.code != "auto" }
    fun byCode(c: String): Lang = all.firstOrNull { it.code == c } ?: all.first { it.code == "en" }
}

object ProviderTypes {
    const val GEMINI = "GEMINI"
    const val OPENAI = "OPENAI"
    fun defaultBaseUrl(type: String) =
        if (type == GEMINI) "https://generativelanguage.googleapis.com" else "https://api.openai.com/v1"
    fun label(type: String) = if (type == GEMINI) "Gemini" else "سازگار با OpenAI"
}

/**
 * Model ladders. Deprecated IDs (e.g. gemini-2.5-flash-lite) are omitted so the router never
 * wastes a round-trip on 404 MODEL_UNAVAILABLE.
 * LITE_FIRST is used for translation/OCR to minimise tokens; FLASH_FIRST for explain/summarize.
 */
object GeminiModels {
    // Nov 2026: 2.0/1.5 retired; 2.5 often 404 for new keys — use 3.x stable IDs
    val TEXT = listOf(
        "gemini-3.5-flash-lite",
        "gemini-3.1-flash-lite",
        "gemini-3.8-flash",
        "gemini-3.6-flash",
        "gemini-2.5-flash-lite",
        "gemini-2.5-flash",
    )
    val LITE_FIRST = listOf(
        "gemini-3.5-flash-lite",
        "gemini-3.1-flash-lite",
        "gemini-3.8-flash",
        "gemini-3.6-flash",
        "gemini-2.5-flash-lite",
        "gemini-2.5-flash",
    )
    val FLASH_FIRST = listOf(
        "gemini-3.8-flash",
        "gemini-3.6-flash",
        "gemini-3.5-flash-lite",
        "gemini-3.1-flash-lite",
        "gemini-2.5-flash",
        "gemini-2.5-flash-lite",
    )
    /** Cheapest / lite TTS first — only fall through on hard failure (quota/404), not preference. */
    val TTS = listOf(
        "gemini-3.8-flash-lite-tts",
        "gemini-3.8-flash-tts",
        "gemini-2.5-flash-preview-tts",
    )
    /** preferredModel outside this set is ignored (avoids pinning retired IDs). */
    val KNOWN: Set<String> = (TEXT + TTS).toSet()
}
