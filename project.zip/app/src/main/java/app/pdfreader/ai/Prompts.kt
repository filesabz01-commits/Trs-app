package app.pdfreader.ai

enum class ReadingProfile(val label: String, val hint: String) {
    GENERAL("عمومی", ""),
    TECHNICAL(
        "فنی / مهندسی",
        "This is an engineering/technical text. Preserve technical terms, acronyms (e.g. P&ID, PSV), units, " +
            "tag numbers, formulas and numbering exactly. Use standard engineering terminology in the target " +
            "language and keep the English term in parentheses on first use when ambiguous.",
    ),
    ACADEMIC(
        "آکادمیک",
        "This is an academic text. Keep a precise scholarly register, keep citations and references as they are.",
    ),
    MEDICAL(
        "پزشکی",
        "This is a medical text. Use accurate medical terminology; keep drug names, doses and units exactly.",
    ),
    LITERATURE(
        "ادبیات",
        "This is literary text. Favor natural, elegant phrasing and preserve tone and style.",
    ),
    CUSTOM("سفارشی", ""),
}

/** Languages are stored as codes ("auto", "en", "fa", ...) — see [Languages]. */
data class ReadingSettings(
    val sourceLanguage: String = "auto",
    val targetLanguage: String = "fa",
    val profile: ReadingProfile = ReadingProfile.TECHNICAL,
    val customInstruction: String = "",
    val preferredModel: String = "",
    val persistOcr: Boolean = false,
)

object Prompts {
    /** Marker the model returns for pages that are only figures / photos / diagrams. */
    const val NO_TEXT = "[[NO_TEXT]]"

    private fun hint(s: ReadingSettings) =
        (if (s.profile == ReadingProfile.CUSTOM) s.customInstruction else s.profile.hint)
            .let { if (it.isBlank()) "" else "\nAdditional instructions: $it" }

    private fun srcName(s: ReadingSettings) =
        if (s.sourceLanguage == "auto") "the language of the text (detect it automatically)"
        else Languages.byCode(s.sourceLanguage).english

    private fun tgtName(s: ReadingSettings) = Languages.byCode(s.targetLanguage).english

    /** Step 1 (vision): body text of the page only, cleaned, in the original language. */
    fun buildExtract(s: ReadingSettings, jpeg: ByteArray): AiRequest {
        val prompt = """
            You are given an image of one page of a book or document. Extract ONLY the main body text of the page, ready to be translated or read aloud.
            Keep: scientific and technical content, definitions, numbered lists, equations (as plain text), and the content of tables as simple lines.
            Remove: running headers and footers, page numbers, repeated text, unnecessary footnotes, figure/photo/diagram captions, and any text that is only part of an image (labels, axis values, callouts).
            Do not summarize, translate, explain or add anything. Keep the original language (${srcName(s)}).
            Separate paragraphs with a blank line, join lines that were only broken by the layout, and repair words hyphenated at line ends.
            If the page contains only figures, photos, charts or diagrams and no substantial running body text, output exactly: $NO_TEXT
            Output only the text, with no preface and no closing remarks.
        """.trimIndent()
        return AiRequest(prompt = prompt, imageJpeg = jpeg)
    }

    /** Step 2 (text only): translate / explain / summarize the already extracted text. */
    fun buildText(task: AiTask, s: ReadingSettings, text: String): AiRequest {
        val tgt = tgtName(s)
        val body = when (task) {
            AiTask.TRANSLATE ->
                "Translate the text below from ${srcName(s)} into $tgt. Separate paragraphs with a blank line. " +
                    "Preserve numbering, units, formulas, acronyms and equipment/tag codes; do not translate code or " +
                    "part numbers. Use natural, correct $tgt punctuation. Output only the translation."
            AiTask.EXPLAIN ->
                "Explain the text below in $tgt in clear, simple language, as to a motivated student: define the key " +
                    "terms first, then walk through the ideas step by step. Output only the explanation."
            AiTask.SUMMARIZE ->
                "Summarize the text below in $tgt as 4 to 8 concise bullet points. Output only the summary."
            AiTask.EXTRACT -> ""
        }
        return AiRequest(prompt = "$body${hint(s)}\n\nTEXT:\n$text")
    }
}
