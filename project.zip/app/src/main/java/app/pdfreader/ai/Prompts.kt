package app.pdfreader.ai

enum class ReadingProfile(val label: String, val hint: String) {
    GENERAL("عمومی", ""),
    TECHNICAL(
        "فنی / مهندسی",
        "This is an engineering/technical text. Preserve technical terms, acronyms (e.g. P&ID, PSV), units, " +
            "tag numbers, formulas and numbering exactly. Use standard engineering terminology in the target " +
            "language and keep the English term in parentheses on first use when ambiguous.",
    ),
    ACADEMIC(
        "آکادمیک",
        "This is an academic text. Keep a precise scholarly register, keep citations and references as they are.",
    ),
    MEDICAL(
        "پزشکی",
        "This is a medical text. Use accurate medical terminology; keep drug names, doses and units exactly.",
    ),
    LITERATURE(
        "ادبیات",
        "This is literary text. Favor natural, elegant phrasing and preserve tone and style.",
    ),
    CUSTOM("سفارشی", ""),
}

data class ReadingSettings(
    val targetLanguage: String = "فارسی",
    val profile: ReadingProfile = ReadingProfile.TECHNICAL,
    val customInstruction: String = "",
)

object Prompts {
    fun build(task: AiTask, s: ReadingSettings, jpeg: ByteArray): AiRequest {
        val lang = s.targetLanguage.ifBlank { "فارسی" }
        val hint = if (s.profile == ReadingProfile.CUSTOM) s.customInstruction else s.profile.hint
        val common = "You are given an image of one page of a document. Ignore running headers, footers and " +
            "page numbers. Mention figures only if they carry essential information. Keep the paragraph " +
            "structure; render tables as simple markdown tables. Output only the result, with no preface " +
            "and no closing remarks."
        val body = when (task) {
            AiTask.EXTRACT ->
                "Transcribe all body text of the page exactly as written, in its original language. Do not translate or summarize."
            AiTask.TRANSLATE ->
                "Translate the text on the page into $lang. Separate paragraphs with a blank line. Preserve " +
                    "numbering, units, formulas, acronyms and equipment/tag codes; do not translate code or part " +
                    "numbers. Use natural, correct $lang punctuation."
            AiTask.EXPLAIN ->
                "Explain the content of this page in $lang in clear, simple language, as to a motivated " +
                    "student: define the key terms first, then walk through the ideas step by step."
            AiTask.SUMMARIZE ->
                "Summarize this page in $lang as 4 to 8 concise bullet points."
        }
        val extra = if (hint.isNotBlank()) "\nAdditional instructions: $hint" else ""
        return AiRequest(prompt = "$body\n$common$extra", imageJpeg = jpeg)
    }
}
