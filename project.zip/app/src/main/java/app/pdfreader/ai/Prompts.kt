package app.pdfreader.ai

enum class ReadingProfile(val label: String, val hint: String) {
    GENERAL("عمومی", ""),
    TECHNICAL(
        "فنی / مهندسی",
        "This is an engineering/technical text. Preserve technical terms, acronyms (e.g. P&ID, PSV), units, " +
            "tag numbers, formulas and numbering exactly. Use standard engineering terminology in the target " +
            "language and keep the English term in parentheses on first use when ambiguous.",
    ),
    ACADEMIC(
        "آکادمیک",
        "This is an academic text. Keep a precise scholarly register, keep citations and references as they are.",
    ),
    MEDICAL(
        "پزشکی",
        "This is a medical text. Use accurate medical terminology; keep drug names, doses and units exactly.",
    ),
    LITERATURE(
        "ادبیات",
        "This is literary text. Favor natural, elegant phrasing and preserve tone and style.",
    ),
    CUSTOM("سفارشی", ""),
}

/** Languages are stored as codes ("auto", "en", "fa", ...) — see [Languages]. */
data class ReadingSettings(
    val sourceLanguage: String = "auto",
    val targetLanguage: String = "fa",
    val profile: ReadingProfile = ReadingProfile.TECHNICAL,
    val customInstruction: String = "",
    val preferredModel: String = "",
    val persistOcr: Boolean = false,
    val bilingual: Boolean = false,
    val voice: String = "Kore",
)

object Prompts {
    /** Marker the model returns for pages that are only figures / photos / diagrams. */
    const val NO_TEXT = "[[NO_TEXT]]"

    private fun hint(s: ReadingSettings) =
        (if (s.profile == ReadingProfile.CUSTOM) s.customInstruction else s.profile.hint)
            .let { if (it.isBlank()) "" else "\nAdditional instructions: $it" }

    private fun srcName(s: ReadingSettings) =
        if (s.sourceLanguage == "auto") "the language of the text (detect it automatically)"
        else Languages.byCode(s.sourceLanguage).english

    private fun tgtName(s: ReadingSettings) = Languages.byCode(s.targetLanguage).english

    /** Step 1 (vision): body text of the page only, cleaned, in the original language. */
    fun buildExtract(s: ReadingSettings, jpeg: ByteArray): AiRequest {
        val prompt = """
            You are given an image of one page of a book or document. Extract ONLY the main body text of the page, ready to be translated or read aloud.
            Keep: scientific and technical content, definitions, numbered lists, boxed notes, equations (as plain text).
            Tables: output every table as a Markdown table (header row, a |---| separator row, then the rows) with all rows and columns.
            Completeness matters: never omit a body paragraph, list item, boxed note or table row. If you are unsure whether something is body text, keep it.
            Remove: running headers and footers, page numbers, repeated text, unnecessary footnotes, figure/photo/diagram captions, and any text that is only part of an image (labels, axis values, callouts).
            Do not summarize, translate, explain or add anything. Keep the original language (${srcName(s)}).
            Separate paragraphs with a blank line, join lines that were only broken by the layout, and repair words hyphenated at line ends.
            If the page contains only figures, photos, charts or diagrams and no substantial running body text, output exactly: $NO_TEXT
            Output only the text, with no preface and no closing remarks.
        """.trimIndent()
        return AiRequest(prompt = prompt, imageJpeg = jpeg)
    }

    /** Step 2 (text only): translate / explain / summarize the already extracted text. */
    fun buildText(task: AiTask, s: ReadingSettings, text: String): AiRequest {
        val tgt = tgtName(s)
        val body = when (task) {
            AiTask.TRANSLATE ->
                "Translate the text below from ${srcName(s)} into $tgt. Separate paragraphs with a blank line. " +
                    "Preserve numbering, units, formulas, acronyms and equipment/tag codes; do not translate code or " +
                    "part numbers. Use natural, correct $tgt punctuation. " +
                    "Markdown tables must stay Markdown tables with exactly the same rows and columns (translate only the cell text). " +
                    "Translate every paragraph completely; do not shorten or skip anything. Output only the translation."
            AiTask.EXPLAIN ->
                "Explain the text below in $tgt in clear, simple language, as to a motivated student: define the key " +
                    "terms first, then walk through the ideas step by step. Output only the explanation."
            AiTask.SUMMARIZE ->
                "Summarize the text below in $tgt as 4 to 8 concise bullet points. Output only the summary."
            AiTask.EXTRACT -> ""
        }
        return AiRequest(prompt = "$body${hint(s)}\n\nTEXT:\n$text")
    }

    enum class RangeMode { FULL, PART, MERGE }

    /** Review summary for a range of pages (single pass, one part of a long range, or merging the parts). */
    fun buildRangeSummary(s: ReadingSettings, from: Int, to: Int, text: String, mode: RangeMode): AiRequest {
        val tgt = tgtName(s)
        val intro = when (mode) {
            RangeMode.FULL -> "The text below is pages ${from + 1} to ${to + 1} of a book. Write a clear, well-structured REVIEW SUMMARY in $tgt so a student can revise quickly: " +
                "short headings, bullet points with the key ideas, important definitions and terms (keep the original English term in parentheses), key numbers/formulas, " +
                "and a 3-line recap at the end. Use only the given text; do not invent facts."
            RangeMode.PART -> "This is one part of pages ${from + 1} to ${to + 1} of a book. Summarize it densely in $tgt, keeping every key fact, definition, term and number " +
                "(it will be merged with other parts later). Use only the given text."
            RangeMode.MERGE -> "Below are partial summaries of consecutive parts of pages ${from + 1} to ${to + 1} of a book. Merge them into ONE coherent, well-structured review summary in $tgt " +
                "with short headings, bullet points, key terms (English term in parentheses), key numbers/formulas and a 3-line recap. Remove repetition; do not invent facts."
        }
        return AiRequest(prompt = "$intro${hint(s)}\n\nTEXT:\n$text")
    }

    /** Chat about the page the reader is on. */
    fun buildChat(s: ReadingSettings, page: Int, pageText: String, history: String, question: String): AiRequest {
        val tgt = tgtName(s)
        val system = "You are a friendly, precise study assistant inside a PDF reader. The user is reading a book and asks about the page text provided. " +
            "Answer from the page text first; if the answer is not on the page, say so briefly and then answer from general knowledge. " +
            "Reply in the language of the user's question; if it is unclear, reply in $tgt. Keep technical terms and acronyms in their original form. " +
            "Be concise and clear: short paragraphs or simple bullet lists; use Markdown tables only when a table really helps." + hint(s)
        val ctx = if (pageText.isBlank()) "(This page has no readable body text; it may contain only figures.)" else pageText
        val prompt = "PAGE ${page + 1} TEXT:\n$ctx\n\n" +
            (if (history.isBlank()) "" else "CONVERSATION SO FAR:\n$history\n\n") +
            "USER QUESTION: $question"
        return AiRequest(prompt = prompt, system = system)
    }
}

/** Target languages that are written right-to-left. */
val RTL_LANGS = setOf("fa", "ar")
