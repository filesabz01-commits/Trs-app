package app.pdfreader.ai

enum class ReadingProfile(val label: String, val hint: String) {
    GENERAL("عمومی", ""),
    TECHNICAL(
        "فنی / مهندسی",
        "Technical text: preserve engineering terms, acronyms, formulas and units. Keep English term in parentheses on first use.",
    ),
    ACADEMIC(
        "آکادمیک",
        "Academic text: keep precise scholarly register, retain citations and references intact.",
    ),
    MEDICAL(
        "پزشکی",
        "Medical text: use accurate terminology; preserve drug names, dosages and units exactly.",
    ),
    LITERATURE(
        "ادبیات",
        "Literary text: favor natural, elegant phrasing and preserve tone.",
    ),
    CUSTOM("سفارشی", ""),
}

data class ReadingSettings(
    val sourceLanguage: String = "auto",
    val targetLanguage: String = "fa",
    val profile: ReadingProfile = ReadingProfile.TECHNICAL,
    val customInstruction: String = "",
    val preferredModel: String = "",
    val persistOcr: Boolean = true,
    val ttsEngine: String = "system", // default: system (free offline), or "gemini"
    val bilingual: Boolean = false,
    val voice: String = "Kore",
    val readText: Boolean = false,
    val highlightPdf: Boolean = true,
    val hideFallbackText: Boolean = false,
    val nightMode: Boolean = false,
)

object Prompts {
    const val NO_TEXT = "[[NO_TEXT]]"

    private fun hint(s: ReadingSettings) =
        if (s.profile == ReadingProfile.GENERAL && s.customInstruction.isBlank()) ""
        else {
            val h = if (s.profile == ReadingProfile.CUSTOM) s.customInstruction else s.profile.hint
            if (h.isBlank()) "" else "\nNote: $h"
        }

    private fun srcName(s: ReadingSettings) =
        if (s.sourceLanguage == "auto") "auto-detect source language"
        else Languages.byCode(s.sourceLanguage).english

    private fun tgtName(s: ReadingSettings) = Languages.byCode(s.targetLanguage).english

    /** Step 1 (vision): body text of the page only, cleaned, in the original language. */
    fun buildExtract(s: ReadingSettings, jpeg: ByteArray): AiRequest {
        val prompt = """
            Extract running body text from this document page image in its original language (${srcName(s)}).
            Keep: main narrative paragraphs, definitions, numbered lists, boxed notes, equations, and tables as GitHub-flavored Markdown tables (with | header | and | --- | rows).
            Remove: headers/footers, book title banners, page numbers (Arabic or Roman such as xxiv, xiv), 
            standalone section titles like "Preface", "Contents", "Introduction" when they appear with a page number, 
            repeated text, footnotes, figure captions, background image labels, diagram pillar labels, 
            chart axis titles, flowchart box labels, publisher download/license notices (e.g. Wiley, InDesign .indd timestamps).
            Format: join broken lines, blank line between paragraphs.
            If the page has no substantial running body text (diagrams/photos only), output exactly: $NO_TEXT
            Output ONLY the extracted text.
        """.trimIndent()
        return AiRequest(prompt = prompt, imageJpeg = jpeg, task = AiTask.EXTRACT)
    }

    /** One structural clean-up pass over clean text layer (no OCR). */
    fun buildClean(s: ReadingSettings, text: String): AiRequest {
        val prompt = """
            Clean structure of this page text layer: join hyphenated words/lines broken by layout, separate paragraphs with blank lines, keep tables as GitHub-flavored Markdown tables.
            Remove: headers/footers, page numbers (Arabic or Roman), standalone titles like Preface/Contents that appear with a page number, 
            footnotes, captions, publisher download/copyright notices, .indd timestamps, isolated diagram pillar/flowchart labels.
            Keep original language (${srcName(s)}). Never rephrase or summarize.
            If only figure labels remain, output: $NO_TEXT
            Output ONLY cleaned text.

            TEXT:
            $text
        """.trimIndent()
        return AiRequest(prompt = prompt, task = AiTask.EXTRACT)
    }

    /** Step 2 (text only): translate / explain / summarize the already extracted text. */
    fun buildText(task: AiTask, s: ReadingSettings, text: String): AiRequest {
        val tgt = tgtName(s)
        val body = when (task) {
            AiTask.TRANSLATE ->
                "Translate the following document page text from ${srcName(s)} into $tgt.\n" +
                    "RULES:\n" +
                    "1. Keep the original paragraph structure: put one blank line between paragraphs. Never merge the whole page into a single block.\n" +
                    "2. ALWAYS keep and translate numbered section headings (e.g. '3.2 Ownership Block', '2.7 Tracking Changes in P&IDs').\n" +
                    "3. TABLES: If the input has a table (comparison rows, columns like Trait/PFD/P&ID, or Markdown table), " +
                    "output it as a proper GitHub-flavored Markdown table with a header row and | --- | separator row. " +
                    "Translate every cell. Do NOT flatten tables into running prose.\n" +
                    "4. STRICTLY OMIT and never translate: page numbers, running headers/footers, standalone 'Preface/Contents', " +
                    "diagram oval/bubble labels (e.g. 'P&ID development guidelines', 'P&ID demonstration rules', 'P&ID drafting rules'), " +
                    "flowchart box labels, short question captions under symbols (e.g. 'Where should I put this valve?', 'What is its symbol?'), " +
                    "figure captions, figure stamp/legal boxes (Permit to practice, This document was prepared exclusively, Signature/Date lines), " +
                    "pure color-only cells, publisher/copyright lines (All rights reserved, Wiley, Companion Website, © year).\n" +
                    "5. Keep numbers, units, formulas, acronyms, equipment tags intact. On first use of a technical term you may add the English in parentheses.\n" +
                    "6. Translate ONLY continuous narrative paragraphs and real section headings. Do not invent content that is not in the input.\n" +
                    "Output ONLY the translation."
            AiTask.EXPLAIN ->
                "Explain the text below in $tgt clearly: define key terms first, then explain main concepts step-by-step. Output only explanation."
            AiTask.SUMMARIZE ->
                "Summarize the text below in $tgt as 4-8 clear, concise bullet points. Output only summary."
            AiTask.EXTRACT -> ""
        }
        return AiRequest(prompt = "$body${hint(s)}\n\nTEXT:\n$text", task = task)
    }

    /** Translation in numbered segments for aligned audio reading & highlighting. */
    fun buildSegments(s: ReadingSettings, segments: List<String>): AiRequest {
        val tgt = tgtName(s)
        val body = StringBuilder()
        segments.forEachIndexed { i, t -> body.append("[[").append(i + 1).append("]]\n").append(t).append("\n\n") }
        val prompt = "Translate each numbered segment below into $tgt. " +
            "Output EXACTLY ${segments.size} blocks in the same order. Each block MUST start with a line containing only [[N]] where N is the segment number. " +
            "Never merge, split, or skip segments. " +
            "STRICTLY omit any page numbers, Roman numerals, 'Preface', running headers, diagram labels, " +
            "table captions/cells (Table 2.1, Intention, Color used, Addition, Deletion, Dark gray, ...), " +
            "and copyright/publisher lines (All rights reserved, John Wiley, Companion Website, ...) that may appear inside a segment. " +
            "Keep real section headings like '2.7 Tracking Changes...'. Preserve numbers, units, formulas, acronyms. " +
            "Output ONLY the numbered blocks, nothing else before or after.${hint(s)}\n\nSEGMENTS:\n$body"
        return AiRequest(prompt = prompt, task = AiTask.TRANSLATE)
    }

    enum class RangeMode { FULL, PART, MERGE }

    /** Review summary for a range of pages. */
    fun buildRangeSummary(s: ReadingSettings, from: Int, to: Int, text: String, mode: RangeMode): AiRequest {
        val tgt = tgtName(s)
        val intro = when (mode) {
            RangeMode.FULL -> "Pages ${from + 1} to ${to + 1} review summary in $tgt: key headings, bullet points, essential definitions (keep English in parentheses), and a 3-line recap."
            RangeMode.PART -> "Part of pages ${from + 1} to ${to + 1} review summary in $tgt: dense summary of facts and key terms."
            RangeMode.MERGE -> "Merge partial summaries of pages ${from + 1} to ${to + 1} into a single review summary in $tgt with headings and bullet points."
        }
        return AiRequest(prompt = "$intro${hint(s)}\n\nTEXT:\n$text", task = AiTask.SUMMARIZE)
    }

    /** Chat about the page the reader is on. */
    fun buildChat(s: ReadingSettings, page: Int, pageText: String, history: String, question: String): AiRequest {
        val tgt = tgtName(s)
        val system = "You are a concise study assistant in a PDF reader. Answer questions about the provided page text first, then general knowledge if needed. Reply in language of question or $tgt. Keep answers clear and succinct." + hint(s)
        val ctx = if (pageText.isBlank()) "(Page has no body text)" else pageText
        val prompt = "PAGE ${page + 1} TEXT:\n$ctx\n\n" +
            (if (history.isBlank()) "" else "HISTORY:\n$history\n\n") +
            "QUESTION: $question"
        return AiRequest(prompt = prompt, system = system, task = AiTask.EXPLAIN, maxOutputTokens = 1024)
    }
}

val RTL_LANGS = setOf("fa", "ar")
