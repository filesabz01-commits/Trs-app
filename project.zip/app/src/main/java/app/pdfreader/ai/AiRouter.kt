package app.pdfreader.ai

import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.LocalDate
import java.util.concurrent.ConcurrentHashMap

/**
 * Robust AI Router:
 * - 20s TTFB limit & 60s total budget to prevent hanging
 * - Task-specific model ladders (Lite models for translate/extract; Flash for explain/summarize)
 * - Automatic attempt logging to Room (timing, tokens, outcome)
 * - Skip to next model & cancel HTTP connections immediately
 * - Strict cooldowns on 400 and 404 with max 1 retry on transient timeouts
 */
class AiRouter(
    private val dao: AiDao,
    private val impls: Map<String, AiProvider>,
) {
    sealed interface Outcome {
        class Ok(
            val text: String,
            val provider: String,
            val model: String,
            val audio: ByteArray? = null,
            val promptTokens: Int = 0,
            val candidatesTokens: Int = 0,
            val thoughtsTokens: Int = 0,
        ) : Outcome
        class Failed(val reason: Reason, val detail: String, val retryAtMs: Long? = null) : Outcome
    }

    enum class Reason { NOT_CONFIGURED, ALL_COOLING_DOWN, NETWORK, ALL_FAILED, TIMEOUT, CANCELLED }

    private companion object {
        // Successful page translations often take 16–24s; 20s TTFB caused many false TIMEOUTS.
        const val CALL_MS = 45_000L
        const val TTS_CALL_MS = 45_000L
        const val TOTAL_BUDGET_MS = 90_000L // allow a couple of model fallbacks
    }

    private val stateLock = Mutex()
    private val pairCooldown = ConcurrentHashMap<String, Long>()

    private val coolingKinds = setOf(
        FailKind.DAILY_QUOTA, FailKind.RATE_LIMIT, FailKind.SERVER,
        FailKind.TIMEOUT, FailKind.BAD_REQUEST, FailKind.MODEL_UNAVAILABLE,
    )

    @Volatile private var skipCurrentModelRequested = false

    fun requestSkipCurrentModel() {
        skipCurrentModelRequested = true
    }

    suspend fun run(
        cap: Capability,
        req: AiRequest,
        preferredModel: String = "",
        onModelActive: ((String) -> Unit)? = null,
        onPartial: ((String) -> Unit)? = null,
    ): Outcome = runWith(cap, req, preferredModel, onModelActive) { impl, baseUrl, model, secret ->
        impl.generate(baseUrl, model, secret, req, onPartial)
    }

    suspend fun synthesize(
        text: String,
        voice: String,
        preferredModel: String = "",
        onModelActive: ((String) -> Unit)? = null,
    ): Outcome = runWith(Capability.TTS, AiRequest(text, task = AiTask.EXTRACT), preferredModel, onModelActive) { impl, baseUrl, model, secret ->
        impl.synthesize(baseUrl, model, secret, text, voice)
    }

    private suspend fun runWith(
        cap: Capability,
        req: AiRequest,
        preferredModel: String,
        onModelActive: ((String) -> Unit)?,
        call: suspend (AiProvider, String, String, String) -> AiResult,
    ): Outcome {
        skipCurrentModelRequested = false
        val providers = dao.providers().filter { it.enabled }
        var configured = false
        var soonest = Long.MAX_VALUE
        val errors = mutableListOf<String>()

        val deadline = System.currentTimeMillis() + TOTAL_BUDGET_MS
        val perCallMs = if (cap == Capability.TTS) TTS_CALL_MS else CALL_MS
        fun expired() = System.currentTimeMillis() > deadline

        for (p in providers) {
            val impl = impls[p.type] ?: continue
            val models = orderedModels(p.id, cap, req.task, preferredModel)
            if (models.isEmpty()) continue

            for (k in dao.keysFor(p.id)) {
                if (expired()) return Outcome.Failed(Reason.TIMEOUT, "زمان کلی درخواست (۶۰ ثانیه) تمام شد.")
                if (k.status == KeyStatus.INVALID.name || k.status == KeyStatus.DISABLED.name) continue
                configured = true
                if (k.cooldownUntil > System.currentTimeMillis()) {
                    soonest = minOf(soonest, k.cooldownUntil)
                    continue
                }
                var keyDead = false
                var keySoonest = Long.MAX_VALUE
                val kinds = mutableSetOf<FailKind>()

                for (m in models) {
                    if (keyDead) break
                    val pair = "${k.id}|${m.modelName}"
                    val cd = pairCooldown[pair] ?: 0L
                    if (cd > System.currentTimeMillis()) {
                        keySoonest = minOf(keySoonest, cd)
                        continue
                    }

                    onModelActive?.invoke(m.modelName)
                    var tries = 0
                    var rateRetried = false

                    while (true) {
                        if (expired()) return Outcome.Failed(Reason.TIMEOUT, "زمان کلی درخواست (۶۰ ثانیه) تمام شد.")
                        if (skipCurrentModelRequested) {
                            skipCurrentModelRequested = false
                            break // skip to next model immediately
                        }

                        val secret = try {
                            SecretBox.decrypt(k.secret)
                        } catch (e: Exception) {
                            touch(k.id, false, FailKind.INVALID_KEY, "cannot decrypt")
                            keyDead = true
                            break
                        }

                        val attemptStart = System.currentTimeMillis()
                        val res: AiResult = withTimeoutOrNull(perCallMs) {
                            call(impl, p.baseUrl, m.modelName, secret)
                        } ?: AiResult.Fail(FailKind.TIMEOUT, "عدم پاسخ در زمان مقرر")

                        val totalMs = System.currentTimeMillis() - attemptStart
                        val outcomeStr = if (res is AiResult.Ok) "OK" else (res as AiResult.Fail).kind.name
                        val promptTok = if (res is AiResult.Ok) res.promptTokens else 0
                        val candTok = if (res is AiResult.Ok) res.candidatesTokens else 0
                        val thoughtTok = if (res is AiResult.Ok) res.thoughtsTokens else 0
                        val errMsg = if (res is AiResult.Fail) res.detail else null

                        try {
                            dao.insertAttempt(
                                AiAttemptEntity(
                                    timestamp = attemptStart,
                                    task = req.task.name,
                                    model = m.modelName,
                                    keyLabel = k.label.ifBlank { "کلید ${k.id.take(4)}" },
                                    timeToFirstByteMs = totalMs,
                                    totalTimeMs = totalMs,
                                    outcome = outcomeStr,
                                    promptTokens = promptTok,
                                    candidatesTokens = candTok,
                                    thoughtsTokens = thoughtTok,
                                    errorMessage = errMsg,
                                )
                            )
                        } catch (ignored: Exception) {}

                        if (res is AiResult.Ok) {
                            touch(k.id, true, null, null)
                            return Outcome.Ok(
                                res.text, p.name, m.modelName, res.audio,
                                res.promptTokens, res.candidatesTokens, res.thoughtsTokens,
                            )
                        }

                        val fail = res as AiResult.Fail

                        // 400 and 404: cooldown immediately, no retry
                        if (fail.kind == FailKind.BAD_REQUEST || fail.kind == FailKind.MODEL_UNAVAILABLE) {
                            touch(k.id, false, fail.kind, fail.detail)
                            errors += "${m.modelName}: ${fail.kind} ${fail.detail.take(90)}"
                            kinds += fail.kind
                            val cdUntil = System.currentTimeMillis() + 15 * 60_000L
                            pairCooldown[pair] = cdUntil
                            keySoonest = minOf(keySoonest, cdUntil)
                            break
                        }

                        // Rate limit: 1 retry if retryAfter is short (<= 10s)
                        if (fail.kind == FailKind.RATE_LIMIT && !rateRetried && (fail.retryAfterMs ?: 6_000L) <= 10_000L) {
                            rateRetried = true
                            delay((fail.retryAfterMs ?: 5_000L).coerceAtLeast(4_000L))
                            continue
                        }

                        // Transient (TIMEOUT/SERVER/NETWORK): max 1 retry
                        val transient = fail.kind == FailKind.SERVER || fail.kind == FailKind.TIMEOUT
                        if (transient && tries < 1) {
                            delay(1_500L)
                            tries++
                            continue
                        }

                        touch(k.id, false, fail.kind, fail.detail)
                        errors += "${m.modelName}: ${fail.kind} ${fail.detail.take(90)}"
                        kinds += fail.kind
                        val now = System.currentTimeMillis()
                        val until = now + when (fail.kind) {
                            FailKind.DAILY_QUOTA -> 6 * 3_600_000L
                            FailKind.MODEL_UNAVAILABLE -> 24 * 3_600_000L
                            FailKind.BAD_REQUEST -> 15 * 60_000L
                            FailKind.RATE_LIMIT -> (fail.retryAfterMs ?: 60_000L).coerceIn(5_000L, 3_600_000L)
                            FailKind.SERVER, FailKind.TIMEOUT, FailKind.NETWORK -> 90_000L
                            FailKind.BLOCKED, FailKind.EMPTY, FailKind.INVALID_KEY -> 0L
                        }
                        if (until > now) {
                            pairCooldown[pair] = until
                            keySoonest = minOf(keySoonest, until)
                        }
                        if (fail.kind == FailKind.INVALID_KEY) keyDead = true
                        if (fail.kind == FailKind.NETWORK) return Outcome.Failed(Reason.NETWORK, errors.last())
                        break
                    }
                }
                if (!keyDead && keySoonest != Long.MAX_VALUE && kinds.any { it in coolingKinds }) {
                    val status = when {
                        FailKind.DAILY_QUOTA in kinds -> KeyStatus.DAILY_QUOTA_EXCEEDED
                        FailKind.RATE_LIMIT in kinds -> KeyStatus.RATE_LIMITED
                        else -> KeyStatus.TEMPORARILY_UNAVAILABLE
                    }
                    setKeyCooldown(k.id, status, keySoonest)
                    soonest = minOf(soonest, keySoonest)
                }
            }
        }
        return when {
            !configured && soonest == Long.MAX_VALUE -> Outcome.Failed(Reason.NOT_CONFIGURED, "")
            errors.isEmpty() && soonest != Long.MAX_VALUE -> Outcome.Failed(Reason.ALL_COOLING_DOWN, "", soonest)
            else -> Outcome.Failed(Reason.ALL_FAILED, errors.joinToString("\n"), soonest.takeIf { it != Long.MAX_VALUE })
        }
    }

    private suspend fun orderedModels(providerId: String, cap: Capability, task: AiTask, preferred: String): List<ModelEntity> {
        val list = dao.models()
            .filter { it.providerId == providerId && it.enabled && it.supports(cap) }
            .sortedBy { it.position }
        if (list.isEmpty()) return emptyList()

        if (preferred.isNotBlank()) {
            val pref = list.firstOrNull { it.modelName == preferred }
            if (pref != null) return listOf(pref) + list.filter { it !== pref }
        }

        val ladder = when (task) {
            AiTask.TRANSLATE, AiTask.EXTRACT -> GeminiModels.LITE_FIRST
            AiTask.EXPLAIN, AiTask.SUMMARIZE -> GeminiModels.FLASH_FIRST
        }
        return list.sortedBy { m ->
            val idx = ladder.indexOf(m.modelName)
            if (idx >= 0) idx else 999
        }
    }

    suspend fun test(keyId: String): String {
        val k = dao.key(keyId) ?: return "کلید پیدا نشد"
        val p = dao.provider(k.providerId) ?: return "provider پیدا نشد"
        val impl = impls[p.type] ?: return "نوع provider پشتیبانی نمی‌شود"
        val models = dao.models().filter { it.providerId == p.id && it.enabled && it.supportsText }.sortedBy { it.position }
        if (models.isEmpty()) return "ابتدا یک مدل متنی اضافه کنید"
        val secret = try { SecretBox.decrypt(k.secret) } catch (e: Exception) { return "رمزگشایی کلید ممکن نشد؛ کلید را دوباره وارد کنید" }
        var last = ""
        for (m in models) {
            val res = impl.generate(p.baseUrl, m.modelName, secret, AiRequest("Reply with the single word: OK"))
            if (res is AiResult.Ok) {
                touch(k.id, true, null, null)
                return "اتصال موفق بود (${m.modelName})"
            }
            val f = res as AiResult.Fail
            if (f.kind == FailKind.INVALID_KEY) {
                touch(k.id, false, f.kind, f.detail)
                return "کلید نامعتبر است: ${f.detail.take(120)}"
            }
            last = "${m.modelName}: ${f.kind} ${f.detail.take(100)}"
        }
        return "هیچ مدلی جواب نداد. آخرین خطا: $last"
    }

    private suspend fun touch(id: String, success: Boolean, kind: FailKind?, detail: String?) =
        stateLock.withLock {
            val k = dao.key(id) ?: return@withLock
            val now = System.currentTimeMillis()
            val today = LocalDate.now().toString()
            val sameDay = k.usageDay == today
            val requests = (if (sameDay) k.requestsToday else 0) + 1
            val errors = (if (sameDay) k.errorsToday else 0) + if (success) 0 else 1
            var status = k.status
            var cooldown = k.cooldownUntil
            if (success) {
                status = KeyStatus.ACTIVE.name
                cooldown = 0
            } else if (kind == FailKind.INVALID_KEY) {
                status = KeyStatus.INVALID.name
                cooldown = 0
            }
            dao.upsertKey(
                k.copy(
                    status = status, cooldownUntil = cooldown, usageDay = today,
                    requestsToday = requests, errorsToday = errors, lastUsedAt = now,
                    lastError = if (success) null else "$kind: ${detail.orEmpty()}".take(200),
                )
            )
        }

    private suspend fun setKeyCooldown(id: String, status: KeyStatus, until: Long) = stateLock.withLock {
        val k = dao.key(id) ?: return@withLock
        if (k.status == KeyStatus.INVALID.name || k.status == KeyStatus.DISABLED.name) return@withLock
        dao.upsertKey(k.copy(status = status.name, cooldownUntil = until))
    }
}
