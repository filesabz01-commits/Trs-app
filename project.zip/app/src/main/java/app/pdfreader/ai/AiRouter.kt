package app.pdfreader.ai

import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.LocalDate
import java.util.concurrent.ConcurrentHashMap

/**
 * Same logic as the original tool, plus several keys:
 *   for each key (in list order)  ->  models in fixed order (preferred model first)
 * A model that fails is put on cooldown for THAT key only and the next model is tried.
 * When every model failed for a key (quota etc.), the next key restarts from the first model.
 */
class AiRouter(
    private val dao: AiDao,
    private val impls: Map<String, AiProvider>,
) {
    sealed interface Outcome {
        class Ok(val text: String, val provider: String, val model: String, val audio: ByteArray? = null) : Outcome
        class Failed(val reason: Reason, val detail: String, val retryAtMs: Long? = null) : Outcome
    }

    enum class Reason { NOT_CONFIGURED, ALL_COOLING_DOWN, NETWORK, ALL_FAILED }

    private val stateLock = Mutex()
    private val pairCooldown = ConcurrentHashMap<String, Long>() // "keyId|model" -> until (in memory)

    private val coolingKinds = setOf(FailKind.DAILY_QUOTA, FailKind.RATE_LIMIT, FailKind.SERVER, FailKind.TIMEOUT)

    suspend fun run(
        cap: Capability,
        req: AiRequest,
        preferredModel: String = "",
        onPartial: ((String) -> Unit)? = null,
    ): Outcome = runWith(cap, preferredModel) { impl, baseUrl, model, secret ->
        impl.generate(baseUrl, model, secret, req, onPartial)
    }

    /** Text-to-speech through the same key/model fallback (TTS models in the HTML order). */
    suspend fun synthesize(text: String, voice: String, preferredModel: String = ""): Outcome =
        runWith(Capability.TTS, preferredModel) { impl, baseUrl, model, secret ->
            impl.synthesize(baseUrl, model, secret, text, voice)
        }

    private suspend fun runWith(
        cap: Capability,
        preferredModel: String,
        call: suspend (AiProvider, String, String, String) -> AiResult,
    ): Outcome {
        val providers = dao.providers().filter { it.enabled }
        var configured = false
        var soonest = Long.MAX_VALUE
        val errors = mutableListOf<String>()

        for (p in providers) {
            val impl = impls[p.type] ?: continue
            val models = orderedModels(p.id, cap, preferredModel)
            if (models.isEmpty()) continue
            for (k in dao.keysFor(p.id)) {
                if (k.status == KeyStatus.INVALID.name || k.status == KeyStatus.DISABLED.name) continue
                configured = true
                if (k.cooldownUntil > System.currentTimeMillis()) {
                    soonest = minOf(soonest, k.cooldownUntil)
                    continue
                }
                var keyDead = false
                var keySoonest = Long.MAX_VALUE
                val kinds = mutableSetOf<FailKind>()

                for (m in models) {
                    if (keyDead) break
                    val pair = "${k.id}|${m.modelName}"
                    val cd = pairCooldown[pair] ?: 0L
                    if (cd > System.currentTimeMillis()) {
                        keySoonest = minOf(keySoonest, cd)
                        continue
                    }
                    var tries = 0
                    var rateRetried = false
                    while (true) {
                        val secret = try {
                            SecretBox.decrypt(k.secret)
                        } catch (e: Exception) {
                            touch(k.id, false, FailKind.INVALID_KEY, "cannot decrypt")
                            keyDead = true
                            break
                        }
                        val res = call(impl, p.baseUrl, m.modelName, secret)
                        if (res is AiResult.Ok) {
                            touch(k.id, true, null, null)
                            return Outcome.Ok(res.text, p.name, m.modelName, res.audio)
                        }
                        val fail = res as AiResult.Fail
                        // like the HTML: one short wait + retry on a busy (429) model
                        if (fail.kind == FailKind.RATE_LIMIT && !rateRetried && (fail.retryAfterMs ?: 6_000L) <= 20_000L) {
                            rateRetried = true
                            delay((fail.retryAfterMs ?: 6_000L).coerceAtLeast(6_000L))
                            continue
                        }
                        val transient = fail.kind == FailKind.SERVER || fail.kind == FailKind.TIMEOUT || fail.kind == FailKind.NETWORK
                        if (transient && tries < 2) {
                            delay(1_000L shl tries)
                            tries++
                            continue
                        }
                        touch(k.id, false, fail.kind, fail.detail)
                        errors += "${m.modelName}: ${fail.kind} ${fail.detail.take(90)}"
                        kinds += fail.kind
                        val now = System.currentTimeMillis()
                        val until = now + when (fail.kind) {
                            FailKind.DAILY_QUOTA -> 6 * 3_600_000L
                            FailKind.MODEL_UNAVAILABLE -> 24 * 3_600_000L
                            FailKind.BAD_REQUEST -> 10 * 60_000L
                            FailKind.RATE_LIMIT -> (fail.retryAfterMs ?: 60_000L).coerceIn(5_000L, 3_600_000L)
                            FailKind.SERVER, FailKind.TIMEOUT, FailKind.NETWORK -> 2 * 60_000L
                            FailKind.BLOCKED, FailKind.EMPTY, FailKind.INVALID_KEY -> 0L
                        }
                        if (until > now) {
                            pairCooldown[pair] = until
                            keySoonest = minOf(keySoonest, until)
                        }
                        if (fail.kind == FailKind.INVALID_KEY) keyDead = true
                        if (fail.kind == FailKind.NETWORK) return Outcome.Failed(Reason.NETWORK, errors.last())
                        break
                    }
                }
                if (!keyDead && keySoonest != Long.MAX_VALUE && kinds.any { it in coolingKinds }) {
                    val status = when {
                        FailKind.DAILY_QUOTA in kinds -> KeyStatus.DAILY_QUOTA_EXCEEDED
                        FailKind.RATE_LIMIT in kinds -> KeyStatus.RATE_LIMITED
                        else -> KeyStatus.TEMPORARILY_UNAVAILABLE
                    }
                    setKeyCooldown(k.id, status, keySoonest)
                    soonest = minOf(soonest, keySoonest)
                }
            }
        }
        return when {
            !configured && soonest == Long.MAX_VALUE -> Outcome.Failed(Reason.NOT_CONFIGURED, "")
            errors.isEmpty() && soonest != Long.MAX_VALUE -> Outcome.Failed(Reason.ALL_COOLING_DOWN, "", soonest)
            else -> Outcome.Failed(Reason.ALL_FAILED, errors.joinToString("\n"), soonest.takeIf { it != Long.MAX_VALUE })
        }
    }

    private suspend fun orderedModels(providerId: String, cap: Capability, preferred: String): List<ModelEntity> {
        val list = dao.models()
            .filter { it.providerId == providerId && it.enabled && it.supports(cap) }
            .sortedBy { it.position }
        val pref = list.firstOrNull { it.modelName == preferred } ?: return list
        return listOf(pref) + list.filter { it !== pref }
    }

    /** Connection test for one key using the first enabled text model of its provider. */
    suspend fun test(keyId: String): String {
        val k = dao.key(keyId) ?: return "کلید پیدا نشد"
        val p = dao.provider(k.providerId) ?: return "provider پیدا نشد"
        val impl = impls[p.type] ?: return "نوع provider پشتیبانی نمی‌شود"
        val models = dao.models().filter { it.providerId == p.id && it.enabled && it.supportsText }.sortedBy { it.position }
        if (models.isEmpty()) return "ابتدا یک مدل متنی اضافه کنید"
        val secret = try { SecretBox.decrypt(k.secret) } catch (e: Exception) { return "رمزگشایی کلید ممکن نشد؛ کلید را دوباره وارد کنید" }
        // Try models in order until one answers, so a retired model does not make a good key look broken.
        var last = ""
        for (m in models) {
            val res = impl.generate(p.baseUrl, m.modelName, secret, AiRequest("Reply with the single word: OK"))
            if (res is AiResult.Ok) {
                touch(k.id, true, null, null)
                return "اتصال موفق بود (${m.modelName})"
            }
            val f = res as AiResult.Fail
            if (f.kind == FailKind.INVALID_KEY) {
                touch(k.id, false, f.kind, f.detail)
                return "کلید نامعتبر است: ${f.detail.take(120)}"
            }
            last = "${m.modelName}: ${f.kind} ${f.detail.take(100)}"
        }
        return "هیچ مدلی جواب نداد. آخرین خطا: $last"
    }

    private suspend fun touch(id: String, success: Boolean, kind: FailKind?, detail: String?) =
        stateLock.withLock {
            val k = dao.key(id) ?: return@withLock
            val now = System.currentTimeMillis()
            val today = LocalDate.now().toString()
            val sameDay = k.usageDay == today
            val requests = (if (sameDay) k.requestsToday else 0) + 1
            val errors = (if (sameDay) k.errorsToday else 0) + if (success) 0 else 1
            var status = k.status
            var cooldown = k.cooldownUntil
            if (success) {
                status = KeyStatus.ACTIVE.name
                cooldown = 0
            } else if (kind == FailKind.INVALID_KEY) {
                status = KeyStatus.INVALID.name
                cooldown = 0
            }
            dao.upsertKey(
                k.copy(
                    status = status, cooldownUntil = cooldown, usageDay = today,
                    requestsToday = requests, errorsToday = errors, lastUsedAt = now,
                    lastError = if (success) null else "$kind: ${detail.orEmpty()}".take(200),
                )
            )
        }

    private suspend fun setKeyCooldown(id: String, status: KeyStatus, until: Long) = stateLock.withLock {
        val k = dao.key(id) ?: return@withLock
        if (k.status == KeyStatus.INVALID.name || k.status == KeyStatus.DISABLED.name) return@withLock
        dao.upsertKey(k.copy(status = status.name, cooldownUntil = until))
    }
}
