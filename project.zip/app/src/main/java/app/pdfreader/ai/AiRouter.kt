package app.pdfreader.ai

import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.LocalDate

/**
 * Smart router: Provider -> Model -> Key pool. Fully generic (no provider is hard-coded).
 * Key state changes only from real provider answers (429, daily-quota text, 401/403, 5xx...).
 */
class AiRouter(
    private val dao: AiDao,
    private val impls: Map<String, AiProvider>,
) {
    sealed interface Outcome {
        class Ok(val text: String, val provider: String, val model: String) : Outcome
        class Failed(val reason: Reason, val detail: String, val retryAtMs: Long? = null) : Outcome
    }

    enum class Reason { NOT_CONFIGURED, ALL_COOLING_DOWN, NETWORK, ALL_FAILED }

    private val stateLock = Mutex()

    suspend fun run(cap: Capability, req: AiRequest): Outcome {
        val providers = dao.providers().filter { it.enabled }
        val models = dao.models().filter { it.enabled }
        var configured = false
        var soonest = Long.MAX_VALUE
        var sawNetwork = false
        val errors = mutableListOf<String>()

        for (p in providers) {
            val impl = impls[p.type] ?: continue
            val pm = models.filter { it.providerId == p.id && it.supports(cap) }.sortedBy { it.position }
            for (m in pm) {
                // least-recently-used key first, so several keys share the load
                val keys = dao.keysFor(p.id).sortedBy { it.lastUsedAt }
                var skipModel = false
                for (k in keys) {
                    if (skipModel) break
                    if (k.status == KeyStatus.INVALID.name || k.status == KeyStatus.DISABLED.name) continue
                    configured = true
                    if (k.cooldownUntil > System.currentTimeMillis()) {
                        soonest = minOf(soonest, k.cooldownUntil)
                        continue
                    }
                    var tries = 0
                    while (true) {
                        val secret = try {
                            SecretBox.decrypt(k.secret)
                        } catch (e: Exception) {
                            touch(k.id, false, FailKind.INVALID_KEY, "cannot decrypt", null)
                            break
                        }
                        val res = impl.generate(p.baseUrl, m.modelName, secret, req)
                        if (res is AiResult.Ok) {
                            touch(k.id, true, null, null, null)
                            return Outcome.Ok(res.text, p.name, m.modelName)
                        }
                        val fail = res as AiResult.Fail
                        val transient = fail.kind == FailKind.NETWORK || fail.kind == FailKind.TIMEOUT || fail.kind == FailKind.SERVER
                        if (transient && tries < 2) {
                            delay(1_000L shl tries) // exponential backoff: 1s, 2s
                            tries++
                            continue
                        }
                        touch(k.id, false, fail.kind, fail.detail, fail.retryAfterMs)
                        if (fail.kind == FailKind.NETWORK) sawNetwork = true
                        errors += "${p.name}/${m.modelName}: ${fail.kind} ${fail.detail.take(100)}"
                        if (fail.kind == FailKind.BAD_REQUEST || fail.kind == FailKind.BLOCKED || fail.kind == FailKind.EMPTY) {
                            skipModel = true // key is fine; this model/request is the problem -> next model
                        }
                        break
                    }
                }
            }
        }
        return when {
            !configured && soonest == Long.MAX_VALUE -> Outcome.Failed(Reason.NOT_CONFIGURED, "")
            errors.isEmpty() && soonest != Long.MAX_VALUE -> Outcome.Failed(Reason.ALL_COOLING_DOWN, "", soonest)
            sawNetwork && errors.all { it.contains("NETWORK") } -> Outcome.Failed(Reason.NETWORK, errors.last())
            else -> Outcome.Failed(Reason.ALL_FAILED, errors.joinToString("\n"), soonest.takeIf { it != Long.MAX_VALUE })
        }
    }

    /** Connection test for one key using the first enabled text model of its provider. */
    suspend fun test(keyId: String): String {
        val k = dao.key(keyId) ?: return "کلید پیدا نشد"
        val p = dao.provider(k.providerId) ?: return "provider پیدا نشد"
        val impl = impls[p.type] ?: return "نوع provider پشتیبانی نمی‌شود"
        val m = dao.models().firstOrNull { it.providerId == p.id && it.enabled && it.supportsText }
            ?: return "ابتدا یک مدل متنی برای این provider اضافه کنید"
        val secret = try { SecretBox.decrypt(k.secret) } catch (e: Exception) { return "رمزگشایی کلید ممکن نشد؛ کلید را دوباره وارد کنید" }
        val res = impl.generate(p.baseUrl, m.modelName, secret, AiRequest("Reply with the single word: OK"))
        return if (res is AiResult.Ok) {
            touch(k.id, true, null, null, null)
            "اتصال موفق بود (${m.modelName})"
        } else {
            val f = res as AiResult.Fail
            touch(k.id, false, f.kind, f.detail, f.retryAfterMs)
            "ناموفق: ${f.kind} — ${f.detail.take(160)}"
        }
    }

    private suspend fun touch(id: String, success: Boolean, kind: FailKind?, detail: String?, retryAfterMs: Long?) =
        stateLock.withLock {
            val k = dao.key(id) ?: return@withLock
            val now = System.currentTimeMillis()
            val today = LocalDate.now().toString()
            val sameDay = k.usageDay == today
            val requests = (if (sameDay) k.requestsToday else 0) + 1
            var errors = if (sameDay) k.errorsToday else 0
            var status = k.status
            var cooldown = k.cooldownUntil
            if (success) {
                status = KeyStatus.ACTIVE.name
                cooldown = 0
            } else {
                errors++
                when (kind) {
                    FailKind.RATE_LIMIT -> {
                        status = KeyStatus.RATE_LIMITED.name
                        cooldown = now + (retryAfterMs ?: 60_000L).coerceIn(5_000L, 3_600_000L)
                    }
                    FailKind.DAILY_QUOTA -> {
                        status = KeyStatus.DAILY_QUOTA_EXCEEDED.name
                        cooldown = now + 6 * 3_600_000L // cooldown only; provider did not report an exact reset time
                    }
                    FailKind.INVALID_KEY -> {
                        status = KeyStatus.INVALID.name
                        cooldown = 0
                    }
                    FailKind.SERVER, FailKind.TIMEOUT -> {
                        status = KeyStatus.TEMPORARILY_UNAVAILABLE.name
                        cooldown = now + 120_000L
                    }
                    else -> Unit
                }
            }
            dao.upsertKey(
                k.copy(
                    status = status, cooldownUntil = cooldown, usageDay = today,
                    requestsToday = requests, errorsToday = errors, lastUsedAt = now,
                    lastError = if (success) null else "$kind: ${detail.orEmpty()}".take(200),
                )
            )
        }
}
