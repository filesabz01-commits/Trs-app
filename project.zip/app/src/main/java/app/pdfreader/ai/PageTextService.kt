package app.pdfreader.ai

import android.graphics.Bitmap
import android.util.LruCache
import app.pdfreader.core.pdf.PdfDocument
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

sealed interface PT {
    class Ok(val text: String, val model: String = "", val fromCache: Boolean = false, val source: String? = null) : PT
    data object NoText : PT
    class Fail(val message: String) : PT
}

/**
 * The one text pipeline used by both "Translate/Explain/Summarize" and "Read Aloud":
 * page image -> clean body text (session memory only, unless the user opts in) -> translation (permanent cache).
 */
class PageTextService(
    private val dao: AiDao,
    private val router: AiRouter,
) {
    private val session = LruCache<String, String>(300)

    fun clearSession() = session.evictAll()

    private fun extractKey(docUri: String, page: Int, s: ReadingSettings) = sha256("v2|$docUri|$page|${s.sourceLanguage}")

    private fun finalKey(task: AiTask, docUri: String, page: Int, s: ReadingSettings) = sha256(
        "v2|$docUri|$page|${task.name}|${s.sourceLanguage}|${s.targetLanguage}|${s.profile.name}|" +
            (if (s.profile == ReadingProfile.CUSTOM) s.customInstruction else "")
    )

    suspend fun cached(task: AiTask, docUri: String, page: Int, s: ReadingSettings): PT.Ok? =
        finalKey(task, docUri, page, s).let { k -> dao.cached(k)?.let { PT.Ok(it.text, it.model, true, dao.cached("$k|src")?.text) } }

    suspend fun extract(
        doc: PdfDocument, docUri: String, page: Int, s: ReadingSettings,
        force: Boolean = false, onPhase: (String) -> Unit = {},
    ): PT {
        val key = extractKey(docUri, page, s)
        if (!force) {
            session.get(key)?.let { return if (it == Prompts.NO_TEXT) PT.NoText else PT.Ok(it) }
            if (s.persistOcr) {
                dao.cached("ocr|$key")?.let {
                    session.put(key, it.text)
                    return PT.Ok(it.text)
                }
            }
        }
        onPhase("در حال استخراج متن صفحه ${page + 1}…")
        val jpeg = try {
            withContext(Dispatchers.IO) {
                val bmp = doc.render(page, 1400)
                val out = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 82, out)
                bmp.recycle()
                out.toByteArray()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            return PT.Fail("رندر صفحه برای پردازش ممکن نشد.")
        }
        return when (val o = router.run(Capability.VISION, Prompts.buildExtract(s, jpeg), s.preferredModel)) {
            is AiRouter.Outcome.Ok -> {
                var text = o.text.trim()
                if (text.contains("NO_TEXT")) text = Prompts.NO_TEXT
                session.put(key, text)
                if (text == Prompts.NO_TEXT) PT.NoText
                else {
                    if (s.persistOcr) dao.upsertCache(CacheEntity("ocr|$key", text, o.model, System.currentTimeMillis()))
                    PT.Ok(text, o.model)
                }
            }
            is AiRouter.Outcome.Failed -> PT.Fail(describe(o))
        }
    }

    /** Translate / explain / summarize already-extracted text. Results are stored permanently. */
    suspend fun process(
        task: AiTask, docUri: String, page: Int, s: ReadingSettings, text: String,
        force: Boolean = false, onPartial: ((String) -> Unit)? = null,
    ): PT {
        val key = finalKey(task, docUri, page, s)
        if (!force) dao.cached(key)?.let { return PT.Ok(it.text, it.model, true, dao.cached("$key|src")?.text) }
        return when (val o = router.run(Capability.TEXT, Prompts.buildText(task, s, text), s.preferredModel, onPartial)) {
            is AiRouter.Outcome.Ok -> {
                dao.upsertCache(CacheEntity(key, o.text, o.model, System.currentTimeMillis()))
                // the source text of a translation is kept with it (needed for the bilingual view)
                if (task == AiTask.TRANSLATE) dao.upsertCache(CacheEntity("$key|src", text, "", System.currentTimeMillis()))
                PT.Ok(o.text, o.model, false, text)
            }
            is AiRouter.Outcome.Failed -> PT.Fail(describe(o))
        }
    }

    /** Review summary for pages [from]..[to] (0-based, inclusive). One extraction request per page, then summarizing. */
    suspend fun summarizeRange(
        doc: PdfDocument, docUri: String, from: Int, to: Int, s: ReadingSettings, force: Boolean,
        onProgress: (String) -> Unit, onPartial: ((String) -> Unit)?,
    ): PT {
        val key = sha256(
            "v2|range|$docUri|$from|$to|${s.targetLanguage}|${s.profile.name}|" +
                (if (s.profile == ReadingProfile.CUSTOM) s.customInstruction else "")
        )
        if (!force) dao.cached(key)?.let { return PT.Ok(it.text, it.model, true) }
        val n = to - from + 1
        val parts = mutableListOf<String>()
        for (p in from..to) {
            onProgress("در حال خواندن صفحه ${p + 1} (${p - from + 1} از $n)…")
            when (val ex = extract(doc, docUri, p, s)) {
                is PT.Fail -> return PT.Fail("صفحه ${p + 1}: " + ex.message)
                PT.NoText -> {}
                is PT.Ok -> parts += "[Page ${p + 1}]\n${ex.text}"
            }
        }
        if (parts.isEmpty()) return PT.NoText
        // split long ranges so every request stays small
        val groups = mutableListOf<String>()
        val sb = StringBuilder()
        for (part in parts) {
            if (sb.isNotEmpty() && sb.length + part.length > 30_000) { groups += sb.toString(); sb.clear() }
            sb.append(part).append("\n\n")
        }
        if (sb.isNotEmpty()) groups += sb.toString()

        suspend fun ask(mode: Prompts.RangeMode, text: String, partial: ((String) -> Unit)?): PT =
            when (val o = router.run(Capability.TEXT, Prompts.buildRangeSummary(s, from, to, text, mode), s.preferredModel, partial)) {
                is AiRouter.Outcome.Ok -> PT.Ok(o.text, o.model)
                is AiRouter.Outcome.Failed -> PT.Fail(describe(o))
            }

        val result: PT = if (groups.size == 1) {
            onProgress("در حال تهیه‌ی خلاصه…")
            ask(Prompts.RangeMode.FULL, groups[0], onPartial)
        } else {
            val partial = mutableListOf<String>()
            for ((i, g) in groups.withIndex()) {
                onProgress("خلاصه‌ی بخش ${i + 1} از ${groups.size}…")
                when (val r = ask(Prompts.RangeMode.PART, g, null)) {
                    is PT.Ok -> partial += r.text
                    else -> return r
                }
            }
            onProgress("در حال یکی کردن خلاصه‌ها…")
            ask(Prompts.RangeMode.MERGE, partial.joinToString("\n\n---\n\n"), onPartial)
        }
        if (result is PT.Ok) dao.upsertCache(CacheEntity(key, result.text, result.model, System.currentTimeMillis()))
        return result
    }

    fun describe(f: AiRouter.Outcome.Failed): String = when (f.reason) {
        AiRouter.Reason.NOT_CONFIGURED ->
            "هیچ کلید معتبری تنظیم نشده است. از تنظیمات، کلید Gemini را اضافه کنید."
        AiRouter.Reason.ALL_COOLING_DOWN -> {
            val sec = ((f.retryAtMs ?: 0L) - System.currentTimeMillis()).coerceAtLeast(0L) / 1000
            "سهمیه‌ی همه‌ی کلیدها/مدل‌ها موقتاً تمام شده. حدود ${waitText(sec)} دیگر دوباره تلاش کنید."
        }
        AiRouter.Reason.NETWORK -> "اتصال اینترنت برقرار نیست یا سرویس در دسترس نیست."
        AiRouter.Reason.TIMEOUT -> "پاسخ سرویس بیش از حد طول کشید (شبکه یا مدل کند است). دوباره تلاش کنید."
        AiRouter.Reason.ALL_FAILED -> "درخواست روی همه‌ی کلیدها و مدل‌ها ناموفق بود.\n" + f.detail.take(500)
    }

    private fun waitText(seconds: Long): String = when {
        seconds < 90 -> "$seconds ثانیه"
        seconds < 5400 -> "${seconds / 60} دقیقه"
        else -> "${seconds / 3600} ساعت"
    }
}
