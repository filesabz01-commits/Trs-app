package app.pdfreader.ai

import android.graphics.Bitmap
import android.util.LruCache
import app.pdfreader.core.pdf.PdfDocument
import app.pdfreader.tts.PdfiumTextEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

sealed interface PT {
    class Ok(val text: String, val model: String = "", val fromCache: Boolean = false, val source: String? = null, val via: String? = null) : PT
    data object NoText : PT
    class Fail(val message: String) : PT
}

/**
 * The one text pipeline used by both "Translate/Explain/Summarize" and "Read Aloud":
 * page image -> clean body text (session memory only, unless the user opts in) -> translation (permanent cache).
 */
class PageTextService(
    private val dao: AiDao,
    private val router: AiRouter,
    private val engine: PdfiumTextEngine,
) {
    private val session = LruCache<String, String>(300)

    fun clearSession() = session.evictAll()

    private fun extractKey(docUri: String, page: Int, s: ReadingSettings) = sha256("v2|$docUri|$page|${s.sourceLanguage}")

    private fun finalKey(task: AiTask, docUri: String, page: Int, s: ReadingSettings) = sha256(
        "v2|$docUri|$page|${task.name}|${s.sourceLanguage}|${s.targetLanguage}|${s.profile.name}|" +
            (if (s.profile == ReadingProfile.CUSTOM) s.customInstruction else "")
    )

    suspend fun cached(task: AiTask, docUri: String, page: Int, s: ReadingSettings): PT.Ok? =
        finalKey(task, docUri, page, s).let { k -> dao.cached(k)?.let { PT.Ok(it.text, it.model, true, dao.cached("$k|src")?.text) } }

    /**
     * The 3-way page evaluation, run before any request is spent:
     *  1. CLEAN text layer      -> no OCR: the layer is used directly, plus ONE structural clean-up pass,
     *  2. NO text layer (scan)  -> OCR with the vision model (extract + clean in one request),
     *  3. GARBLED text layer    -> the broken layer is thrown away and the page is OCR'd.
     * [force] (the "OCR this page" button) always takes the OCR path.
     */
    suspend fun extract(
        doc: PdfDocument, docUri: String, page: Int, s: ReadingSettings,
        force: Boolean = false, onPhase: (String) -> Unit = {},
    ): PT {
        val key = extractKey(docUri, page, s)
        if (!force) {
            session.get(key)?.let { return if (it == Prompts.NO_TEXT) PT.NoText else PT.Ok(it) }
            if (s.persistOcr) {
                dao.cached("ocr|$key")?.let {
                    session.put(key, it.text)
                    return PT.Ok(it.text)
                }
            }
        }
        var verdict = TextVerdict(PageTextKind.NONE, if (force) "OCR درخواستی" else "")
        var layer = ""
        if (!force) {
            onPhase("در حال بررسی لایه‌ی متنی صفحه ${page + 1}…")
            val raw = try {
                engine.pageText(docUri, page)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            if (raw != null) {
                layer = raw
                verdict = TextQuality.assess(raw)
            }
        }
        if (verdict.kind == PageTextKind.CLEAN) return cleanLayer(layer, key, page, s, onPhase)
        onPhase(
            if (verdict.kind == PageTextKind.GARBLED) "متن PDF مخدوش است (${verdict.reason})؛ OCR صفحه ${page + 1}…"
            else "صفحه‌ی اسکن‌شده؛ OCR صفحه ${page + 1}…"
        )
        return ocrPage(doc, key, page, s, if (verdict.kind == PageTextKind.GARBLED) "OCR (متن مخدوش)" else "OCR")
    }

    /** Mode 1: clean text layer. One structural pass by the text model; if it fails the local clean-up is used. */
    private suspend fun cleanLayer(layer: String, key: String, page: Int, s: ReadingSettings, onPhase: (String) -> Unit): PT {
        onPhase("متن سالم PDF؛ بدون OCR (پاکسازی ساختار صفحه ${page + 1})…")
        val local = TextQuality.localClean(layer)
        if (local.isBlank()) return PT.NoText
        var text = local
        var model = ""
        when (val o = router.run(Capability.TEXT, Prompts.buildClean(s, local), s.preferredModel)) {
            is AiRouter.Outcome.Ok -> {
                val t = o.text.trim()
                if (t.contains("NO_TEXT")) {
                    session.put(key, Prompts.NO_TEXT)
                    return PT.NoText
                }
                // a truncated answer must never replace the page: keep the local result then
                if (t.length * 100 >= local.length * 55) { text = t; model = o.model }
            }
            is AiRouter.Outcome.Failed -> {}
        }
        session.put(key, text)
        if (s.persistOcr) dao.upsertCache(CacheEntity("ocr|$key", text, model, System.currentTimeMillis()))
        return PT.Ok(text, model, false, null, "متن PDF")
    }

    /** Modes 2 and 3: render the page and read it with the vision model. */
    private suspend fun ocrPage(doc: PdfDocument, key: String, page: Int, s: ReadingSettings, via: String): PT {
        val jpeg = try {
            withContext(Dispatchers.IO) {
                val bmp = doc.render(page, 1400)
                val out = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 82, out)
                bmp.recycle()
                out.toByteArray()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            return PT.Fail("رندر صفحه برای پردازش ممکن نشد.")
        }
        return when (val o = router.run(Capability.VISION, Prompts.buildExtract(s, jpeg), s.preferredModel)) {
            is AiRouter.Outcome.Ok -> {
                var text = o.text.trim()
                if (text.contains("NO_TEXT")) text = Prompts.NO_TEXT
                session.put(key, text)
                if (text == Prompts.NO_TEXT) PT.NoText
                else {
                    if (s.persistOcr) dao.upsertCache(CacheEntity("ocr|$key", text, o.model, System.currentTimeMillis()))
                    PT.Ok(text, o.model, false, null, via)
                }
            }
            is AiRouter.Outcome.Failed -> PT.Fail(describe(o))
        }
    }

    /** Translation matched to source sentences: [groups][i] = the source sentences (indices) that [items][i] translates. */
    class AlignedResult(val groups: List<IntRange>?, val items: List<String>?, val error: String?)

    suspend fun translateAligned(docUri: String, page: Int, s: ReadingSettings, sentences: List<String>): AlignedResult {
        val key = sha256("ali|v1|$docUri|$page|${s.sourceLanguage}|${s.targetLanguage}|${s.profile.name}|" + sentences.joinToString("\u0001"))
        dao.cached(key)?.let { c -> parseAligned(c.text, sentences.size)?.let { return AlignedResult(it.first, it.second, null) } }
        var lastError = "ترجمه‌ی هم‌تراز ناموفق بود"
        for (attempt in 0 until 2) {
            when (val o = router.run(Capability.TEXT, Prompts.buildAligned(s, sentences), s.preferredModel)) {
                is AiRouter.Outcome.Ok -> {
                    val parsed = parseAligned(o.text, sentences.size)
                    if (parsed != null) {
                        dao.upsertCache(CacheEntity(key, o.text, o.model, System.currentTimeMillis()))
                        return AlignedResult(parsed.first, parsed.second, null)
                    }
                    lastError = "بلوک‌های ترجمه با جمله‌های اصلی هم‌تراز نبود"
                }
                is AiRouter.Outcome.Failed -> return AlignedResult(null, null, describe(o))
            }
        }
        return AlignedResult(null, null, lastError)
    }

    /** Blocks must cover sentences 1..n exactly once and in order; anything else is rejected (the caller falls back). */
    private fun parseAligned(raw: String, n: Int): Pair<List<IntRange>, List<String>>? {
        val marks = Regex("\\[\\[\\s*(\\d+)\\s*(?:[-\u2013]\\s*(\\d+)\\s*)?]]").findAll(raw).toList()
        if (marks.isEmpty()) return null
        val groups = ArrayList<IntRange>()
        val items = ArrayList<String>()
        var next = 1
        for ((i, m) in marks.withIndex()) {
            val a = m.groupValues[1].toIntOrNull() ?: return null
            val b = m.groupValues[2].toIntOrNull() ?: a
            if (a != next || b < a || b > n) return null
            val end = if (i + 1 < marks.size) marks[i + 1].range.first else raw.length
            val t = raw.substring(m.range.last + 1, end).trim()
            if (t.isBlank()) return null
            groups += (a - 1)..(b - 1)
            items += t
            next = b + 1
        }
        return if (next == n + 1) groups to items else null
    }

    class SegmentResult(val items: List<String>?, val error: String?)

    /**
     * Translates [segments] (consecutive parts of one page) in ONE request and returns exactly one translation per
     * segment, or an error. A wrong number of blocks is retried once; the result is cached.
     */
    suspend fun translateSegments(docUri: String, page: Int, s: ReadingSettings, segments: List<String>): SegmentResult {
        val key = sha256("seg|v1|$docUri|$page|${s.sourceLanguage}|${s.targetLanguage}|${s.profile.name}|" + segments.joinToString("\u0001"))
        dao.cached(key)?.let { c -> parseSegments(c.text, segments.size)?.let { return SegmentResult(it, null) } }
        var lastError = "ترجمه‌ی قطعه‌ای ناموفق بود"
        for (attempt in 0 until 2) {
            when (val o = router.run(Capability.TEXT, Prompts.buildSegments(s, segments), s.preferredModel)) {
                is AiRouter.Outcome.Ok -> {
                    val items = parseSegments(o.text, segments.size)
                    if (items != null) {
                        dao.upsertCache(CacheEntity(key, o.text, o.model, System.currentTimeMillis()))
                        return SegmentResult(items, null)
                    }
                    lastError = "تعداد قطعه‌های ترجمه با متن اصلی برابر نبود"
                }
                is AiRouter.Outcome.Failed -> return SegmentResult(null, describe(o))
            }
        }
        return SegmentResult(null, lastError)
    }

    private fun parseSegments(raw: String, n: Int): List<String>? {
        val marks = Regex("\\[\\[(\\d+)]]").findAll(raw).toList()
        if (marks.size != n) return null
        val out = ArrayList<String>(n)
        for ((i, m) in marks.withIndex()) {
            if (m.groupValues[1].toIntOrNull() != i + 1) return null
            val end = if (i + 1 < marks.size) marks[i + 1].range.first else raw.length
            val t = raw.substring(m.range.last + 1, end).trim()
            if (t.isBlank()) return null
            out += t
        }
        return out
    }

    /** Translate / explain / summarize already-extracted text. Results are stored permanently. */
    suspend fun process(
        task: AiTask, docUri: String, page: Int, s: ReadingSettings, text: String,
        force: Boolean = false, onPartial: ((String) -> Unit)? = null,
    ): PT {
        val key = finalKey(task, docUri, page, s)
        if (!force) dao.cached(key)?.let { return PT.Ok(it.text, it.model, true, dao.cached("$key|src")?.text) }
        return when (val o = router.run(Capability.TEXT, Prompts.buildText(task, s, text), s.preferredModel, onPartial)) {
            is AiRouter.Outcome.Ok -> {
                dao.upsertCache(CacheEntity(key, o.text, o.model, System.currentTimeMillis()))
                // the source text of a translation is kept with it (needed for the bilingual view)
                if (task == AiTask.TRANSLATE) dao.upsertCache(CacheEntity("$key|src", text, "", System.currentTimeMillis()))
                PT.Ok(o.text, o.model, false, text)
            }
            is AiRouter.Outcome.Failed -> PT.Fail(describe(o))
        }
    }

    /** Review summary for pages [from]..[to] (0-based, inclusive). One extraction request per page, then summarizing. */
    suspend fun summarizeRange(
        doc: PdfDocument, docUri: String, from: Int, to: Int, s: ReadingSettings, force: Boolean,
        onProgress: (String) -> Unit, onPartial: ((String) -> Unit)?,
    ): PT {
        val key = sha256(
            "v2|range|$docUri|$from|$to|${s.targetLanguage}|${s.profile.name}|" +
                (if (s.profile == ReadingProfile.CUSTOM) s.customInstruction else "")
        )
        if (!force) dao.cached(key)?.let { return PT.Ok(it.text, it.model, true) }
        val n = to - from + 1
        val parts = mutableListOf<String>()
        for (p in from..to) {
            onProgress("در حال خواندن صفحه ${p + 1} (${p - from + 1} از $n)…")
            when (val ex = extract(doc, docUri, p, s)) {
                is PT.Fail -> return PT.Fail("صفحه ${p + 1}: " + ex.message)
                PT.NoText -> {}
                is PT.Ok -> parts += "[Page ${p + 1}]\n${ex.text}"
            }
        }
        if (parts.isEmpty()) return PT.NoText
        // split long ranges so every request stays small
        val groups = mutableListOf<String>()
        val sb = StringBuilder()
        for (part in parts) {
            if (sb.isNotEmpty() && sb.length + part.length > 30_000) { groups += sb.toString(); sb.clear() }
            sb.append(part).append("\n\n")
        }
        if (sb.isNotEmpty()) groups += sb.toString()

        suspend fun ask(mode: Prompts.RangeMode, text: String, partial: ((String) -> Unit)?): PT =
            when (val o = router.run(Capability.TEXT, Prompts.buildRangeSummary(s, from, to, text, mode), s.preferredModel, partial)) {
                is AiRouter.Outcome.Ok -> PT.Ok(o.text, o.model)
                is AiRouter.Outcome.Failed -> PT.Fail(describe(o))
            }

        val result: PT = if (groups.size == 1) {
            onProgress("در حال تهیه‌ی خلاصه…")
            ask(Prompts.RangeMode.FULL, groups[0], onPartial)
        } else {
            val partial = mutableListOf<String>()
            for ((i, g) in groups.withIndex()) {
                onProgress("خلاصه‌ی بخش ${i + 1} از ${groups.size}…")
                when (val r = ask(Prompts.RangeMode.PART, g, null)) {
                    is PT.Ok -> partial += r.text
                    else -> return r
                }
            }
            onProgress("در حال یکی کردن خلاصه‌ها…")
            ask(Prompts.RangeMode.MERGE, partial.joinToString("\n\n---\n\n"), onPartial)
        }
        if (result is PT.Ok) dao.upsertCache(CacheEntity(key, result.text, result.model, System.currentTimeMillis()))
        return result
    }

    fun describe(f: AiRouter.Outcome.Failed): String = when (f.reason) {
        AiRouter.Reason.NOT_CONFIGURED ->
            "هیچ کلید معتبری تنظیم نشده است. از تنظیمات، کلید Gemini را اضافه کنید."
        AiRouter.Reason.ALL_COOLING_DOWN -> {
            val sec = ((f.retryAtMs ?: 0L) - System.currentTimeMillis()).coerceAtLeast(0L) / 1000
            "سهمیه‌ی همه‌ی کلیدها/مدل‌ها موقتاً تمام شده. حدود ${waitText(sec)} دیگر دوباره تلاش کنید."
        }
        AiRouter.Reason.NETWORK -> "اتصال اینترنت برقرار نیست یا سرویس در دسترس نیست."
        AiRouter.Reason.TIMEOUT -> "پاسخ سرویس بیش از حد طول کشید (شبکه یا مدل کند است). دوباره تلاش کنید."
        AiRouter.Reason.ALL_FAILED -> "درخواست روی همه‌ی کلیدها و مدل‌ها ناموفق بود.\n" + f.detail.take(500)
    }

    private fun waitText(seconds: Long): String = when {
        seconds < 90 -> "$seconds ثانیه"
        seconds < 5400 -> "${seconds / 60} دقیقه"
        else -> "${seconds / 3600} ساعت"
    }
}
