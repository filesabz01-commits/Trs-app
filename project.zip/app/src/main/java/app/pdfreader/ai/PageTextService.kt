package app.pdfreader.ai

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.util.LruCache
import app.pdfreader.core.pdf.PdfDocument
import app.pdfreader.tts.PdfiumTextEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

sealed interface PT {
    class Ok(val text: String, val model: String = "", val fromCache: Boolean = false, val source: String? = null, val via: String? = null) : PT
    data object NoText : PT
    class Fail(val message: String) : PT
}

class PageTextService(
    private val dao: AiDao,
    private val router: AiRouter,
    private val engine: PdfiumTextEngine,
) {
    private val session = LruCache<String, String>(300)

    fun clearSession() = session.evictAll()

    private fun extractKey(docUri: String, page: Int, s: ReadingSettings) = sha256("v4|$docUri|$page|${s.sourceLanguage}")

    private fun finalKey(task: AiTask, docUri: String, page: Int, s: ReadingSettings) = sha256(
        "v4|$docUri|$page|${task.name}|${s.sourceLanguage}|${s.targetLanguage}|${s.profile.name}|" +
            (if (s.profile == ReadingProfile.CUSTOM) s.customInstruction else "")
    )

    private fun contentKey(task: AiTask, s: ReadingSettings, text: String): String = sha256(
        "v4|content|${task.name}|${s.targetLanguage}|${s.profile.name}|" +
            (if (s.profile == ReadingProfile.CUSTOM) s.customInstruction else "") + "|" +
            sha256(text.trim().lowercase())
    )

    suspend fun cached(task: AiTask, docUri: String, page: Int, s: ReadingSettings): PT.Ok? {
        val k = finalKey(task, docUri, page, s)
        return dao.cached(k)?.let { PT.Ok(it.text, it.model, true, dao.cached("$k|src")?.text) }
    }

    /**
     * Check if text is already written in the target language (avoiding wasteful translation calls).
     */
    fun isAlreadyTargetLanguage(text: String, targetLang: String): Boolean {
        val letters = text.filter { it.isLetter() }
        if (letters.length < 20) return false
        if (targetLang in RTL_LANGS) {
            val rtlLetters = letters.count { ch ->
                ch in '\u0600'..'\u06FF' || ch in '\u0750'..'\u077F' || ch in '\uFB50'..'\uFDFF' || ch in '\uFE70'..'\uFEFF'
            }
            return (rtlLetters.toDouble() / letters.length) > 0.65
        }
        if (targetLang == "en") {
            val latinLetters = letters.count { it in 'a'..'z' || it in 'A'..'Z' }
            return (latinLetters.toDouble() / letters.length) > 0.80
        }
        return false
    }

    suspend fun extract(
        doc: PdfDocument, docUri: String, page: Int, s: ReadingSettings,
        force: Boolean = false, onPhase: (String) -> Unit = {},
    ): PT {
        val key = extractKey(docUri, page, s)
        if (!force) {
            session.get(key)?.let { return if (it == Prompts.NO_TEXT) PT.NoText else PT.Ok(it) }
            if (s.persistOcr) {
                dao.cached("ocr|$key")?.let {
                    session.put(key, it.text)
                    return PT.Ok(it.text)
                }
            }
        }
        var verdict = TextVerdict(PageTextKind.NONE, if (force) "OCR درخواستی" else "")
        var layer = ""
        if (!force) {
            onPhase("در حال بررسی لایه‌ی متنی صفحه ${page + 1}…")
            val raw = try {
                engine.pageText(docUri, page)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            if (raw != null) {
                layer = raw
                verdict = TextQuality.assess(raw)
            }
        }
        if (verdict.kind == PageTextKind.CLEAN) return cleanLayer(layer, key, page, s, onPhase)
        onPhase(
            if (verdict.kind == PageTextKind.GARBLED) "متن PDF مخدوش است (${verdict.reason})؛ OCR صفحه ${page + 1}…"
            else "صفحه‌ی اسکن‌شده؛ OCR فشرده‌ی صفحه ${page + 1}…"
        )
        return ocrPage(doc, key, page, s, if (verdict.kind == PageTextKind.GARBLED) "OCR (متن مخدوش)" else "OCR")
    }

    private suspend fun cleanLayer(layer: String, key: String, page: Int, s: ReadingSettings, onPhase: (String) -> Unit): PT {
        onPhase("متن سالم PDF؛ پردازش سریع محلی…")
        val local = TextQuality.localClean(layer)
        if (local.isBlank()) return PT.NoText
        session.put(key, local)
        if (s.persistOcr) dao.upsertCache(CacheEntity("ocr|$key", local, "local", System.currentTimeMillis()))
        return PT.Ok(local, "متن PDF", false, null, "متن PDF")
    }

    /** Optimized OCR with 1000px, grayscale, and 65 quality JPEG to save ~60% tokens. */
    private suspend fun ocrPage(doc: PdfDocument, key: String, page: Int, s: ReadingSettings, via: String): PT {
        val jpeg = try {
            withContext(Dispatchers.IO) {
                val bmp = doc.render(page, 1000)
                val gray = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(gray)
                val paint = Paint().apply {
                    colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
                }
                canvas.drawBitmap(bmp, 0f, 0f, paint)
                bmp.recycle()
                val out = ByteArrayOutputStream()
                gray.compress(Bitmap.CompressFormat.JPEG, 65, out)
                gray.recycle()
                out.toByteArray()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            return PT.Fail("رندر صفحه برای پردازش ممکن نشد.")
        }

        return when (val o = router.run(Capability.VISION, Prompts.buildExtract(s, jpeg), s.preferredModel)) {
            is AiRouter.Outcome.Ok -> {
                var text = o.text.trim()
                if (text.contains("NO_TEXT")) text = Prompts.NO_TEXT
                if (text != Prompts.NO_TEXT) {
                    // Same local junk filter as clean text layer (headers, stamps, diagram labels)
                    text = TextQuality.localClean(text)
                }
                session.put(key, text)
                if (text.isBlank() || text == Prompts.NO_TEXT) PT.NoText
                else {
                    if (s.persistOcr) dao.upsertCache(CacheEntity("ocr|$key", text, o.model, System.currentTimeMillis()))
                    PT.Ok(text, o.model, false, null, via)
                }
            }
            is AiRouter.Outcome.Failed -> PT.Fail(describe(o))
        }
    }

    /** Unified cache methods */
    suspend fun cachedText(key: String): String? = dao.cached(key)?.text
    suspend fun loadSavedText(key: String): String? = cachedText(key)

    suspend fun saveText(key: String, text: String) =
        dao.upsertCache(CacheEntity(key, text, "", System.currentTimeMillis()))

    /**
     * Persist a translation produced by the read-aloud path under the same keys
     * that the plain "ترجمه" button uses, so the two features share one cache and
     * never spend tokens twice for the same page.
     */
    suspend fun saveTranslation(docUri: String, page: Int, s: ReadingSettings, translated: String, source: String) {
        val pageKey = finalKey(AiTask.TRANSLATE, docUri, page, s)
        val cKey = contentKey(AiTask.TRANSLATE, s, source)
        val now = System.currentTimeMillis()
        dao.upsertCache(CacheEntity(pageKey, translated, "segment", now))
        dao.upsertCache(CacheEntity(cKey, translated, "segment", now))
        dao.upsertCache(CacheEntity("$pageKey|src", source, "", now))
    }

    class SegmentResult(val items: List<String>?, val error: String?)

    suspend fun translateSegments(docUri: String, page: Int, s: ReadingSettings, segments: List<String>): SegmentResult {
        val key = sha256("seg|v3|$docUri|$page|${s.sourceLanguage}|${s.targetLanguage}|${s.profile.name}|" + segments.joinToString("\u0001"))
        dao.cached(key)?.let { c -> parseSegments(c.text, segments.size)?.let { return SegmentResult(it, null) } }
        var lastError = "ترجمه‌ی قطعه‌ای ناموفق بود"
        for (attempt in 0 until 3) {
            when (val o = router.run(Capability.TEXT, Prompts.buildSegments(s, segments), s.preferredModel)) {
                is AiRouter.Outcome.Ok -> {
                    val items = parseSegments(o.text, segments.size)
                    if (items != null) {
                        dao.upsertCache(CacheEntity(key, o.text, o.model, System.currentTimeMillis()))
                        return SegmentResult(items, null)
                    }
                    lastError = "تعداد یا ترتیب قطعه‌های ترجمه با متن اصلی برابر نبود (تلاش ${attempt + 1})"
                }
                is AiRouter.Outcome.Failed -> {
                    // Only hard-fail on permanent problems; retry transient ones
                    if (o.reason == AiRouter.Reason.NOT_CONFIGURED || o.reason == AiRouter.Reason.ALL_COOLING_DOWN) {
                        return SegmentResult(null, describe(o))
                    }
                    lastError = describe(o)
                }
            }
        }
        return SegmentResult(null, lastError)
    }

    /**
     * More tolerant parser: accepts [[1]], [[ 1 ]], [1], 1. etc. and reconstructs by number order.
     * Falls back to sequential split if markers are missing but count of paragraphs matches.
     */
    private fun parseSegments(raw: String, n: Int): List<String>? {
        if (n <= 0) return null
        // Primary: numbered markers [[N]] or [N] or N.
        val markRegex = Regex("""(?:\[\[|\[)\s*(\d+)\s*(?:\]\]|\])|(?:^|\n)\s*(\d+)[\.\)]\s+""", RegexOption.MULTILINE)
        val marks = markRegex.findAll(raw).mapNotNull { m ->
            val num = (m.groupValues[1].ifBlank { m.groupValues[2] }).toIntOrNull() ?: return@mapNotNull null
            num to m.range
        }.toList()
        if (marks.isNotEmpty()) {
            val byNum = sortedMapOf<Int, String>()
            for ((i, pair) in marks.withIndex()) {
                val (num, range) = pair
                val end = if (i + 1 < marks.size) marks[i + 1].second.first else raw.length
                val t = raw.substring(range.last + 1, end).trim()
                    .removePrefix("\n").trim()
                if (t.isNotBlank()) byNum[num] = t
            }
            if (byNum.size == n && byNum.keys.first() == 1 && byNum.keys.last() == n) {
                return (1..n).map { byNum[it]!! }
            }
            // Accept if we got exactly the expected consecutive numbers even if start is not 1 (rare)
            if (byNum.size == n) {
                val sorted = byNum.toList().sortedBy { it.first }
                if (sorted.zipWithNext().all { (a, b) -> b.first == a.first + 1 }) {
                    return sorted.map { it.second }
                }
            }
        }
        // Fallback: split on blank lines if the model ignored numbering but produced the right count of blocks
        val blocks = raw.split(Regex("\n\\s*\n")).map { it.trim() }.filter { it.isNotBlank() && !it.matches(Regex("^\\[\\[?\\d+\\]?\\]$")) }
        if (blocks.size == n) return blocks
        return null
    }

    suspend fun process(
        task: AiTask, docUri: String, page: Int, s: ReadingSettings, text: String,
        force: Boolean = false,
        onModelActive: ((String) -> Unit)? = null,
        onPartial: ((String) -> Unit)? = null,
    ): PT {
        if (task == AiTask.TRANSLATE && isAlreadyTargetLanguage(text, s.targetLanguage)) {
            return PT.Ok(text, "متن از قبل به زبان مقصد است", true, text)
        }

        val pageKey = finalKey(task, docUri, page, s)
        val cKey = contentKey(task, s, text)

        if (!force) {
            dao.cached(pageKey)?.let { return PT.Ok(it.text, it.model, true, dao.cached("$pageKey|src")?.text) }
            dao.cached(cKey)?.let { return PT.Ok(it.text, it.model, true, text) }
        }

        val req = Prompts.buildText(task, s, text)
        return when (val o = router.run(Capability.TEXT, req, s.preferredModel, onModelActive, onPartial)) {
            is AiRouter.Outcome.Ok -> {
                val now = System.currentTimeMillis()
                dao.upsertCache(CacheEntity(pageKey, o.text, o.model, now))
                dao.upsertCache(CacheEntity(cKey, o.text, o.model, now))
                if (task == AiTask.TRANSLATE) dao.upsertCache(CacheEntity("$pageKey|src", text, "", now))
                PT.Ok(o.text, o.model, false, text)
            }
            is AiRouter.Outcome.Failed -> PT.Fail(describe(o))
        }
    }

    suspend fun summarizeRange(
        doc: PdfDocument, docUri: String, from: Int, to: Int, s: ReadingSettings, force: Boolean,
        onProgress: (String) -> Unit, onPartial: ((String) -> Unit)?,
    ): PT {
        val key = sha256(
            "v6|handout|$docUri|$from|$to|${s.handoutLanguage}|${s.targetLanguage}|${s.profile.name}|" +
                (if (s.profile == ReadingProfile.CUSTOM) s.customInstruction else "")
        )
        if (!force) dao.cached(key)?.let { return PT.Ok(it.text, it.model, true) }
        val n = to - from + 1
        val pageTexts = mutableListOf<Pair<Int, String>>() // pageIndex to text
        for (p in from..to) {
            onProgress("در حال خواندن صفحه ${p + 1} (${p - from + 1} از $n)…")
            when (val ex = extract(doc, docUri, p, s)) {
                is PT.Fail -> return PT.Fail("صفحه ${p + 1}: " + ex.message)
                PT.NoText -> {}
                is PT.Ok -> pageTexts += (p to "[Page ${p + 1}]\n${ex.text}")
            }
        }
        if (pageTexts.isEmpty()) return PT.NoText

        suspend fun ask(mode: Prompts.RangeMode, text: String, partial: ((String) -> Unit)?): PT =
            when (val o = router.run(Capability.TEXT, Prompts.buildRangeSummary(s, from, to, text, mode), s.preferredModel, null, partial)) {
                is AiRouter.Outcome.Ok -> PT.Ok(o.text, o.model)
                is AiRouter.Outcome.Failed -> PT.Fail(describe(o))
            }

        // For ranges up to 15 pages (standard chapter/section study range): single direct call with live streaming!
        // This keeps the full document context, streams tokens in 1-2s, and prevents false timeouts.
        val result: PT = if (pageTexts.size <= 15) {
            onProgress("در حال تولید جزوهٔ مرور هوشمند صفحات ${from + 1} تا ${to + 1}…")
            ask(Prompts.RangeMode.FULL, pageTexts.joinToString("\n\n") { it.second }, onPartial)
        } else {
            val groups = pageTexts.chunked(10)
            val partial = mutableListOf<String>()
            for ((i, g) in groups.withIndex()) {
                val pStart = g.first().first + 1
                val pEnd = g.last().first + 1
                onProgress("جزوهٔ بخش ${i + 1} از ${groups.size} (صفحات $pStart تا $pEnd)…")
                when (val r = ask(Prompts.RangeMode.PART, g.joinToString("\n\n") { it.second }, onPartial)) {
                    is PT.Ok -> partial += r.text
                    else -> return r
                }
            }
            onProgress("در حال ادغام نهایی جزوه…")
            ask(Prompts.RangeMode.MERGE, partial.joinToString("\n\n---\n\n"), onPartial)
        }
        if (result is PT.Ok) dao.upsertCache(CacheEntity(key, result.text, result.model, System.currentTimeMillis()))
        return result
    }

    fun describe(f: AiRouter.Outcome.Failed): String = when (f.reason) {
        AiRouter.Reason.NOT_CONFIGURED ->
            "هیچ کلید معتبری تنظیم نشده است. از تنظیمات، کلید Gemini را اضافه کنید."
        AiRouter.Reason.ALL_COOLING_DOWN -> {
            val sec = ((f.retryAtMs ?: 0L) - System.currentTimeMillis()).coerceAtLeast(0L) / 1000
            "سهمیه‌ی همه‌ی کلیدها/مدل‌ها موقتاً تمام شده. حدود ${waitText(sec)} دیگر دوباره تلاش کنید."
        }
        AiRouter.Reason.NETWORK -> "اتصال اینترنت برقرار نیست یا سرویس در دسترس نیست."
        AiRouter.Reason.TIMEOUT -> "پاسخ سرویس بیش از حد طول کشید (عدم دریافت توکن در ۲۰ ثانیه). مدل‌های دیگر را امتحان کنید."
        AiRouter.Reason.CANCELLED -> "عملیات توسط کاربر لغو شد."
        AiRouter.Reason.ALL_FAILED -> "درخواست روی همه‌ی کلیدها و مدل‌ها ناموفق بود.\n" + f.detail.take(500)
    }

    private fun waitText(seconds: Long): String = when {
        seconds < 90 -> "$seconds ثانیه"
        seconds < 5400 -> "${seconds / 60} دقیقه"
        else -> "${seconds / 3600} ساعت"
    }
}
