package app.pdfreader.ai

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONException
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL

internal class HttpResponse(val code: Int, val body: String)

internal suspend fun postJson(url: String, headers: Map<String, String>, body: String): HttpResponse =
    withContext(Dispatchers.IO) {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 20_000
            c.readTimeout = 90_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            HttpResponse(code, text)
        } finally {
            c.disconnect()
        }
    }

/** Turns every network/parse exception into a typed failure so nothing can crash the app. */
internal suspend fun guarded(block: suspend () -> AiResult): AiResult = try {
    block()
} catch (e: CancellationException) {
    throw e
} catch (e: SocketTimeoutException) {
    AiResult.Fail(FailKind.TIMEOUT, "timeout")
} catch (e: IOException) {
    AiResult.Fail(FailKind.NETWORK, e.message ?: "network")
} catch (e: JSONException) {
    AiResult.Fail(FailKind.BAD_REQUEST, "bad response format")
} catch (e: Exception) {
    AiResult.Fail(FailKind.NETWORK, e.message ?: "error")
}

private val retryRegex = Regex("\"retryDelay\"\\s*:\\s*\"(\\d+(?:\\.\\d+)?)s\"")

/** Uses ONLY what the provider reported; nothing is guessed locally. */
internal fun classifyError(code: Int, body: String): AiResult.Fail {
    val lower = body.lowercase()
    val squashed = lower.replace("_", "").replace(" ", "")
    val detail = body.take(300)
    return when {
        code == 402 -> AiResult.Fail(FailKind.DAILY_QUOTA, detail) // payment required / credits finished
        code == 429 -> {
            val credits = "insufficient_quota" in lower || "insufficient balance" in lower ||
                "insufficient credit" in lower || "credit balance" in lower
            val daily = credits || "perday" in squashed || "daily" in lower
            if (daily) AiResult.Fail(FailKind.DAILY_QUOTA, detail)
            else AiResult.Fail(
                FailKind.RATE_LIMIT, detail,
                retryRegex.find(body)?.groupValues?.get(1)?.toDoubleOrNull()?.let { (it * 1000).toLong() },
            )
        }
        code == 401 || code == 403 -> AiResult.Fail(FailKind.INVALID_KEY, detail)
        code == 400 && ("api key not valid" in lower || "api_key_invalid" in lower || "invalid api key" in lower) ->
            AiResult.Fail(FailKind.INVALID_KEY, detail)
        code == 404 -> AiResult.Fail(FailKind.MODEL_UNAVAILABLE, detail)
        code == 408 -> AiResult.Fail(FailKind.TIMEOUT, detail)
        code >= 500 -> AiResult.Fail(FailKind.SERVER, detail)
        else -> AiResult.Fail(FailKind.BAD_REQUEST, detail)
    }
}

/** Reads a server-sent-events style response line by line so text can be shown while it is generated. */
internal suspend fun postStream(
    url: String,
    headers: Map<String, String>,
    body: String,
    onLine: (String) -> Unit,
): HttpResponse = withContext(Dispatchers.IO) {
    val c = URL(url).openConnection() as HttpURLConnection
    try {
        c.requestMethod = "POST"
        c.connectTimeout = 20_000
        c.readTimeout = 60_000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        if (code !in 200..299) {
            val t = c.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return@withContext HttpResponse(code, t)
        }
        c.inputStream.bufferedReader(Charsets.UTF_8).useLines { lines -> lines.forEach(onLine) }
        HttpResponse(code, "")
    } finally {
        c.disconnect()
    }
}
