# Universal PDF Reader — مرحله ۱
Kotlin + Compose + Material 3 + Room. موتور فعلی: PdfRenderer (پشت interface `PdfEngine`).
ساخت: `gradle assembleDebug` (Gradle 8.9، JDK 17، Android SDK 34).
